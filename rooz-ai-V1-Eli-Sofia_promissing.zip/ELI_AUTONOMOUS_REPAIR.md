# Eli: autonomous implementation and repair

## Install

Stop Rooz-AI, replace its source files with this archive, and preserve your existing `.env`, `.venv` and `data` directory. Restart with `bash start.sh`. This update adds no dependencies and requires no Docker rebuild. Existing conversations, project files, preview data and generated applications are not rewritten.

An already-finished request does not restart automatically. Open the existing project and send `@Eli Continue the saved task and finish verification.` New requests use the updated behavior immediately after restart.

## Confirmed causes

The host previously sent failed verification back to Eli once, using a one-time boolean. After that feedback it accepted another final answer even if the check still failed. It also judged only the last check, so a different passing command could hide an unresolved failure. Finally, automatic checks ran after Eli drafted his answer, without returning successful/unavailable results to him before delivery.

The starter's browser test targets the starter UI. A customized app must update those assertions to cover its real features. A missing `Check backend` button proves that the locator failed; it does not establish a React rendering failure.

## Changes

- Keep failed checks in the work loop until their affected command is rerun successfully or a demonstrated infrastructure limitation is recorded. Continue after repeated repair proposals; no extra user approval is requested for an already-authorized repair.
- Track each command independently. Preserve failed checks across source edits and prevent unrelated passing checks from clearing them. Require full-stack acceptance again after edits to a supported app.
- Return automatic execution results to Eli before his final report.
- Use concise developer instructions covering ownership, inspection, implementation, autonomous diagnosis, meaningful testing and truthful delivery. Extend the frontend, backend, testing and debugging guides with the same workflow.
- Tell Eli to inspect and adapt starter tests when replacing starter components, preserving real application-to-backend coverage.
- Add an evidence-bound execution-blocker report for inaccessible runtime/dependencies/services. It requires an executed command, an exact diagnostic, the current revision, an explanation and an external next action. It never changes a failed result into a pass. A stale selector, missing project test file or local connection failure cannot be classified as a runtime blocker through this tool.
- Mark requests with unavailable/blocked verification as incomplete rather than successful delivery. Report a work-limit exit as unfinished development, not a model/provider error. Stop and the existing 64-step/15-minute execution limits remain in place.

## Verification and limits

133 automated Python checks passed. After the final prompt wording change, the 21 affected developer-context and recovery checks also passed. Tests include repeated premature final answers, unrelated passing commands, final-revision acceptance, stale diagnostics, work limits, cancellation, and actual OpenAI SDK serialization for both supported API routes.

A separate actual Chromium/HTTP/SQLite reproduction first failed on a removed starter button, rejected two premature confirmation proposals, saved a corrected test, passed browser create/edit/reload/delete and backend-read assertions, then passed final acceptance. The model in this reproduction was scripted: it verifies Rooz's control flow, not live-model repair quality. Ten existing browser team checks also passed, including handoffs, cancellation, saved conversations and mobile layout.

Execution used controlled native test adapters in this environment. Production still uses Docker. No live provider calls or Docker execution were performed here. The user's Task Board application was not modified or verified by this host update; Eli remains responsible for implementing and checking it.
