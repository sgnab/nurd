"""Link preinstalled frontend dependencies in the disposable copy, then execute."""
import json
import os
import sys
from pathlib import Path


def link_modules(modules, runtime):
    if modules.exists() or modules.is_symlink():
        return
    modules.mkdir()
    for installed in (runtime / 'node_modules').iterdir():
        if installed.name in ('.vite', '.vite-temp', '.cache', '.package-lock.json'):
            continue
        (modules / installed.name).symlink_to(installed, target_is_directory=installed.is_dir())


def prepare(workspace=Path('/work'), runtime=Path('/opt/rooz/web-runtime')):
    supported = json.loads((runtime / 'package.json').read_text())
    versions = {**supported.get('dependencies', {}), **supported.get('devDependencies', {})}
    for package in workspace.rglob('package.json'):
        if any(part in ('node_modules', '.git', '.venv') for part in package.parts):
            continue
        requested = json.loads(package.read_text())
        dependencies = {**requested.get('dependencies', {}), **requested.get('devDependencies', {})}
        # Only supply the bundled profile when every requested dependency is present.
        # Other installed/built projects can use their own dependency tree.
        modules = package.parent / 'node_modules'
        if modules.exists() or modules.is_symlink():
            continue
        missing = [name for name in dependencies if name not in versions]
        if missing:
            print('Bundled frontend runtime lacks: ' + ', '.join(missing) +
                  '. Add dependencies to the runner image; test containers cannot install from the internet.', flush=True)
            continue
        # Vite writes node_modules/.vite-temp when loading TypeScript config.
        # Keep this directory writable; installed package entries stay read-only.
        link_modules(modules, runtime)
        mismatches = [name for name, version in dependencies.items() if version != versions[name]]
        if mismatches:
            print('Bundled runtime versions (not a lockfile-matched install): ' +
                  ', '.join(name + '=' + versions[name] for name in mismatches), flush=True)
    # Scripts commonly run from /work while package.json lives under frontend/.
    # Make test imports resolvable there, even for plain HTML/Python projects.
    if not (workspace / 'package.json').is_file():
        link_modules(workspace / 'node_modules', runtime)
    # Python Playwright also installs a CLI named playwright, without `test`.
    # Prefer the actual Node test runner for npm/npx, without touching Python imports.
    os.environ['PATH'] = str(runtime / 'node_modules' / '.bin') + os.pathsep + os.environ.get('PATH', '')


if __name__ == '__main__':
    if len(sys.argv) < 2:
        raise SystemExit('A command is required')
    prepare()
    os.execvp(sys.argv[1], sys.argv[1:])
