"""Small automatic checks. These do not claim functional coverage."""
import ast,functools,http.server,json,subprocess,threading
from pathlib import Path
root=Path.cwd();failures=[];checked=[]
files=[p for p in root.rglob('*') if p.is_file() and not any(x in ('node_modules','.git','__pycache__') for x in p.parts)]
for path in files:
 name=path.relative_to(root).as_posix()
 try:
  if path.suffix=='.py':ast.parse(path.read_text(),filename=name);checked.append('Python syntax: '+name)
  elif path.suffix in ('.js','.mjs','.cjs'):
   result=subprocess.run(['node','--check',str(path)],capture_output=True,text=True,timeout=20)
   if result.returncode:raise ValueError(result.stderr[-1000:])
   checked.append('JavaScript syntax: '+name)
  elif path.suffix=='.json':json.loads(path.read_text());checked.append('JSON parse: '+name)
 except Exception as exc:failures.append(name+': '+str(exc)[:1000])
html=[p for p in files if p.suffix=='.html'][:5]
if html:
 from playwright.sync_api import sync_playwright
 class Quiet(http.server.SimpleHTTPRequestHandler):
  def log_message(self,*args):pass
 server=http.server.ThreadingHTTPServer(('127.0.0.1',0),functools.partial(Quiet,directory=str(root)))
 threading.Thread(target=server.serve_forever,daemon=True).start()
 try:
  with sync_playwright() as p:
   browser=p.chromium.launch(headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
   for path in html:
    page=browser.new_page();errors=[]
    page.on('pageerror',lambda error:errors.append(str(error)))
    page.on('requestfailed',lambda request:errors.append('Request failed: '+request.url))
    page.on('response',lambda r:errors.append('HTTP '+str(r.status)+' '+r.url) if r.status>=400 else None)
    try:
     page.goto('http://127.0.0.1:'+str(server.server_port)+'/'+path.relative_to(root).as_posix(),wait_until='networkidle',timeout=12000)
     if errors:raise ValueError('; '.join(errors)[:1000])
     checked.append('Browser load: '+path.relative_to(root).as_posix())
    except Exception as exc:failures.append(str(exc)[:1000])
    finally:page.close()
   browser.close()
 finally:server.shutdown();server.server_close()
unsupported=[p.relative_to(root).as_posix() for p in files if p.suffix in ('.jsx','.tsx','.ts')]
if unsupported:failures.append('These files need a project-specific build/type check: '+', '.join(unsupported[:10]))
print(json.dumps({'scope':'Syntax and browser-load smoke only; no functional coverage claimed','checks':checked,'failures':failures},indent=2))
if not checked and not failures:print('No supported executable code found; returned files were not behavior-tested.')
raise SystemExit(1 if failures else 0)
