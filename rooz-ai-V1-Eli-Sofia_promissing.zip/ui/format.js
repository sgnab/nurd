import MarkdownIt from 'markdown-it';
import hljs from 'highlight.js/lib/common';
window.roozMarkdown=new MarkdownIt({html:false,linkify:true,breaks:true});
window.roozHighlight=hljs;
