# Stage 1.8: Eli, full-stack foundation

This stage upgrades Eli individually. Alex's proposal/approval workflow, whole-project
version rollback and parallel development are subsequent stages.

## What changes

- Eli owns frontend, backend and their practical tests. Existing projects retain their stack.
- New apps can start from an independent React 18 / TypeScript / Vite 6 / Tailwind 3 / FastAPI template.
  It includes an original local Radix Slot button in the shadcn component pattern, utilities and
  components.json. It is a small component foundation, not the entire shadcn library.
- Eli receives the current REQUIREMENTS.md, DESIGN.md, PROGRESS.md and PLAN.md when present.
  Large documents are explicitly excerpted. Missing documents are reported, not invented.
- Four guides are listed in the prompt and read using read_skill: frontend, backend, testing, debugging.
  Only the small core and document context are automatically loaded; other guides are on demand.
- read_files must inspect an existing file before Eli replaces it. This is checked against its current bytes.
- A failed latest check returns to Eli for investigation once before accepting a final response. Eli can
  repair repeatedly during the tool loop. Unresolved/unavailable latest checks are appended to the reply.
  This is a practical feedback mechanism, not proof that arbitrary tasks always recover.
- Empty projects can use scaffold_app. It refuses to overwrite existing project files.
- Node dependencies are installed during the runner image build using the included lockfile. Test commands
  link that bundled dependency tree only inside a disposable workspace. No package downloads or secrets
  are available during tests. Different dependency versions are explicitly reported; unsupported packages
  require extending the runner image. No hidden native execution fallback exists.
- Eli has up to 64 tool-loop rounds within the existing 15-minute request deadline. Stop remains available.
- Add explicit host httpx dependency, already imported by preview code.

## Install

Extract this update into your existing Rooz-AI folder, preserving your .env and data directory.
The ZIP contains neither credentials nor user data. Stop Rooz-AI before replacing source files.

From that folder:

```bash
bash setup.sh
docker build -t rooz-ai-runner:stage1 -f sandbox/Dockerfile .
bash start.sh
```

The runner image rebuild is required once for this update. It is not needed on each restart.
Docker Desktop must be running when executing tests or starting a preview.

## Test Eli directly

Start with a new chat/project and address Eli:

> @Eli, create a small notes app using the full-stack starter. Use React/TypeScript/Tailwind
> and FastAPI with SQLite. Support adding, editing and deleting notes, reject blank notes,
> and preserve notes after reload. Read the relevant skills, save the files, run the production
> build, backend tests and a real browser-to-API test. Report the commands and actual results.

For follow-up work, ask Eli to modify the existing app without regenerating it.
For debugging, report an observed bug and ask for reproduction, repair and rerun evidence.

The starter itself only verifies a real frontend-to-health-API connection. It does not implement
notes, authentication, billing, databases or all CRUD tests on behalf of Eli. Eli must build
and test the requested application. A successful response generation is not a verified delivery.

## Preview boundary

The existing Preview button remains a static-file preview. This stage enables React builds
and real full-stack checks inside Docker; it does not add a persistent React/backend user preview.
Do not use the static Preview button as evidence that an API application works.
For a generated starter outside the sandbox:

```bash
npm --prefix frontend ci
npm --prefix frontend run build
python -m pip install -r backend/requirements.txt
python -m uvicorn backend.main:app --host 127.0.0.1 --port 8080
```

Then visit http://127.0.0.1:8080. For development use the Vite dev command in another terminal;
its /api proxy targets port 8080. Applications with client-side nested routes need appropriate
SPA fallback routing before deploying those routes.

## Validation and limits

See verification/stage18/results.md for checks actually executed here. Host behavior tests use
scripted model responses, not live-provider conversations. Docker is unavailable in the build
workspace, so actual image build/execution still needs the local Docker check below. No claim
is made that Eli's behavior is perfected or that external integrations were verified.

```bash
.venv/bin/python tests/check_stage18_docker.py
```

This creates a disposable starter workspace and runs backend tests, the production build and
the real browser-to-API check through the production DockerRunner. It does not use your API key.

The guides were independently written for Rooz-AI after reviewing Anthropic frontend-design /
webapp-testing, FastAPI's official skill/documentation, Playwright documentation and obra/superpowers
debugging/verification examples. No Atoms SDK, cloud secrets or proprietary backend integration is copied.
