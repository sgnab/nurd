# Stage 1.8 — Docker build/cache and setup correction

Apply these files over the existing Stage 1.8 project. Do not create another nested
rooz-ai folder. Your .env and data are not included in this patch.

From the project folder, run:

```bash
bash setup.sh
bash start.sh
```

setup.sh now selects an existing Python 3.11+ environment (preferring the project
.venv), checks Docker, installs host dependencies, builds the runner with Docker's
cache, then runs the actual API / React build / browser check. It reports success
only if all those commands succeed. Use start.sh alone for normal restarts.
On macOS, setup and start prefer Docker Desktop's bundled CLI over old installations.
An existing .env is preserved. Fresh setup can create a placeholder .env even when
.env.example was excluded from an earlier export. No key is generated automatically.

## Cause and correction

The initial Stage 1.8 runner linked the entire disposable node_modules directory
to the installed dependency tree in the read-only image. Vite tries to create
node_modules/.vite-temp when loading its TypeScript configuration. The user's
Docker run failed there after the backend test had passed.

The runner now creates an ordinary writable node_modules directory in the disposable
project and links each installed package entry into it. Vite's .vite-temp and .vite
caches can be written locally; the image's packages remain read-only. Container
isolation, network restrictions and dependency versions are unchanged.

The .dockerignore excludes credentials, user data and local installed dependencies
from the build context.

## Validation

- 104 host tests passed, including read-before-write/repair tests and four new setup
  checks: build then verify, build failure, verification failure, and unavailable Docker.
  Setup tests use fake command adapters and do not claim an actual Docker build.
- Bash syntax checks passed for setup.sh and start.sh.
- Actual TypeScript/Vite builds were run with a chmod read-only dependency tree.
  A normal host EACCES error triggers Vite's built-in fallback, so that alone did not
  reproduce the container failure. A focused filesystem-error adapter matching the
  reported ENOENT on .vite-temp made the old layout fail; the corrected layout passed
  the same test without writing cache files into the shared dependency tree.
- Real Chromium -> built React -> HTTP -> FastAPI connection passed using the new
  directory layout. This used a local Chromium executable adapter, not Docker.

Actual Docker execution is still unavailable in the build workspace. On your Mac,
`bash setup.sh` rebuilds the corrected image and performs that final verification.
See verification/setup-fix/vite-readonly-proof.json for the build comparison.

The existing Preview button remains static-only; this correction does not add a
persistent full-stack preview or change Eli's feature scope.
