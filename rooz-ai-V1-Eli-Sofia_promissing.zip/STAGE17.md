# Stage 1.7 — static Live Preview

Based on your latest `rooz-ai-review(2).zip`. This stage adds user-operated preview of saved HTML/CSS/JavaScript. Agents keep their existing chat, attachment and test tools; they cannot start, inspect or control the preview.

## Install

1. Stop Rooz-AI with Ctrl+C.
2. Extract `rooz-ai-stage17.zip` **inside your existing Rooz-AI folder**, replacing matching files. Keep `.env`, `.venv` and the entire `data/` folder.
3. Start Docker Desktop, then run:

   ```bash
   bash start.sh
   ```

4. Refresh Rooz-AI with Cmd+Shift+R.

There are no new Python packages, database migrations or Docker image changes. The preview reuses `rooz-ai-runner:stage1` (or your existing `ROOZ_RUNNER_IMAGE` override). If your agent tests already run in Docker, no rebuild is needed. Only if that image is missing, build it once:

```bash
docker build -t rooz-ai-runner:stage1 -f sandbox/Dockerfile .
```

Existing keys, conversations, attachments and project files are retained. Preview needs no model call or provider credential.

## Try it

Ask Sofia:

> @Sofia build a small counter in plain HTML, CSS and JavaScript with increase, decrease and reset buttons. Save it as index.html in Project files. Do not use React or a build tool.

After the files are saved:

1. Click **Preview** in the top toolbar.
2. Choose the HTML entry if there is more than one.
3. Click **Start Preview** and test the counter inside the panel.
4. Ask for a visible change, wait for the saved files, then click **Refresh**.
5. Click **Stop preview** to shut down that preview.

Code written only in a chat code block is not a saved project file. Uploaded HTML remains a reference, just like other attachments; ask the agent to save a project copy if you want to run it. The panel explains when no HTML entry is available.

## Behavior

- Start creates a read-only snapshot of the current room's public static files and starts the fixed Python static server inside Docker.
- The HTML entry's folder becomes the web root. Put its styles, scripts, images and data inside that folder. Root `index.html` is selected first when present.
- The app loads in a sandboxed iframe at a separate, loopback-only HTTP port. It cannot read the Rooz-AI API across origins. Preview does not mount `.env`, attachments, the conversation database or the host workspace.
- Refresh stops the old container, takes a new snapshot and starts it at the same preview address. This preserves that origin's localStorage/IndexedDB while reloading the page. Changes in JavaScript memory reset when the page reloads.
- The panel indicates when supported saved files changed. It does not automatically refresh while an agent is writing.
- Closing the panel keeps its server running. Reopening the panel or refreshing the Rooz-AI browser page reconnects to that server.
- Each room has its own preview. Switching rooms clears the previous iframe immediately; starting or stopping another room does not reuse its files.
- Stop removes the container and snapshot, while retaining saved source files. Starting after Stop may use a different port and browser storage origin.
- A graceful Rooz-AI shutdown stops its previews. After an interrupted shutdown, startup attempts cleanup of its recorded containers and resets the preview status. Cleanup failures remain visible and can be retried with Stop; they are not reported as success.

## Errors and logs

The panel displays actual startup and Docker errors, including a missing image, unavailable daemon or failed port binding. A preview becomes Running only after its fixed server returns the matching session identity from a real HTTP readiness check. Docker operations and readiness checks have timeouts.

Open **Preview server logs** for startup output and HTTP request logs. **Reload logs** retrieves the latest container output. These are server logs; JavaScript console errors remain in your browser's developer tools. A Running server does not certify application correctness or replace testing its buttons and behavior.

## Scope

This serves existing static files only. It does not install npm dependencies, compile JSX/TypeScript, start Vite, run backend code or start project-defined commands. HTML entries that directly load source JSX/TypeScript receive an explicit build-step message. React development servers and backend/API preview are later stages.

Supported public extensions are defined in `rooz/preview_server.py`. Hidden paths, dependency folders and symlinks are excluded. Snapshots are limited to 1,000 files, 10 MB per file and 50 MB total. The container has a read-only filesystem and mounts, resource limits and no forwarded provider keys. Its fixed server never imports generated project code. Browser JavaScript runs normally and may make external requests permitted by the browser; the preview is not a network-offline browser.

## Checks performed

- 83 Python tests passed, including 17 preview tests.
- 14 actual Chromium preview workflows passed: saved files, counter actions, external CSS/ES modules/JSON, origin separation, reopening, refresh with localStorage preservation, logs, Stop, runtime failure/retry, room separation, unsupported entries and mobile layout.
- 33 existing Chromium workflows passed across chat, team handoffs and attachments.
- Production startup scripts, requirements, storage, attachment module, Docker test runner and image definition remain unchanged. The agent module only gains the stage number and accurate user-preview instructions.

Docker is unavailable in the build environment. Preview browser tests use the actual fixed server through a controlled native test adapter; Docker launch arguments and failure handling are tested separately. No real Docker container or paid OpenAI call was run here. Reports under `verification/stage17/` distinguish these contexts.

An optional real-Docker smoke check is included for your Mac:

```bash
.venv/bin/python -m tests.check_preview_docker
```

It uses disposable controlled files, verifies HTML/JavaScript over the actual Docker-published port, then removes the container and snapshot. It makes no provider calls and does not alter your saved room. It exits nonzero if Docker is unavailable or any check fails.

## Component boundaries

`rooz/preview.py` owns snapshots, Docker lifecycle, readiness, logs and cleanup. `rooz/preview_server.py` is the fixed static server mounted into the existing image. `static/preview.js` and `static/preview.css` own the panel. `rooz/api.py` exposes room-scoped status/start/refresh/stop/log routes. The chat sends room-change/open-panel events; preview is not an agent tool or a project completion gate.
