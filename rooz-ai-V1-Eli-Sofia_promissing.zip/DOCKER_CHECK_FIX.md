# Docker availability check repair

Your terminal established that `docker image inspect rooz-ai-runner:stage1` fails while `docker run --rm --pull=never rooz-ai-runner:stage1 ...` succeeds. The app previously interpreted the inspection failure as a missing image and refused to start preview or tests.

Both test execution and preview now use one shared availability check: query the Docker daemon, then run a small fixed Python readiness command in the configured image. There is no image-inspection gate. The probe uses no network, host mounts, forwarded credentials or generated project code. It verifies both a zero exit code and a unique readiness marker. Missing images, daemon failures and execution failures retain the actual error. Operations are time-limited, and an interrupted probe attempts removal of its named container.

## Install

1. Stop Rooz-AI with Ctrl+C.
2. Extract `rooz-ai-docker-check-fix.zip` **inside your existing rooz-ai folder**, replacing matching files. The new `rooz/docker_environment.py` file must be included alongside the replacement `runner.py` and `preview.py`.
3. With Docker Desktop running, restart using `bash start.sh` in the same Terminal where `RUNNER_OK` succeeded.
4. Retry Start Preview. Ask Eli/Sofia to execute their saved tests again.

No Docker rebuild or package installation is needed. The ZIP does not replace your Dockerfile, `.env`, data, generated projects or dependencies. It preserves the Dockerfile change you made locally to disable pip progress.

This verifies environment availability, not application correctness. Preview still performs its server readiness check; generated code tests still run their actual commands and report their outcomes. No native execution fallback or fabricated success is introduced.

## Validation

91 Python tests passed. The eight added regression tests cover an inspect-fails/run-succeeds Docker CLI fixture through real subprocesses, probe restrictions, actual missing-image errors, unavailable daemon, failed or incorrect probe output, timeout cleanup, cancellation and concurrent checks. Existing preview lifecycle, API, chat, attachment and team tests also passed.

Docker itself is unavailable in the build environment. The regression uses a controlled CLI fixture; actual Docker execution on your Mac was established by your `RUNNER_OK` diagnostic. Preview startup after this repair still needs the local retry above.
