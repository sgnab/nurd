# Named projects and preview startup

## Install this update

Stop Rooz-AI. Replace its source files with this archive, preserving your existing `.env` and `data` directory. Start Docker Desktop, then run from the project folder:

```bash
bash setup.sh
bash start.sh
```

Setup rebuilds the image with the preview fix and runs the existing Docker checks. Open http://127.0.0.1:8001. Subsequent starts only need `bash start.sh`.

## Preview repair

The previous full-stack entry point copied source directly into Docker's root-owned `/work` mount. Python then tried to copy directory metadata onto that mount and failed with `Operation not permitted`. Source now goes into the app-owned `/work/project` child. Container permissions, read-only source and disposable copies remain in place.

## Project naming

New project asks for a name before creating anything. Cancel creates nothing. The sidebar, conversation header and project record use the same name. Click the header to rename; saved files, conversation history, project IDs and preview data stay attached. ZIP downloads use the project name. Existing single-chat projects adopt their saved conversation names without moving files. Five recent projects remain visible, with older projects collapsed.

## Verification

122 Python checks passed, including a regression that reproduces the mount-metadata failure and verifies the child-directory fix. Chromium checks covered the existing chat, team, attachments and preview flows, plus project naming and full-stack preview CRUD/persistence. HTTP and storage checks used controlled fixtures and native runtime adapters; live model calls and Docker were not executed in this environment. `bash setup.sh` runs the real Docker checks on your laptop.

This update changes Rooz-AI's host runtime and project UI. Generated project application files were not edited.
