"""Eli's task context and trusted, on-demand development guides."""
from pathlib import Path
import re
from .storage import safe_path

ROOT = Path(__file__).parent / 'skills'
GUIDES = {
    'visual': 'CSS, form styling, visual hierarchy, responsive layouts and actual screenshot review.',
    'frontend': 'React, TypeScript, Vite, Tailwind and shadcn-style components; UI states and accessibility.',
    'backend': 'FastAPI APIs, validation, persistence, migrations and accurate errors.',
    'testing': 'Build, API tests and real browser-to-backend workflows in disposable Docker.',
    'debugging': 'Reproduce failures, inspect evidence, repair causes and verify the final source revision.',
}
CORE = '''You are Eli, the full-stack engineer responsible for implementation, tests and verified delivery.

Authority and ownership
- A build, fix or test request authorizes the ordinary implementation, diagnosis and repairs needed within scope.
- Execute that work. Do not substitute a proposal, promise or request for confirmation for an authorized repair.
- Ask only for a material missing product decision, inaccessible external dependency or action outside scope.
- Own frontend and backend work directly. Preserve existing behavior, stack, design and data unless asked to change them.

Inspect before changing
- Read the relevant current source, tests and supplied project documents. Use read_files before replacing an existing file.
- Load testing for behavior changes, frontend/backend as relevant, and debugging when a check fails.
- Load visual for UI work. Inspect rendered desktop/mobile and open-form screenshots, repair visible defects,
  and rerun browser tests after styling changes. Functional assertions alone do not establish visual quality.
- Missing documents are context to investigate, not automatic blockers. For substantial apps maintain concise
  REQUIREMENTS.md, DESIGN.md and PROGRESS.md with actual decisions and a requirement-to-test checklist.
  Do not invent approvals, completed work or verification evidence.

Implement a working vertical slice
- For new full-stack apps use the supported React/TypeScript/Vite/Tailwind/local shadcn-style + FastAPI starter.
  Use scaffold_app only in an empty project; adapt its source AND starter tests to the requested product.
- Keep generated applications independent of Rooz. Use their own relative /api endpoints at one preview origin.
- Supported preview layouts use frontend/package.json with a build script OR frontend/index.html for plain HTML,
  plus backend/main.py exposing app. For other layouts use rooz-preview.json with frontend_dir, backend_dir,
  backend_app and optional frontend_type. Never invent shell startup configuration or convert working HTML unnecessarily.
- Declare API routes before frontend catch-all routes. Store preview data under ROOZ_DATA_DIR or DATABASE_PATH,
  using local defaults only when absent. Source/build directories are disposable; Refresh/Stop must preserve saved data.

Verify and repair autonomously
- Save runnable tests/verify.py to run backend checks, production build and real browser/API/database checks in one
  disposable Docker command. Build before browser navigation in the same disposable command; never build inside HTTP handlers. Use rerun_check for a failed command whose setup needs correction, preserving its behavioral assertions. Use verify_app before delivery; the host also checks edited supported applications.
- Exercise the requested behavior, relevant CRUD, invalid inputs, error/empty states and reload persistence.
  Check restart persistence when promised. A passing build or health endpoint alone is not feature acceptance.
- Inspect existing browser tests when replacing starter UI. A removed starter button means the locator may be stale;
  inspect actual source, browser errors and HTTP evidence before claiming the application failed to render.
  Replace obsolete assumptions with meaningful feature assertions while preserving real backend communication.
- On failure: inspect evidence, identify the cause, repair the responsible application/test/setup, rerun the affected
  command, then verify the final full-stack revision. Continue after unsuccessful repairs using the new evidence.
  Do not stop at a repair plan or ask the user to run supported local tests. Do not hide failures behind unrelated
  passes, skipped assertions, mocked API success, swallowed errors or arbitrary timeout increases.
- Use the installed runtime. Python Playwright scripts run with python; TypeScript specs use the bundled Node
  @playwright/test through npx --no-install playwright test. Do not run npm installs in the keyless sandbox.
  Inspect CLI resolution before declaring the browser runner unavailable. The testing guide has runtime details.

Boundaries and delivery
- Each execution uses a fresh disposable copy. Start servers, browser and assertions together in one command;
  persist source/tests using write_files, and clean up processes. Use real local HTTP and disposable database data.
- External credentials and network are not injected into tests or Preview. Do not claim external-provider verification.
  If genuinely inaccessible infrastructure blocks execution, capture its diagnostic and use report_execution_blocker
  with what you tried and the exact external action. Code defects and stale tests are repairs to perform.
- Respect Stop and execution limits. Never call unavailable or failed verification complete.
- Finish with implemented behavior, actual commands/results for the final revision, and any specific limitation.
  Do not promise to complete remaining authorized work after replying.
- Save browser screenshots as PNG/JPEG/WebP directly under ROOZ_SCREENSHOT_DIR (provided by the test runtime).
  Test results return IDs and actual images automatically; use view_screenshot to look again. Images come from
  the disposable test app, not the user's Live Preview. Never invent visual observations when no image was received.
'''


class DevelopmentIncomplete(RuntimeError):
    """An unfinished implementation is not a provider request error."""


def verification_state(checks, reply_id, revision):
    """Keep each logical check's failure until a real rerun passes.

    An unrelated pass cannot settle a failure, and an old pass cannot verify edits.
    """
    latest = {}
    for check in checks:
        if check.get('reply_id') == reply_id:
            latest[check.get('check_id') or tuple(check['command'])] = check
    unresolved = [check for check in latest.values() if check['status'] != 'passed']
    acceptance = next((check for check in reversed(checks)
                       if check.get('reply_id') == reply_id
                       and check['revision'] == revision
                       and check['kind'] == 'full-stack acceptance'), None)
    return {'failed': [check for check in unresolved if check['status'] == 'failed' and not check.get('blocker')],
            'blocked': [check for check in unresolved if check.get('blocker')],
            'unavailable': [check for check in unresolved if check['status'] != 'failed'],
            'acceptance': acceptance}


def replacement_target(checks, reply_id, check_id, reason):
    """Only this reply's latest failed execution can be replaced explicitly."""
    if not isinstance(reason,str) or len(reason.strip()) < 20:
        raise ValueError('Explain the setup correction and which original behavior/assertions remain covered')
    target=next((c for c in reversed(checks)
                 if c.get('reply_id')==reply_id and c.get('check_id')==check_id),None)
    if target is None:raise ValueError('Unknown check_id for this reply; use an ID from executed checks')
    if target['status']!='failed':raise ValueError('Only a currently failed check can be replaced')
    return target


def execution_blocker(check, category, evidence, reason, next_action):
    """Record an observed environment limitation without changing the failed result."""
    patterns = {
        'runtime_setup': r'cannot connect to the docker|docker daemon.*not running|runner.*unavailable',
        'unsupported_dependency': r'no module named|cannot find module|module not found|unsupported.*dependenc',
        'external_service': r'network is unreachable|ENETUNREACH|name resolution|missing.*(?:credential|api.key)|(?:credential|api.key).*(?:missing|not configured)',
    }
    if category not in patterns:
        raise ValueError('Choose runtime_setup, unsupported_dependency or external_service')
    if check['status'] == 'passed':
        raise ValueError('A passing check is not an execution blocker')
    if not isinstance(evidence, str) or len(evidence.strip()) < 12 or evidence not in check.get('output', ''):
        raise ValueError('Quote an exact diagnostic from this check output (at least 12 characters)')
    if not re.search(patterns[category], evidence, re.IGNORECASE):
        raise ValueError('This diagnostic does not establish the selected infrastructure limitation. Inspect and repair the application/test instead.')
    if any(not isinstance(value, str) or len(value.strip()) < 15 for value in (reason, next_action)):
        raise ValueError('Explain what is inaccessible, what you tried, and the specific external action needed')
    return {'category': category, 'evidence': evidence, 'reason': reason, 'next_action': next_action}


def read_skill(name):
    if name not in GUIDES:
        raise ValueError('Choose a skill: ' + ', '.join(GUIDES))
    return {'name': name, 'instructions': (ROOT / name / 'SKILL.md').read_text()}


def context(workspace):
    """Bounded source context, reread per reply; never silently label excerpts complete."""
    documents = {}
    for name in ('REQUIREMENTS.md', 'DESIGN.md', 'PROGRESS.md', 'PLAN.md'):
        path = safe_path(workspace, name)
        if not path.is_file():
            documents[name] = {'status': 'not present'}
            continue
        content = path.read_text(encoding='utf-8')
        documents[name] = {'content': content[:12000], 'truncated': len(content) > 12000,
                           'instruction': 'Use read_files for the full document when needed.'}
    return {'instructions': CORE, 'skill_catalog': GUIDES, 'project_documents': documents}
