"""Provider routing for a request's immutable model selection; secrets stay server-side."""
import os
from openai import AsyncOpenAI

DEEPSEEK_MODEL='deepseek-flash'
CATALOG=(
    {'id':'gpt-6-luna','label':'GPT-6 Luna','provider':'openai'},
    {'id':DEEPSEEK_MODEL,'label':'DeepSeek V4.1 Flash','provider':'deepseek'},
    {'id':'gpt-6.1-sol','label':'GPT-6.1 Sol','provider':'openai'},
)

def provider_for(model):return 'deepseek' if model==DEEPSEEK_MODEL else 'openai'
def key_variable(model):return 'DEEPSEEK_API_KEY' if provider_for(model)=='deepseek' else 'OPENAI_API_KEY'

class ModelRouter:
    def __init__(self,default):
        self.default=default
        self.catalog=[dict(row) for row in CATALOG]
        if default not in {row['id'] for row in self.catalog}:
            self.catalog.append({'id':default,'label':default,'provider':'openai'})
    def public_models(self):
        return [{**row,'key_configured':bool(os.getenv(key_variable(row['id']),'').strip())} for row in self.catalog]
    def validate(self,model,require_key=False):
        if model not in {row['id'] for row in self.catalog}:raise ValueError('Choose a model from the model dropdown')
        if require_key and not os.getenv(key_variable(model),'').strip():
            raise ValueError('Add '+key_variable(model)+' to the Rooz-AI .env file and restart. No other model was substituted.')
        return model
    def client(self,model):
        self.validate(model,require_key=True)
        options={'api_key':os.environ[key_variable(model)].strip(),'max_retries':1,'timeout':150}
        if provider_for(model)=='deepseek':options['base_url']='https://api.deepseek.com'
        return AsyncOpenAI(**options)
