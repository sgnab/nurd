"""Small original full-stack template; no Atoms SDK or hosted-service coupling."""
import json
from pathlib import Path

TEMPLATE = Path(__file__).parent / 'templates' / 'fullstack'


def files(workspace):
    existing = [p for p in workspace.rglob('*') if p.is_file()]
    if existing:
        raise ValueError('Scaffolding requires an empty project. Inspect and modify existing files instead.')
    return [{'path': p.relative_to(TEMPLATE).as_posix(), 'content': p.read_text()}
            for p in sorted(TEMPLATE.rglob('*')) if p.is_file()
            and not any(part in ('node_modules', 'dist', '__pycache__', '.pytest_cache') for part in p.relative_to(TEMPLATE).parts)]


def dependencies():
    return json.loads((TEMPLATE / 'frontend' / 'package.json').read_text())
