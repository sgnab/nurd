"""HTTP boundary. Storage, agents and test execution have independent interfaces."""
import asyncio,io,json,os,re,zipfile
from contextlib import asynccontextmanager
from pathlib import Path
from urllib.parse import quote
from fastapi import FastAPI,HTTPException,Request,UploadFile,File
from fastapi.responses import FileResponse,Response,JSONResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel,Field
from .storage import Store
from .runner import DockerRunner
from .agents import AGENTS,AgentService
from .team import agent_id,recipients
from .attachments import Attachments,AttachmentError,MAX_FILES,MAX_FILE_BYTES,MAX_TOTAL_BYTES,ACCEPT
from .preview import PreviewService
from .monitoring import Monitoring
from .security import SecurityService

class ChatInput(BaseModel):
 title:str=Field(default='New conversation',min_length=1,max_length=100)
 project_id:str|None=None
class RenameInput(BaseModel):title:str=Field(min_length=1,max_length=100)
class ProjectInput(BaseModel):title:str=Field(min_length=1,max_length=100)
class MessageInput(BaseModel):
 agent:str='alex'
 content:str=Field(default='',max_length=30000)
 model:str=Field(default='',max_length=120)
 attachment_ids:list[str]=Field(default_factory=list,max_length=MAX_FILES)

class PreviewInput(BaseModel):entry:str=Field(default='',max_length=240)
class SecurityInput(BaseModel):
 mode:str='fast'
 model:str=Field(default='',max_length=120)
 agent:str='eli'
 confirm_paid:bool=False
 max_calls:int=Field(default=20,ge=1,le=40)
 output_tokens:int=Field(default=4096,ge=1024,le=8192)

def create_app(data_dir,static_dir,client_factory,model,runner=None,preview_backend=None,model_router=None):
 store=Store(data_dir);runner=runner or DockerRunner(os.getenv('ROOZ_RUNNER_IMAGE','rooz-ai-runner:stage1'))
 attachments=Attachments(store)
 monitoring=Monitoring(store.root)
 service=AgentService(store,runner,client_factory,model,attachments=attachments,model_router=model_router,observer=monitoring.event)
 security=SecurityService(store,monitoring,client_factory,model,model_router)
 previews=PreviewService(store,preview_backend)
 @asynccontextmanager
 async def lifespan(app):
  await previews.recover()
  security.ensure_fast()
  yield
  await security.shutdown()
  await service.shutdown()
  await previews.shutdown()
 app=FastAPI(title='Rooz-AI · Stage 1.9',lifespan=lifespan)
 app.state.store=store;app.state.agents=service;app.state.attachments=attachments
 app.state.previews=previews;app.state.monitoring=monitoring;app.state.security=security
 @app.middleware('http')
 async def local_origin(request:Request,call_next):
  origin=request.headers.get('origin')
  if request.method not in ('GET','HEAD','OPTIONS') and origin and origin.rstrip('/')!=str(request.base_url).rstrip('/'):
   return JSONResponse({'detail':'Open Rooz-AI from its own local URL'},status_code=403)
  return await call_next(request)
 @app.exception_handler(KeyError)
 async def missing(request,exc):return JSONResponse({'detail':str(exc.args[0])},status_code=404)
 @app.exception_handler(ValueError)
 async def bad_input(request,exc):return JSONResponse({'detail':str(exc)},status_code=409)
 @app.get('/api/config')
 async def config():
  choices=model_router.public_models() if model_router else [{'id':model,'label':model,'provider':'openai','key_configured':bool(os.getenv('OPENAI_API_KEY','').strip())}]
  default_ready=next(row['key_configured'] for row in choices if row['id']==model)
  return {'agents':{k:{n:v for n,v in value.items() if n!='prompt'} for k,value in AGENTS.items()},
          'model':model,'models':choices,'key_configured':default_ready,'runner':await runner.capability(),'stage':1.9,
          'uploads':{'accept':ACCEPT,'max_files':MAX_FILES,'max_file_bytes':MAX_FILE_BYTES,'max_total_bytes':MAX_TOTAL_BYTES}}
 @app.get('/monitoring')
 async def monitoring_page():return FileResponse(Path(static_dir)/'monitoring.html')
 @app.get('/api/monitoring')
 async def monitoring_results():
  security.ensure_fast()
  return {'runs':monitoring.runs(store),'security_runs':security.reports(),'fingerprint':security.revision(),
          'models':model_router.public_models() if model_router else [{'id':model,'label':model,'key_configured':bool(os.getenv('OPENAI_API_KEY','').strip())}],
          'agents':list(AGENTS),'telemetry':'Metadata only; no prompts, file contents, credentials or model reasoning. Token usage is provider-reported; dollar cost is not configured.'}
 @app.post('/api/security/runs',status_code=202)
 async def security_start(body:SecurityInput):
  if body.mode=='live' and not body.confirm_paid:raise HTTPException(422,'Confirm the bounded paid model test before starting')
  return security.start(body.mode,body.model,body.agent,body.max_calls,body.output_tokens)
 @app.get('/api/security/runs/{identity}')
 async def security_report(identity:str):return monitoring.report(identity)
 @app.post('/api/security/runs/{identity}/stop')
 async def security_stop(identity:str):return security.stop(identity)
 @app.get('/api/chats')
 async def chats():return {'chats':store.chats()}
 @app.post('/api/chats',status_code=201)
 async def new_chat(body:ChatInput):return store.create_chat(body.title,body.project_id)
 @app.post('/api/projects',status_code=201)
 async def new_project(body:ProjectInput):
  if not body.title.strip():raise HTTPException(422,'Enter a project name')
  return store.create_chat(body.title.strip())
 @app.patch('/api/chats/{chat_id}')
 async def rename_chat(chat_id:str,body:RenameInput):
  if not body.title.strip():raise HTTPException(422,'Title cannot be empty')
  store.rename(chat_id,body.title.strip());return store.chat(chat_id)
 @app.get('/api/chats/{chat_id}')
 async def chat(chat_id:str):
  selected=store.chat(chat_id);project=selected['project_id']
  messages=store.messages(chat_id);bound=attachments.list(chat_id)
  for message in messages:message['attachments']=[a for a in bound if a['message_id']==message['id']]
  return {'chat':selected,'messages':messages,'runs':store.runs(chat_id),'attachments':bound,
          'pending_attachments':attachments.list(chat_id,pending=True),
          'files':store.manifest(project),'artifacts':store.artifacts(project),'revision':store.revision(project)}
 @app.post('/api/chats/{chat_id}/messages',status_code=202)
 async def message(chat_id:str,body:MessageInput):
  try:selected=agent_id(body.agent)
  except ValueError:raise HTTPException(422,'Choose Alex, Sofia or Eli')
  if not body.content.strip() and not body.attachment_ids:raise HTTPException(422,'Message cannot be empty')
  targets=recipients(body.content,selected)
  content=body.content.strip() or 'Please review the attached files.'
  selected_model=body.model or model
  if model_router:model_router.validate(selected_model,require_key=True)
  elif selected_model!=model:raise HTTPException(422,'Choose the configured model')
  run=store.start_run(chat_id,targets[0],content,body.attachment_ids,model=selected_model);service.start(run,targets);return run
 @app.post('/api/chats/{chat_id}/attachments',status_code=201)
 async def upload(chat_id:str,files:list[UploadFile]=File(...)):
  store.chat(chat_id)
  try:
   if not 1<=len(files)<=MAX_FILES:raise HTTPException(422,'Attach 1–8 files per message')
   items=[];total=0
   for file in files:
    data=await file.read(MAX_FILE_BYTES+1);total+=len(data)
    if len(data)>MAX_FILE_BYTES:raise HTTPException(413,'Each file must be at most 10 MB')
    if total>MAX_TOTAL_BYTES:raise HTTPException(413,'Attachments must total at most 20 MB')
    items.append((file.filename or '',data))
   return {'attachments':await asyncio.to_thread(attachments.save,chat_id,items)}
  except AttachmentError as exc:raise HTTPException(422,str(exc))
  finally:
   for file in files:await file.close()
 @app.delete('/api/chats/{chat_id}/attachments/{attachment_id}')
 async def remove_attachment(chat_id:str,attachment_id:str):
  try:attachments.remove_pending(chat_id,attachment_id)
  except AttachmentError as exc:raise HTTPException(409,str(exc))
  return {'removed':True}
 @app.get('/api/chats/{chat_id}/attachments/{attachment_id}/download')
 async def attachment_download(chat_id:str,attachment_id:str):
  row=attachments.get(chat_id,attachment_id)
  return FileResponse(attachments.original_path(row),filename=row['filename'],media_type=row['content_type'],
    headers={'X-Content-Type-Options':'nosniff','Content-Security-Policy':"default-src 'none'; sandbox"})
 @app.get('/api/chats/{chat_id}/attachments/{attachment_id}/thumbnail')
 async def attachment_thumbnail(chat_id:str,attachment_id:str):
  row=attachments.get(chat_id,attachment_id)
  if row['kind']!='image':raise HTTPException(404,'This attachment is not an image')
  return FileResponse(attachments.image_path(row),media_type='image/jpeg',
    headers={'X-Content-Type-Options':'nosniff','Cache-Control':'private, max-age=3600'})
 @app.get('/api/runs/{run_id}')
 async def run(run_id:str):return store.run(run_id)
 @app.post('/api/runs/{run_id}/stop')
 async def stop(run_id:str):return service.stop(run_id)
 @app.get('/api/chats/{chat_id}/preview')
 async def preview_status(chat_id:str):return await previews.describe(chat_id)
 @app.post('/api/chats/{chat_id}/preview/start')
 async def preview_start(chat_id:str,body:PreviewInput):return await previews.start(chat_id,body.entry)
 @app.post('/api/chats/{chat_id}/preview/refresh')
 async def preview_refresh(chat_id:str,body:PreviewInput):return await previews.start(chat_id,body.entry,refresh=True)
 @app.post('/api/chats/{chat_id}/preview/stop')
 async def preview_stop(chat_id:str):return await previews.stop(chat_id)
 @app.post('/api/chats/{chat_id}/preview/reset-data')
 async def preview_reset(chat_id:str):return await previews.reset_data(chat_id)
 @app.get('/api/chats/{chat_id}/preview/logs')
 async def preview_logs(chat_id:str):return await previews.read_logs(chat_id)
 @app.get('/api/artifacts/{artifact_id}/download')
 async def download(artifact_id:str):
  artifact=store.artifact(artifact_id)
  return Response(artifact['content'],media_type='text/plain; charset=utf-8',headers={
   'Content-Disposition':"attachment; filename*=UTF-8''"+quote(Path(artifact['path']).name,safe='')})
 @app.get('/api/projects/{project_id}/download')
 async def project_download(project_id:str):
  root=store.workspace(project_id);stream=io.BytesIO()
  with zipfile.ZipFile(stream,'w',zipfile.ZIP_DEFLATED) as z:
   for row in store.manifest(project_id):z.write(root/row['path'],row['path'])
  name=re.sub(r'[^\w .()-]+','-',store.project(project_id)['title']).strip(' .')[:80] or 'project'
  return Response(stream.getvalue(),media_type='application/zip',headers={'Content-Disposition':"attachment; filename*=UTF-8''"+quote(name+'.zip',safe='')})
 app.mount('/static',StaticFiles(directory=static_dir),name='static')
 @app.get('/')
 async def index():return FileResponse(Path(static_dir)/'index.html')
 return app
