---
name: backend
description: Implement FastAPI routes, data validation, persistence and API error handling.
---

Inspect existing routes, schemas, database access and tests first. Keep existing contracts unless asked to change them.
Adapt starter tests to the actual requested API. When an assertion fails, inspect the request, response and database,
repair within the authorized scope, and rerun it. Do not stop at a proposal or send executable local checks to the user.
For a new app use backend/main.py and expose /api routes. Validate requests with Pydantic and return explicit
response shapes and appropriate HTTP statuses. Keep errors actionable and avoid exposing secrets or tracebacks.
Use SQLite for small local apps where appropriate; use a configured PostgreSQL service when the project requires it.
Never claim PostgreSQL behavior was tested using only SQLite. Use transactions and parameterized queries;
preserve data across restarts. Schema changes need an explicit migration/data-preservation plan.
Do not block the async event loop with synchronous I/O. Enforce ownership on the server when authentication exists.
Use disposable storage in tests. Cover successful operations, invalid inputs, missing records and relevant persistence.
TestClient is suitable for API checks, but integration acceptance also exercises the actual HTTP application.
Declare imported third-party dependencies. Use the installed runtime; report unsupported dependencies specifically.
For the one-origin preview, expose application endpoints under /api. Honor DATABASE_PATH or ROOZ_DATA_DIR
for persistent SQLite data; the preview work directory is rebuilt and disposable. Do not hardcode Rooz-AI's port.
Declare specific API/health routes before any catch-all frontend route. Test GET and mutation endpoints against
the final saved revision; a working POST does not establish that GET/list routing works. Do not suppress database
initialization failures and continue as if storage is ready. Existing databases still need schema initialization checks.


## Browser setup and corrected checks

Each test command gets a fresh disposable workspace. Build the frontend before starting the server and navigating with Playwright, in the same command or saved verification script. Never start npm/build work inside an HTTP request handler; serving a page must not trigger a build. A health endpoint alone does not establish frontend readiness.

When a diagnostic command itself omitted setup or used a stale selector, correct it while keeping the intended behavior and assertions. Use rerun_check with the failed result's check_id and explain the correction. Its executed pass settles that logical check and preserves both results. An unrelated passing command cannot clear a failure. Prefer saved scripts over repeated ad hoc probes; run verify_app for the final source revision. Do not remove assertions just to pass.
