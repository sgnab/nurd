---
name: debugging
description: Diagnose a code, test, build or setup failure and verify the repair.
---

Own the repair through verified completion. The user's build/fix/test request authorizes ordinary source,
test and local setup repairs within scope. Do not return a proposal or ask to proceed with that same work.

Reproduce the reported behavior through its actual entry point. Read the error, relevant source and recent changes.
Separate application defects, broken tests, unavailable dependencies and external-service failures using evidence.
If evidence is missing, capture it with an executable diagnostic or focused reproduction; do not merely request it
when tools can obtain it. Form a specific hypothesis, make a scoped change and rerun the failing operation.
Keep the acceptance requirement intact. Correct test setup or selectors when evidence shows the test is wrong;
do not remove a valid assertion or change expected behavior just to turn a check green.
When an attempt fails, use the new evidence to change approach. Avoid repetitive speculative patches.
Verify the final source revision with the focused regression and relevant surrounding checks.
Record actual results and unresolved issues in PROGRESS.md for substantial tasks. Preserve useful failure details.
Do not claim a bug is fixed solely because files were saved, a teammate said so or syntax passed.

For a browser timeout, inspect the locator, component and browser errors/HTTP responses before diagnosing it.
A missing control establishes a locator failure, not a rendering failure. If a starter-specific control was removed
by the requested redesign, update the test to exercise the real feature and retain backend communication coverage.
For example, replace a removed starter connection-button test with a create/read/update/delete flow using the
current labels and actual HTTP responses. Do not reintroduce irrelevant starter UI just to satisfy stale tests.

After a failed repair, use the new output and continue; one unsuccessful attempt is not a handoff to the user.
Rerun the same affected command to settle its failure, then run verify_app for the final revision. Do not hide a
failure behind a different passing command, longer timeout, skipped assertion, mocked response or swallowed error.
If tools cannot access a required dependency, capture the exact diagnostic and use report_execution_blocker
with what you tried and the specific external action. Application bugs, stale tests and missing evidence you can
collect are work to perform, not external blockers. Stop is always respected; resource limits remain visible.


## Browser setup and corrected checks

Each test command gets a fresh disposable workspace. Build the frontend before starting the server and navigating with Playwright, in the same command or saved verification script. Never start npm/build work inside an HTTP request handler; serving a page must not trigger a build. A health endpoint alone does not establish frontend readiness.

When a diagnostic command itself omitted setup or used a stale selector, correct it while keeping the intended behavior and assertions. Use rerun_check with the failed result's check_id and explain the correction. Its executed pass settles that logical check and preserves both results. An unrelated passing command cannot clear a failure. Prefer saved scripts over repeated ad hoc probes; run verify_app for the final source revision. Do not remove assertions just to pass.
