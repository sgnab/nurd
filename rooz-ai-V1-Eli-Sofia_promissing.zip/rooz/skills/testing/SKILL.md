---
name: testing
description: Verify a change with builds, API tests and real browser/API/database interaction.
---

Choose a few meaningful checks for the task.
Read tests/verify.py and the starter's browser/API tests when customizing an app. Keep the verify command stable,
but replace obsolete starter assumptions with assertions for the requested product. Save runnable tests before
claiming their coverage. Do not deliver a test plan in place of executing the authorized checks.

For a full-stack app:
1. Run backend tests using a fresh disposable database.
2. Run TypeScript checking and Vite production build.
3. Start the actual backend and serve the built frontend in the same disposable container.
4. Use Python Playwright to interact with that app. Test the requested workflow, relevant CRUD, reload persistence,
   validation and visible failure behavior. Confirm real API responses; do not intercept app endpoints with mock success.
5. Stop servers in finally blocks. Include failed assertions, console errors and relevant HTTP errors in test output.
6. For UI changes, capture desktop/mobile and open-form states under ROOZ_SCREENSHOT_DIR and inspect the
   actual images returned by Rooz. Load visual for the review checklist and capture convention. Repeat after repairs.

The runner has no external network or provider keys. Localhost servers inside the container are supported.
Each run_tests command gets a fresh copy; files written inside it disappear after the command. Start server, browser
and assertions together in one command. Save source/test files with write_files before running them.
The supplied frontend dependencies are linked by the runner into directories with package.json. Do not run npm install
inside the keyless test environment. Use `npm --prefix frontend run build` and the existing declared scripts.
Prefer role/label locators and Playwright expect assertions. Wait for specific UI or response readiness;
do not rely on fixed sleeps or networkidle. Include actual navigation/setup, such as opening collapsed details.
Use Chromium headlessly with --no-sandbox and --disable-dev-shm-usage in this sandbox.
Distinguish API unit tests, mocked UI tests, real local integration, and live external-provider tests in the report.
If a check fails, read debugging and repair the cause. Rerun affected checks after the last code edit.
Continue without requesting confirmation for these in-scope repairs. After focused checks pass, run verify_app.
Report only the final revision's executed results. A build/API pass cannot replace a failing browser workflow.
Passing tests support their specific assertions, not a claim that every possible bug is absent.

Save tests/verify.py as a fail-fast orchestrator and call verify_app. Include behavior tests for the actual feature,
not merely the template's health connection. A notes app needs add/list/edit/delete, blank/whitespace rejection,
and records surviving reload; test across a backend restart when persistence is required. Confirm saved values
through real API reads as well as UI rendering. Use disposable paths passed through ROOZ_DATA_DIR/DATABASE_PATH.
Assert visible failure states and missing/invalid API requests proportionately. Check console errors and failed HTTP
requests. Do not mock application endpoints in the final integration scenario. Focus each test on a useful behavior;
do not create exhaustive tests for every styling choice. Record unresolved coverage rather than inventing it.

Both browser APIs are installed: Python playwright and JavaScript @playwright/test. For .spec.ts files run
`npx --no-install playwright test frontend/test_notes_app.spec.ts --workers=1` from the project root, or use
the declared npm test script. The sandbox links shared test dependencies at the project root as well as frontend/.
Do not use `python -m playwright test`: Python's CLI only manages browsers/tools. Python tests run as Python scripts
or pytest tests. An `unknown command test` error is a CLI selection/setup problem, not evidence the app UI failed.
Do not send the task back to the user before inspecting the available runtime and trying the supported route.
Node browser tests in this sandbox should use Chromium with launchOptions args --no-sandbox and
--disable-dev-shm-usage, one worker and an outputDir under /tmp. Start the actual app before executing the specs,
and stop it in finally. A failing run remains unverified even when independent backend tests passed.


## Browser setup and corrected checks

Each test command gets a fresh disposable workspace. Build the frontend before starting the server and navigating with Playwright, in the same command or saved verification script. Never start npm/build work inside an HTTP request handler; serving a page must not trigger a build. A health endpoint alone does not establish frontend readiness.

When a diagnostic command itself omitted setup or used a stale selector, correct it while keeping the intended behavior and assertions. Use rerun_check with the failed result's check_id and explain the correction. Its executed pass settles that logical check and preserves both results. An unrelated passing command cannot clear a failure. Prefer saved scripts over repeated ad hoc probes; run verify_app for the final source revision. Do not remove assertions just to pass.
