---
name: frontend
description: Build or change React/TypeScript interfaces, styling and browser behavior.
---

Read existing entry points, routes, package.json and relevant components. Follow the user's brief and
existing design. For new apps use React/TypeScript/Vite, Tailwind and reusable local shadcn-style components.
Use scaffold_app only in an empty project; it creates a runnable baseline, not the finished requested product.
When replacing starter components, inspect their browser tests and update outdated UI assumptions as part of
the implementation. Cover the requested interactions against the real backend before delivery.
Use real content and deliberate spacing, typography and hierarchy. Keep forms labelled, keyboard accessible,
responsive and usable with long content. Implement loading, empty, validation, failure and success states.
Keep business operations behind the project's own API. Use relative /api URLs and the Vite proxy in development.
Do not invent generated-file links or treat a static server as a backend.
Run the configured TypeScript check and production build. Exercise important interactions in a browser.
Load visual and inspect desktop/mobile plus open-form screenshots before delivering UI changes. Define visible
field borders/surfaces and keyboard focus explicitly; CSS resets are not a finished form design. Changing status
must update the displayed column only after an actual successful API write, and remain correct after reload.
Preserve console and HTTP errors for diagnosis. A successful build alone does not prove a functioning UI.
Use the testing guide for practical browser tests; read debugging when behavior fails.
The user full-stack Preview builds dist/ and serves assets at the same origin as /api. Do not use absolute
localhost backend URLs. Missing /api responses are errors, not a signal to switch silently to fake/local data.


## Browser setup and corrected checks

Each test command gets a fresh disposable workspace. Build the frontend before starting the server and navigating with Playwright, in the same command or saved verification script. Never start npm/build work inside an HTTP request handler; serving a page must not trigger a build. A health endpoint alone does not establish frontend readiness.

When a diagnostic command itself omitted setup or used a stale selector, correct it while keeping the intended behavior and assertions. Use rerun_check with the failed result's check_id and explain the correction. Its executed pass settles that logical check and preserves both results. An unrelated passing command cannot clear a failure. Prefer saved scripts over repeated ad hoc probes; run verify_app for the final source revision. Do not remove assertions just to pass.
