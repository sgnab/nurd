"""Fixed static server used inside Docker; never imports or executes project code."""
import argparse,json,mimetypes
from functools import partial
from http.server import SimpleHTTPRequestHandler,ThreadingHTTPServer
from pathlib import Path
from urllib.parse import quote,unquote,urlsplit

PUBLIC_EXTENSIONS={'.html','.htm','.css','.js','.mjs','.json','.map','.png','.jpg','.jpeg','.gif','.webp','.svg','.ico','.woff','.woff2','.ttf','.otf','.txt','.csv','.mp3','.mp4','.ogg','.wav','.webm'}

class Handler(SimpleHTTPRequestHandler):
 def __init__(self,*args,root,entry,session,**kwargs):
  self.root=Path(root).resolve();self.entry=entry;self.session=session
  super().__init__(*args,directory=str(self.root),**kwargs)
 def end_headers(self):
  self.send_header('Cache-Control','no-store');self.send_header('X-Content-Type-Options','nosniff')
  self.send_header('Content-Security-Policy',"worker-src 'none'")
  super().end_headers()
 def list_directory(self,path):self.send_error(404,'Choose a saved HTML entry file');return None
 def do_GET(self):self.serve(False)
 def do_HEAD(self):self.serve(True)
 def serve(self,head):
  path=unquote(urlsplit(self.path).path)
  if path=='/__rooz_health':
   content=json.dumps({'preview':self.session}).encode();self.send_response(200);self.send_header('Content-Type','application/json');self.send_header('Content-Length',str(len(content)));self.end_headers()
   if not head:self.wfile.write(content)
   return
  rel=Path(path.lstrip('/') or self.entry)
  if '\\' in path or any(p.startswith('.') for p in rel.parts) or rel.suffix.lower() not in PUBLIC_EXTENSIONS:
   self.send_error(404,'Static asset not available');return
  target=(self.root/rel).resolve()
  if not target.is_relative_to(self.root) or not target.is_file() or any(p.is_symlink() for p in [self.root/rel,*(self.root/rel).parents]):
   self.send_error(404,'Static asset not available');return
  self.path='/'+quote(rel.as_posix())
  if head:super().do_HEAD()
  else:super().do_GET()

def main():
 parser=argparse.ArgumentParser();parser.add_argument('--root',required=True);parser.add_argument('--entry',required=True);parser.add_argument('--session',required=True);parser.add_argument('--port',type=int,default=8080);parser.add_argument('--host',default='0.0.0.0');args=parser.parse_args()
 mimetypes.add_type('text/javascript','.mjs')
 server=ThreadingHTTPServer((args.host,args.port),partial(Handler,root=args.root,entry=args.entry,session=args.session))
 print('Static preview listening on port '+str(args.port),flush=True);server.serve_forever()

if __name__=='__main__':main()
