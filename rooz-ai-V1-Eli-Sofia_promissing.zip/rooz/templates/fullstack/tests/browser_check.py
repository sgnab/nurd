"""Real browser -> HTTP -> FastAPI check. Run after the production build."""
import socket
import os
from pathlib import Path
import subprocess
import sys
import time
import urllib.request
from playwright.sync_api import sync_playwright, expect

def main():
    with socket.socket() as sock:
        sock.bind(('127.0.0.1', 0))
        port = sock.getsockname()[1]
    url = f'http://127.0.0.1:{port}'
    process = subprocess.Popen([sys.executable, '-m', 'uvicorn', 'backend.main:app', '--host', '127.0.0.1', '--port', str(port)])
    try:
        deadline = time.monotonic() + 15
        while True:
            try:
                with urllib.request.urlopen(url + '/api/health', timeout=1) as response:
                    assert response.status == 200
                break
            except OSError:
                if process.poll() is not None or time.monotonic() >= deadline:
                    raise RuntimeError('Backend did not become ready')
                time.sleep(.1)
        with sync_playwright() as playwright:
            browser = playwright.chromium.launch(args=['--no-sandbox', '--disable-dev-shm-usage'])
            try:
                page = browser.new_page()
                errors = []
                page.on('pageerror', lambda error: errors.append(str(error)))
                page.on('response', lambda response: errors.append(f'HTTP {response.status} {response.url}') if response.status >= 400 else None)
                page.goto(url)
                with page.expect_response(lambda response: response.url.endswith('/api/health') and response.status == 200):
                    page.get_by_role('button', name='Check backend').click()
                expect(page.get_by_role('status')).to_have_text('Backend connected')
                # Starter evidence only: replace these states with the requested app's workflows.
                if os.getenv('ROOZ_SCREENSHOT_DIR'):
                    evidence=Path(os.environ['ROOZ_SCREENSHOT_DIR']);evidence.mkdir(parents=True,exist_ok=True)
                    page.screenshot(path=str(evidence/'desktop.png'))
                    page.set_viewport_size({'width':390,'height':844})
                    assert page.evaluate('document.documentElement.scrollWidth <= innerWidth')
                    page.screenshot(path=str(evidence/'mobile.png'))
                assert not errors, errors
                print('PASS: real React frontend -> HTTP -> FastAPI health request; no API mocks')
            finally:
                browser.close()
    finally:
        process.terminate()
        try: process.wait(timeout=5)
        except subprocess.TimeoutExpired:
            process.kill(); process.wait()

if __name__ == '__main__':
    main()
