"""One command, one disposable workspace, all checks share the built artifacts."""
import subprocess
import sys

commands = [
    [sys.executable, '-m', 'pytest', '-q', 'tests/test_api.py'],
    ['npm', '--prefix', 'frontend', 'run', 'build'],
    [sys.executable, 'tests/browser_check.py'],
]
for command in commands:
    print('RUN:', ' '.join(command), flush=True)
    subprocess.run(command, check=True)
