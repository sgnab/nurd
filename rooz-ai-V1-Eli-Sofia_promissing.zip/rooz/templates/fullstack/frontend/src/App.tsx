import { useState } from 'react';
import { Button } from './components/ui/button';
export default function App() {
  const [message, setMessage] = useState('Ready to connect');
  const [busy, setBusy] = useState(false);
  async function connect() {
    setBusy(true);
    try {
      const response = await fetch('/api/health');
      if (!response.ok) throw new Error(`API returned HTTP ${response.status}`);
      const data = await response.json();
      setMessage(data.status === 'ok' ? 'Backend connected' : 'Unexpected health response');
    } catch (error) { setMessage(error instanceof Error ? error.message : 'Connection failed'); }
    finally { setBusy(false); }
  }
  return <main className="mx-auto max-w-3xl px-6 py-20">
    <h1 className="mb-4 text-4xl font-semibold tracking-tight">Your application starts here</h1>
    <p className="mb-8 text-slate-600">A React interface connected to its own API.</p>
    <Button onClick={connect} disabled={busy}>{busy ? 'Connecting…' : 'Check backend'}</Button>
    <p role="status" className="mt-4">{message}</p>
  </main>;
}
