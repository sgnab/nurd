"""Frontend acceptance only: build once, then real browser/localStorage workflows."""
import subprocess,sys
for command in (['npm','--prefix','frontend','run','build'],[sys.executable,'tests/browser_check.py']):
    print('RUN:', ' '.join(command), flush=True)
    subprocess.run(command,check=True)
