"""Replace starter assertions with actual requested product behavior. Mock data only."""
import os,socket,subprocess,sys,time,urllib.request
from pathlib import Path
from playwright.sync_api import sync_playwright,expect


def main():
    with socket.socket() as sock:
        sock.bind(('127.0.0.1',0));port=sock.getsockname()[1]
    base='http://127.0.0.1:'+str(port)
    process=subprocess.Popen([sys.executable,'-m','uvicorn','backend.main:app','--host','127.0.0.1','--port',str(port)])
    try:
        deadline=time.monotonic()+15
        while True:
            try:
                with urllib.request.urlopen(base+'/api/health',timeout=1) as response:
                    assert response.status==200
                break
            except OSError:
                if process.poll() is not None or time.monotonic()>deadline:raise RuntimeError('Static preview adapter did not start')
                time.sleep(.1)
        with sync_playwright() as playwright:
            browser=playwright.chromium.launch(args=['--no-sandbox','--disable-dev-shm-usage'])
            try:
                page=browser.new_page(viewport={'width':1440,'height':1000})
                errors=[]
                page.on('pageerror',lambda e:errors.append(str(e)))
                page.on('response',lambda r:errors.append('HTTP '+str(r.status)+' '+r.url) if r.status>=400 else None)
                page.goto(base)
                expect(page.get_by_text('Review the design',exact=True)).to_be_visible()
                page.get_by_role('button',name='Add item',exact=True).click()
                expect(page.get_by_label('Title',exact=True)).to_be_focused()
                page.get_by_label('Title',exact=True).fill('   ')
                page.get_by_role('button',name='Save item',exact=True).click()
                expect(page.get_by_role('dialog').get_by_role('alert')).to_contain_text('Enter a title')
                capture=Path(os.environ.get('ROOZ_SCREENSHOT_DIR','.rooz-screenshots'));capture.mkdir(parents=True,exist_ok=True)
                page.screenshot(path=str(capture/'form.png'))
                page.get_by_label('Title',exact=True).fill('Prepare launch')
                page.get_by_role('button',name='Save item',exact=True).click()
                expect(page.get_by_text('Prepare launch',exact=True)).to_be_visible()
                page.get_by_role('button',name='Edit Prepare launch',exact=True).click()
                page.get_by_label('Title',exact=True).fill('Launch ready')
                page.get_by_role('button',name='Save item',exact=True).click()
                page.get_by_role('checkbox',name='Launch ready',exact=True).check()
                page.reload()
                expect(page.get_by_role('checkbox',name='Launch ready',exact=True)).to_be_checked()
                page.screenshot(path=str(capture/'desktop.png'))
                page.get_by_role('button',name='Add item',exact=True).click();page.keyboard.press('Escape')
                expect(page.get_by_role('dialog')).not_to_be_visible()
                expect(page.get_by_role('button',name='Add item',exact=True)).to_be_focused()
                page.on('dialog',lambda dialog:dialog.accept())
                page.get_by_role('button',name='Delete Launch ready',exact=True).click()
                page.get_by_role('button',name='Delete Review the design',exact=True).click()
                expect(page.get_by_role('heading',name='No items yet',exact=True)).to_be_visible()
                page.reload()
                expect(page.get_by_role('heading',name='No items yet',exact=True)).to_be_visible()
                page.set_viewport_size({'width':390,'height':844})
                assert page.evaluate('document.documentElement.scrollWidth <= innerWidth')
                page.get_by_role('button',name='Add item',exact=True).click()
                expect(page.get_by_role('button',name='Save item',exact=True)).to_be_in_viewport()
                page.screenshot(path=str(capture/'mobile.png'))
                page.keyboard.press('Escape')
                page.evaluate("localStorage.setItem('sofia.frontend-starter.items','invalid-json')")
                page.reload()
                expect(page.get_by_role('alert')).to_be_visible()
                page.screenshot(path=str(capture/'error.png'))
                assert not errors,errors
                print('PASS frontend mock workflows: create/edit/toggle/delete, validation, reload, empty/error states, focus/Escape and desktop/mobile; not real backend integration.')
            finally:browser.close()
    finally:
        process.terminate()
        try:process.wait(timeout=5)
        except subprocess.TimeoutExpired:process.kill();process.wait()

if __name__=='__main__':main()
