"""Static preview adapter only. No application/domain data API is implemented."""
from pathlib import Path
from fastapi import FastAPI, HTTPException
from fastapi.responses import FileResponse

app = FastAPI(title='Frontend mock preview', docs_url=None, redoc_url=None)
dist = Path(__file__).resolve().parents[1]/'frontend'/'dist'

@app.get('/api/health')
def health():
    return {'status':'ok', 'mode':'frontend-mock-preview'}

@app.get('/api/{path:path}')
def no_business_api(path: str):
    raise HTTPException(404, 'Frontend mock preview has no business API')

@app.get('/{path:path}')
def frontend(path: str):
    relative = Path(path or 'index.html')
    target = (dist/relative).resolve()
    if not target.is_relative_to(dist.resolve()) or any(part.startswith('.') for part in relative.parts) or '\\' in path:
        raise HTTPException(404)
    if not target.is_file() and not relative.suffix:
        target = dist/'index.html'
    if not target.is_file():
        raise HTTPException(404)
    return FileResponse(target)
