# Frontend mock starter

This is a starter only. Sofia must replace its UI and browser assertions with the requested product.
`frontend/src/services/items.ts` defines a typed async interface backed by localStorage.
Mock records are clearly labeled. `backend/main.py` is a static serving adapter for Preview;
it provides no business API. Eli can later implement a real API and replace the service adapter.

Run `python tests/verify.py` in Rooz's disposable runner to build then exercise the UI in a real browser.
The starter checks create/edit/toggle/delete, blank input, reload persistence, empty state, corrupt-storage
error visibility, modal focus/Escape and desktop/mobile overflow, with screenshots for actual review.
These are mock frontend tests, not real-backend integration or live-provider verification.
