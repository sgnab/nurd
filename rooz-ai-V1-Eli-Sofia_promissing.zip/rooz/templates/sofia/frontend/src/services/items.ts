// Mock-only service. Replace this adapter with HTTP later; components keep the same interface.
export interface Item { id: string; title: string; done: boolean }
export interface ItemService {
  list(): Promise<Item[]>;
  create(title: string): Promise<Item>;
  update(id: string, changes: Partial<Pick<Item, 'title' | 'done'>>): Promise<void>;
  remove(id: string): Promise<void>;
}
const KEY = 'sofia.frontend-starter.items';
function read(): Item[] {
  const saved = localStorage.getItem(KEY);
  if (saved === null) {
    const seeded = [{ id: 'sample-1', title: 'Review the design', done: false }];
    localStorage.setItem(KEY, JSON.stringify(seeded));
    return seeded;
  }
  const parsed: unknown = JSON.parse(saved);
  if (!Array.isArray(parsed) || parsed.some(item => !item || typeof item.id !== 'string' || typeof item.title !== 'string' || typeof item.done !== 'boolean')) {
    throw new Error('Saved demo data could not be read. Your existing data has not been overwritten.');
  }
  return parsed;
}
function title(value: string): string {
  const result = value.trim();
  if (!result || result.length > 120) throw new Error('Enter a title between 1 and 120 characters.');
  return result;
}
export const items: ItemService = {
  async list() { return read(); },
  async create(value) {
    const row = { id: crypto.randomUUID(), title: title(value), done: false };
    localStorage.setItem(KEY, JSON.stringify([...read(), row]));
    return row;
  },
  async update(id, changes) {
    const rows = read();
    if (!rows.some(row => row.id === id)) throw new Error('This item no longer exists. Reload and try again.');
    localStorage.setItem(KEY, JSON.stringify(rows.map(row => row.id === id ? { ...row, ...changes, title: changes.title === undefined ? row.title : title(changes.title) } : row)));
  },
  async remove(id) { localStorage.setItem(KEY, JSON.stringify(read().filter(row => row.id !== id))); }
};
