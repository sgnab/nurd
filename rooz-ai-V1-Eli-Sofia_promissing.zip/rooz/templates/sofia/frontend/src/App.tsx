import { FormEvent, useEffect, useRef, useState } from 'react';
import { Item, items } from './services/items';

export default function App() {
  const [rows, setRows] = useState<Item[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [value, setValue] = useState('');
  const [editing, setEditing] = useState<string | null>(null);
  const [notice, setNotice] = useState('');
  const dialog = useRef<HTMLDialogElement>(null);
  async function load() {
    setLoading(true); setError('');
    try { setRows(await items.list()); }
    catch (e) { setError(e instanceof Error ? e.message : 'Demo data could not be loaded.'); }
    finally { setLoading(false); }
  }
  useEffect(() => { void load(); }, []);
  function open(row?: Item) { setEditing(row?.id || null); setValue(row?.title || ''); setError(''); dialog.current?.showModal(); }
  async function save(event: FormEvent) {
    event.preventDefault(); setError('');
    try {
      if (editing) await items.update(editing, { title: value }); else await items.create(value);
      dialog.current?.close(); await load(); setNotice('Saved locally');
    } catch (e) { setError(e instanceof Error ? e.message : 'Save failed.'); }
  }
  async function toggle(row: Item) { try { await items.update(row.id, { done: !row.done }); await load(); } catch (e) { setError(String(e)); } }
  async function remove(row: Item) {
    if (!window.confirm(`Delete “${row.title}”?`)) return;
    try { await items.remove(row.id); await load(); setNotice('Deleted locally'); } catch (e) { setError(String(e)); }
  }
  return <main className="demo-shell">
    <header><div><span className="sample-label">FRONTEND STARTER · MOCK DATA</span><h1>Make room for good work.</h1><p>A small interactive starting point. Replace it with the requested product and its tests.</p></div><button onClick={() => open()}>Add item</button></header>
    {error && <div role="alert" className="error">{error}<button onClick={() => void load()}>Retry</button></div>}
    <p role="status" className="notice">{loading ? 'Loading demo items…' : notice}</p>
    {!loading && !error && (rows.length ? <ul className="items">{rows.map(row => <li key={row.id}><label><input type="checkbox" checked={row.done} onChange={() => void toggle(row)} /><span className={row.done ? 'done' : ''}>{row.title}</span></label><div className="actions"><button className="secondary" onClick={() => open(row)} aria-label={`Edit ${row.title}`}>Edit</button><button className="secondary" onClick={() => void remove(row)} aria-label={`Delete ${row.title}`}>Delete</button></div></li>)}</ul> : <section className="empty"><h2>No items yet</h2><p>Create an item to start your demo.</p></section>)}
    <dialog ref={dialog} aria-labelledby="item-title"><form onSubmit={save}><h2 id="item-title">{editing ? 'Edit item' : 'New item'}</h2><label htmlFor="title">Title</label><input id="title" value={value} onChange={event => setValue(event.target.value)} maxLength={120} required autoFocus />{error && <p role="alert" className="error">{error}</p>}<div className="form-actions"><button type="button" className="secondary" onClick={() => dialog.current?.close()}>Cancel</button><button type="submit">Save item</button></div></form></dialog>
    <footer>Demo records stay in this browser. No business backend or real-provider integration is implemented.</footer>
  </main>;
}
