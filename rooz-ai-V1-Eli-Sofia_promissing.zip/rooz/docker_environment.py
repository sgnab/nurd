"""Shared Docker availability check based on execution, not image metadata."""
import asyncio,re,shutil,uuid

class DockerError(RuntimeError):pass

async def docker_command(*args,timeout=15,check=True):
 if not shutil.which('docker'):raise DockerError('Docker is not installed or is not on this server process\'s PATH. Start Docker Desktop and restart Rooz-AI from that Terminal.')
 process=await asyncio.create_subprocess_exec('docker',*args,stdout=asyncio.subprocess.PIPE,stderr=asyncio.subprocess.STDOUT)
 try:
  async with asyncio.timeout(timeout):output,_=await process.communicate()
 except (TimeoutError,asyncio.CancelledError):
  if process.returncode is None:process.kill()
  await process.wait();raise
 text=output.decode(errors='replace')[-12000:]
 if check and process.returncode:raise DockerError(text.strip() or 'Docker command failed (exit '+str(process.returncode)+')')
 return process.returncode,text

async def image_capability(image,command=None):
 """Start fixed Python in the configured image. No workspace, secrets or network."""
 command=command or docker_command;name='rooz-probe-'+uuid.uuid4().hex[:16];token='ROOZ_IMAGE_READY_'+uuid.uuid4().hex
 phase='daemon check';started=False
 try:
  await command('info','--format','{{.ServerVersion}}',timeout=6)
  phase='image execution probe';started=True
  try:
   code,output=await command('run','--rm','--pull=never','--name',name,
    '--network','none','--read-only','--cap-drop','ALL','--security-opt','no-new-privileges',
    '--pids-limit','64','--memory','128m','--cpus','0.5','--entrypoint','python',
    image,'-c','print('+repr(token)+')',check=False,timeout=12)
  except BaseException:
   # The CLI can be interrupted while its daemon-side container is still alive.
   try:await command('rm','-f',name,timeout=6,check=False)
   except (DockerError,OSError,TimeoutError):pass
   raise
  if code==0 and token in output.splitlines():return {'ready':True,'reason':'','checked_by':'container-execution'}
  if code and re.search(r'no such image|unable to find image',output,re.I):
   return {'ready':False,'reason':'Docker could not start the local image '+image+':\n'+output.strip()+'\nBuild it with: docker build -t '+image+' -f sandbox/Dockerfile .','checked_by':'container-execution'}
  return {'ready':False,'reason':'Docker image execution probe failed (exit '+str(code)+'):\n'+(output.strip() or 'No readiness marker returned.'),'checked_by':'container-execution'}
 except (DockerError,OSError,TimeoutError) as exc:
  detail=str(exc).strip() or ('Docker '+phase+' timed out.')
  return {'ready':False,'reason':detail,'checked_by':'container-execution' if started else 'daemon-check'}
