"""Room-scoped, immutable reference files; never mounted into executable workspaces."""
import base64,hashlib,io,re
from pathlib import Path
from PIL import Image,ImageOps,UnidentifiedImageError
from .storage import identifier,now

MAX_FILES=8
MAX_FILE_BYTES=10*1024*1024
MAX_TOTAL_BYTES=20*1024*1024
MAX_TEXT_BYTES=1024*1024
TEXT_EXTENSIONS={'.py','.js','.jsx','.ts','.tsx','.html','.css','.md','.markdown','.json','.txt','.yaml','.yml','.csv','.sql','.toml','.ini','.sh','.xml','.log'}
IMAGE_EXTENSIONS={'.png':'PNG','.jpg':'JPEG','.jpeg':'JPEG','.webp':'WEBP'}
ACCEPT=','.join(sorted(TEXT_EXTENSIONS|set(IMAGE_EXTENSIONS)))

class AttachmentError(ValueError):pass

class Attachments:
 def __init__(self,store):
  self.store=store;self.root=store.root/'attachments';self.root.mkdir(exist_ok=True)
 def public(self,row):
  fields={k:row[k] for k in ('id','chat_id','message_id','filename','kind','content_type','size','created')}
  fields['download_url']='/api/chats/'+row['chat_id']+'/attachments/'+row['id']+'/download'
  fields['thumbnail_url']=('/api/chats/'+row['chat_id']+'/attachments/'+row['id']+'/thumbnail') if row['kind']=='image' else None
  return fields
 def get(self,chat,attachment_id,*,bound=False):
  self.store.chat(chat)
  with self.store.db() as c:row=c.execute('SELECT * FROM attachments WHERE id=? AND chat_id=?',(attachment_id,chat)).fetchone()
  if not row or (bound and not row['message_id']):raise KeyError('Attachment not available in this room')
  return dict(row)
 def list(self,chat,*,pending=False):
  self.store.chat(chat)
  with self.store.db() as c:rows=c.execute('SELECT * FROM attachments WHERE chat_id=? AND message_id IS '+('NULL' if pending else 'NOT NULL')+' ORDER BY rowid',(chat,)).fetchall()
  return [self.public(dict(r)) for r in rows]
 def original_path(self,row):return self.root/(row['id']+'.bin')
 def image_path(self,row):return self.root/(row['id']+'.jpg')
 def prepare(self,filename,data):
  if not isinstance(filename,str) or not filename or len(filename)>160 or re.search(r'[/\\\x00-\x1f\x7f]',filename) or filename in ('.','..'):
   raise AttachmentError('Use a plain filename without folder paths')
  if not data:raise AttachmentError(filename+': the file is empty')
  if len(data)>MAX_FILE_BYTES:raise AttachmentError(filename+': maximum file size is 10 MB')
  suffix=Path(filename).suffix.casefold();image=None
  if suffix in IMAGE_EXTENSIONS:
   try:
    with Image.open(io.BytesIO(data)) as source:
     if source.format!=IMAGE_EXTENSIONS[suffix]:raise AttachmentError(filename+': image bytes do not match the filename type')
     if source.width*source.height>20_000_000:raise AttachmentError(filename+': image must be at most 20 megapixels')
     source.verify()
    with Image.open(io.BytesIO(data)) as source:
     pixels=ImageOps.exif_transpose(source);pixels.thumbnail((2048,2048))
     if pixels.mode in ('RGBA','LA') or 'transparency' in pixels.info:
      rgba=pixels.convert('RGBA');canvas=Image.new('RGB',rgba.size,'white');canvas.paste(rgba,mask=rgba.getchannel('A'));pixels=canvas
     else:pixels=pixels.convert('RGB')
     output=io.BytesIO();pixels.save(output,'JPEG',quality=90);image=output.getvalue()
     if len(image)>4*1024*1024:raise AttachmentError(filename+': normalized image is too large; use a smaller screenshot')
   except (UnidentifiedImageError,OSError,Image.DecompressionBombError) as exc:
    raise AttachmentError(filename+': not a readable PNG, JPEG or WebP image') from exc
   kind='image';mime={'PNG':'image/png','JPEG':'image/jpeg','WEBP':'image/webp'}[IMAGE_EXTENSIONS[suffix]]
  elif suffix in TEXT_EXTENSIONS:
   if len(data)>MAX_TEXT_BYTES:raise AttachmentError(filename+': text/code files must be at most 1 MB')
   try:text=data.decode('utf-8-sig')
   except UnicodeError as exc:raise AttachmentError(filename+': save this text file as UTF-8') from exc
   if '\x00' in text:raise AttachmentError(filename+': binary data is not a supported text attachment')
   kind='text';mime='text/plain; charset=utf-8'
  else:raise AttachmentError(filename+': use a supported code/text file or PNG, JPEG or WebP image')
  return {'id':identifier(),'filename':filename,'kind':kind,'content_type':mime,'size':len(data),'data':data,'image':image,'sha256':hashlib.sha256(data).hexdigest()}
 def save(self,chat,files):
  self.store.chat(chat)
  if not 1<=len(files)<=MAX_FILES:raise AttachmentError('Attach 1–8 files per message')
  if sum(len(data) for _,data in files)>MAX_TOTAL_BYTES:raise AttachmentError('Attachments must total at most 20 MB per message')
  prepared=[self.prepare(filename,data) for filename,data in files];written=[];saved=[]
  try:
   with self.store.db() as c:
    c.execute('BEGIN IMMEDIATE')
    pending=c.execute('SELECT count(*),coalesce(sum(size),0) FROM attachments WHERE chat_id=? AND message_id IS NULL',(chat,)).fetchone()
    if pending[0]+len(prepared)>MAX_FILES:raise AttachmentError('This message already has attachments; remove some to stay within eight files')
    if pending[1]+sum(p['size'] for p in prepared)>MAX_TOTAL_BYTES:raise AttachmentError('Attachments must total at most 20 MB per message')
    for item in prepared:
     row={**item,'chat_id':chat,'message_id':None,'created':now()}
     saved.append(row)
     original=self.original_path(row);original.write_bytes(item['data']);written.append(original)
     if item['image'] is not None:
      view=self.image_path(row);view.write_bytes(item['image']);written.append(view)
     c.execute('INSERT INTO attachments(id,chat_id,message_id,filename,kind,content_type,size,sha256,created) VALUES(?,?,?,?,?,?,?,?,?)',
       (item['id'],chat,None,item['filename'],item['kind'],item['content_type'],item['size'],item['sha256'],row['created']))
   return [self.public(row) for row in saved]
  except BaseException:
   for path in written:path.unlink(missing_ok=True)
   raise
 def remove_pending(self,chat,attachment_id):
  with self.store.db() as c:
   c.execute('BEGIN IMMEDIATE');row=c.execute('SELECT * FROM attachments WHERE id=? AND chat_id=?',(attachment_id,chat)).fetchone()
   if not row:raise KeyError('Attachment not available in this room')
   row=dict(row)
   if row['message_id']:raise AttachmentError('Sent attachments remain with the room; only unsent attachments can be removed')
   self.original_path(row).unlink(missing_ok=True);self.image_path(row).unlink(missing_ok=True)
   c.execute('DELETE FROM attachments WHERE id=?',(attachment_id,))
 def for_run(self,chat,run):
  with self.store.db() as c:
   rows=c.execute("SELECT a.* FROM attachments a JOIN messages m ON m.id=a.message_id WHERE a.chat_id=? AND m.chat_id=? AND m.run_id=? AND m.role='user' ORDER BY a.rowid",(chat,chat,run)).fetchall()
   message=c.execute("SELECT id,content FROM messages WHERE chat_id=? AND run_id=? AND role='user' ORDER BY rowid LIMIT 1",(chat,run)).fetchone()
  return (dict(message) if message else None),[dict(r) for r in rows]
 def text(self,row,offset=0,limit=20000):
  if row['kind']!='text':return self.public(row)
  if type(offset) is not int or type(limit) is not int or offset<0 or not 1<=limit<=60000:raise AttachmentError('Use offset >= 0 and a limit of 1–60000 characters')
  text=self.original_path(row).read_bytes().decode('utf-8-sig')
  if offset>len(text):raise AttachmentError('Offset is past the end of this attachment')
  chunk=text[offset:offset+limit]
  return {**self.public(row),'text':chunk,'offset':offset,'total_characters':len(text),'next_offset':offset+len(chunk) if offset+len(chunk)<len(text) else None}
 def message_parts(self,rows,intro,*,responses):
  text_kind='input_text' if responses else 'text';parts=[{'type':text_kind,'text':intro}]
  for row in rows:
   info=self.public(row)
   if row['kind']=='text':
    view=self.text(row,0,8000)
    label=json_text(info)+'\nText reference excerpt:\n'+view['text']
    if view['next_offset'] is not None:label+='\n[Excerpt truncated; use read_attachment at offset '+str(view['next_offset'])+' to continue.]'
    parts.append({'type':text_kind,'text':label})
   else:
    parts.append({'type':text_kind,'text':'Image reference (actual image follows; model view max 2048 px): '+json_text(info)})
    url='data:image/jpeg;base64,'+base64.b64encode(self.image_path(row).read_bytes()).decode('ascii')
    parts.append({'type':'input_image','image_url':url,'detail':'auto'} if responses else {'type':'image_url','image_url':{'url':url,'detail':'auto'}})
  return parts

def json_text(value):
 import json
 return json.dumps(value,ensure_ascii=False)
