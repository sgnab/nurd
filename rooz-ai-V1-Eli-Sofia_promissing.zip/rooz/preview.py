"""User-controlled static previews; independent of agent tools and test execution."""
import asyncio,hashlib,json,os,re,shutil,time,uuid
from pathlib import Path
from html.parser import HTMLParser
from urllib.parse import urlsplit
import httpx
from .preview_server import PUBLIC_EXTENSIONS
from .docker_environment import DockerError as PreviewError,docker_command,image_capability
from .app_profile import FULLSTACK_ENTRY,profile,source_files


def static_files(root):
 """Read only public assets, excluding hidden paths, links and dependency trees."""
 files={};total=0
 for directory,dirs,names in os.walk(root,followlinks=False):
  folder=Path(directory)
  dirs[:]=sorted(d for d in dirs if not d.startswith('.') and d not in ('node_modules','__pycache__','venv') and not (folder/d).is_symlink())
  for name in sorted(names):
   source=folder/name
   if name.startswith('.') or source.is_symlink() or source.suffix.lower() not in PUBLIC_EXTENSIONS:continue
   if source.stat().st_size>10*1024*1024:raise PreviewError('Static preview files must be at most 10 MB each: '+source.relative_to(root).as_posix())
   content=source.read_bytes();total+=len(content)
   if total>50*1024*1024 or len(files)>=1000:raise PreviewError('This static preview exceeds 50 MB or 1,000 files. Choose a smaller project.')
   files[source.relative_to(root).as_posix()]=content
 return files

def revision(files):
 return hashlib.sha256(json.dumps([(p,hashlib.sha256(b).hexdigest()) for p,b in sorted(files.items())]).encode()).hexdigest()

def entries(files):
 return sorted((p for p in files if Path(p).suffix.lower() in ('.html','.htm')),key=lambda p:(p!='index.html',Path(p).name!='index.html',len(Path(p).parts),p))

def requires_build(content):
 class Scripts(HTMLParser):
  needed=False
  def handle_starttag(self,tag,attrs):
   if tag=='script':
    src=dict(attrs).get('src') or ''
    if Path(urlsplit(src).path).suffix.lower() in ('.jsx','.tsx','.ts'):self.needed=True
 parser=Scripts();parser.feed(content.decode('utf-8',errors='replace'));return parser.needed

class DockerPreview:
 def __init__(self,image=None):
  self.image=image or os.getenv('ROOZ_RUNNER_IMAGE','rooz-ai-runner:stage1');self.port_timeout=12
 async def command(self,*args,timeout=15,check=True):
  return await docker_command(*args,timeout=timeout,check=check)
 async def capability(self):
  return await image_capability(self.image,self.command)
 async def wait_port(self,name,stop=None):
  deadline=time.monotonic()+self.port_timeout;last='Port mapping is not published yet'
  while True:
   if stop and stop.is_set():raise asyncio.CancelledError()
   _,raw=await self.command('inspect','--format','{{json .NetworkSettings.Ports}}',name,timeout=3)
   try:
    bindings=json.loads(raw).get('8080/tcp') or []
    for binding in bindings:
     port=int(binding['HostPort'])
     if binding['HostIp']=='127.0.0.1' and 1<=port<=65535:return 'http://127.0.0.1:'+str(port)+'/'
    if bindings:raise PreviewError('Docker published no safe IPv4 loopback preview port; refusing a non-loopback binding')
   except (ValueError,TypeError,KeyError,AttributeError):last='Docker returned an incomplete preview port mapping'
   _,state_raw=await self.command('inspect','--format','{{json .State}}',name,timeout=3)
   try:
    state=json.loads(state_raw)
    if state.get('Status') in ('exited','dead'):
     raise PreviewError('Preview container '+state['Status']+' before publishing its local port (exit '+str(state.get('ExitCode','unknown'))+'). See container logs below.')
   except (ValueError,TypeError,AttributeError):pass
   if time.monotonic()>=deadline:raise PreviewError(last+' after '+str(self.port_timeout)+' seconds. Container startup did not publish port 8080 on 127.0.0.1; see container logs below.')
   await asyncio.sleep(.15)
 async def launch(self,name,snapshot,entry,session,owner,port=None,stop=None):
  if port is not None and (type(port) is not int or not 1<=port<=65535):raise PreviewError('Invalid saved preview port')
  document_root=Path('/work')/Path(entry).parent
  # Retain an exited container until we read its startup logs, then remove it.
  await self.command('run','-d','--pull=never','--name',name,'--label','rooz.preview.owner='+owner,
   '--read-only','--cap-drop','ALL','--security-opt','no-new-privileges','--pids-limit','64','--memory','256m','--cpus','0.5',
   '--user',str(os.getuid())+':'+str(os.getgid()),'--tmpfs','/tmp:rw,nosuid,size=32m',
   '-p','127.0.0.1:'+('' if port is None else str(port))+':8080','-v',str(snapshot.resolve())+':/work:ro',
   '-v',str(Path(__file__).with_name('preview_server.py').resolve())+':/opt/rooz-preview.py:ro',
   '-e','PYTHONDONTWRITEBYTECODE=1',self.image,'python','-u','/opt/rooz-preview.py',
   '--root',str(document_root),'--entry',Path(entry).name,'--session',session)
  return await self.wait_port(name,stop)
 async def running(self,name):
  code,text=await self.command('inspect','--format','{{.State.Running}}',name,check=False,timeout=6)
  return code==0 and text.strip()=='true'
 async def launch_fullstack(self,name,snapshot,settings,data,session,owner,port=None,stop=None):
  if port is not None and (type(port) is not int or not 1<=port<=65535):raise PreviewError('Invalid saved preview port')
  await self.command('run','-d','--pull=never','--name',name,'--label','rooz.preview.owner='+owner,
   '--read-only','--cap-drop','ALL','--security-opt','no-new-privileges','--pids-limit','256','--memory','1g','--cpus','1',
   '--user',str(os.getuid())+':'+str(os.getgid()),'--tmpfs','/tmp:rw,nosuid,size=128m,mode=1777',
   '--tmpfs','/work:rw,nosuid,size=256m,mode=1777',
   '-p','127.0.0.1:'+('' if port is None else str(port))+':8080',
   '-v',str(snapshot.resolve())+':/source:ro','-v',str(data.resolve())+':/data:rw',
   '-e','PYTHONDONTWRITEBYTECODE=1','-e','HOME=/tmp',
   self.image,'python','-u','/opt/rooz/fullstack_server.py','--source','/source','--session',session,'--profile',json.dumps(settings))
  return await self.wait_port(name,stop)
 async def logs(self,name):
  code,text=await self.command('logs','--tail','60',name,check=False,timeout=6)
  return text if code==0 else ''
 async def remove(self,name):
  code,text=await self.command('rm','-f',name,check=False,timeout=8)
  if code and 'No such container' not in text:raise PreviewError(text.strip() or 'Docker could not stop the preview')

class PreviewService:
 def __init__(self,store,backend=None):
  self.store=store;self.backend=backend or DockerPreview();self.root=store.root/'previews';self.root.mkdir(exist_ok=True)
  self.states={};self.locks={};self.stops={};self.ready_timeout=10;self.app_ready_timeout=150;self.owner=hashlib.sha256(str(store.root.resolve()).encode()).hexdigest()[:16]
  for path in self.root.glob('*.json'):
   try:
    row=json.loads(path.read_text())
    if re.fullmatch(r'[a-f0-9]{32}',path.stem):self.states[path.stem]=row
   except (ValueError,OSError):continue
 def empty(self,chat):return {'chat_id':chat,'status':'stopped','url':None,'entry':'','revision':None,'error':'','logs':'','name':None,'session':None,'port':None,'mode':'static'}
 def data_path(self,chat):
  self.store.chat(chat)
  if not re.fullmatch(r'[a-f0-9]{32}',chat):raise PreviewError('Invalid preview data identity')
  return self.root/'app-data'/chat
 def sources(self,root,fullstack=False):
  files=static_files(root);options=entries(files);settings=None;source_error=''
  try:settings=profile(root)
  except (ValueError,OSError) as exc:source_error='Full-stack preview: '+str(exc)
  if settings:options=[FULLSTACK_ENTRY,*options]
  if fullstack:
   if not settings:raise PreviewError(source_error or 'No supported full-stack app found. Use frontend/package.json and backend/main.py, or rooz-preview.json.')
   files=source_files(root)
  return files,options,settings,source_error
 def save(self,chat,row):
  self.states[chat]=row;path=self.root/(chat+'.json');temp=path.with_suffix('.tmp');temp.write_text(json.dumps(row));temp.replace(path)
 def lock(self,chat):return self.locks.setdefault(chat,asyncio.Lock())
 def snapshot_path(self,row):
  session=row.get('session','')
  if not isinstance(session,str) or not re.fullmatch(r'[a-f0-9]{32}',session):return None
  return self.root/'snapshots'/session
 async def cleanup(self,row):
  name=row.get('name')
  if name:
   if not re.fullmatch(r'rooz-preview-'+self.owner+r'-[a-f0-9]{16}',name):raise PreviewError('Saved preview container identity is invalid')
   await self.backend.remove(name)
  snapshot=self.snapshot_path(row)
  if snapshot:shutil.rmtree(snapshot,ignore_errors=True)
 async def recover(self):
  # Interrupted previews are explicitly stopped; no old run is silently resumed.
  for chat in list(self.states):
   row=self.states[chat]
   if row.get('name') or self.snapshot_path(row) or row.get('status') in ('starting','running'):
    try:
     await self.cleanup(row);self.save(chat,{**self.empty(chat),'entry':row.get('entry',''),'logs':row.get('logs',''),'error':'Server restarted. Start Preview to open a fresh snapshot.'})
    except (PreviewError,OSError,TimeoutError) as exc:self.save(chat,{**row,'status':'error','url':None,'error':'Could not clean up the previous preview: '+str(exc)})
 async def shutdown(self):
  for event in self.stops.values():event.set()
  for chat in list(self.states):
   try:await self.stop(chat)
   except (PreviewError,OSError,TimeoutError):pass
 async def describe(self,chat):
  selected=self.store.chat(chat);root=self.store.workspace(selected['project_id'])
  try:
   active=self.states.get(chat,self.empty(chat))
   files,options,settings,source_error=await asyncio.to_thread(self.sources,root,active.get('entry')==FULLSTACK_ENTRY)
   current=revision(files)
  except (PreviewError,OSError) as exc:options=[];current=None;source_error=str(exc)
  row=self.states.get(chat,self.empty(chat))
  if row['status']=='running' and not self.lock(chat).locked():
   async with self.lock(chat):
    row=self.states.get(chat,self.empty(chat))
    if row['status']=='running':
     try:
      if not await self.backend.running(row['name']):
       logs=await self.backend.logs(row['name']);row={**row,'status':'error','url':None,'error':'Preview container stopped. Start Preview to retry.','logs':logs or row['logs']};self.save(chat,row)
     except (PreviewError,OSError,TimeoutError) as exc:
      row={**row,'status':'error','url':None,'error':'Preview status could not be checked: '+str(exc)};self.save(chat,row)
  row=self.states.get(chat,row)
  return {k:v for k,v in row.items() if k not in ('name','session')}|{'entries':options,'source_error':source_error,'stale':bool(row.get('revision') and current!=row['revision'])}
 async def start(self,chat,entry='',refresh=False):
  selected=self.store.chat(chat)
  async with self.lock(chat):
   previous=self.states.get(chat,self.empty(chat))
   if not entry and previous.get('mode','static')=='static':
    try:
     if profile(self.store.workspace(selected['project_id'])):entry=FULLSTACK_ENTRY
    except (ValueError,OSError):pass
   if previous['status']=='running' and not refresh and (not entry or entry==previous.get('entry')):
    if await self.backend.running(previous['name']):return await self.describe(chat)
   event=asyncio.Event();self.stops[chat]=event;row={**previous,'status':'starting','url':None,'error':''};self.save(chat,row)
   try:
    await self.cleanup(previous)
    root=self.store.workspace(selected['project_id'])
    files,options,settings,source_error=await asyncio.to_thread(self.sources,root)
    entry=entry or (FULLSTACK_ENTRY if settings else previous.get('entry')) or (options[0] if options else '')
    if entry not in options:raise PreviewError(source_error or 'Save a plain HTML file or a supported full-stack app in Project files. Uploaded references are separate from project code.')
    fullstack=entry==FULLSTACK_ENTRY
    if fullstack:files=await asyncio.to_thread(source_files,root)
    elif requires_build(files[entry]):
     raise PreviewError('This HTML entry needs a build step. Choose Full-stack app if available, or save a built static HTML entry.')
    capability=await self.backend.capability()
    if not capability['ready']:raise PreviewError(capability['reason'])
    if event.is_set():raise asyncio.CancelledError()
    session=uuid.uuid4().hex;name='rooz-preview-'+self.owner+'-'+session[:16]
    row={**self.empty(chat),'status':'starting','entry':entry,'revision':revision(files),'name':name,'session':session,'mode':'fullstack' if fullstack else 'static'};self.save(chat,row)
    snapshot=self.snapshot_path(row);snapshot.mkdir(parents=True)
    for path,content in files.items():
     target=snapshot/path;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(content);target.chmod(0o644)
    snapshot.chmod(0o755)
    for path in snapshot.rglob('*'):
     if path.is_dir():path.chmod(0o755)
    # Keep the browser origin on Refresh so localStorage/IndexedDB survive it.
    port=previous.get('port') if previous.get('entry')==entry else None
    if fullstack:
     data=self.data_path(chat);data.mkdir(parents=True,exist_ok=True)
     url=await self.backend.launch_fullstack(name,snapshot,settings,data,session,self.owner,port=port,stop=event)
    else:url=await self.backend.launch(name,snapshot,entry,session,self.owner,port=port,stop=event)
    timeout=self.app_ready_timeout if fullstack else self.ready_timeout
    deadline=time.monotonic()+timeout
    async with httpx.AsyncClient(trust_env=False,timeout=1) as client:
     while True:
      if event.is_set():raise asyncio.CancelledError()
      try:
       response=await client.get(url+'__rooz_health')
       if response.status_code==200 and response.json().get('preview')==session:break
      except (httpx.HTTPError,ValueError):pass
      if not await self.backend.running(name):raise PreviewError('Preview exited during startup. See the build/backend logs below. If fullstack_server.py is missing, run bash setup.sh to rebuild the image.')
      if time.monotonic()>deadline:raise PreviewError('Preview did not become ready within '+str(timeout)+' seconds. See the container logs below.')
      await asyncio.sleep(.15)
    row={**row,'status':'running','url':url,'port':urlsplit(url).port,'logs':await self.backend.logs(name)};self.save(chat,row)
   except BaseException as exc:
    if isinstance(exc,(KeyboardInterrupt,SystemExit)):raise
    cancelled=isinstance(exc,asyncio.CancelledError)
    try:
     if row.get('name'):row['logs']=await self.backend.logs(row['name'])
    except (PreviewError,OSError,TimeoutError):pass
    cleanup_error=''
    try:await self.cleanup(row)
    except (PreviewError,OSError,TimeoutError) as cleanup_exc:cleanup_error=' Cleanup failed: '+str(cleanup_exc)
    row={**row,'status':'stopped' if cancelled and not cleanup_error else 'error','url':None,
     'error':('' if cancelled else str(exc) or type(exc).__name__)+cleanup_error}
    if not cleanup_error:row.update(name=None,session=None)
    self.save(chat,row)
    if cancelled and not event.is_set():raise
   return await self.describe(chat)
 async def stop(self,chat):
  self.store.chat(chat)
  if chat in self.stops:self.stops[chat].set()
  async with self.lock(chat):
   row=self.states.get(chat,self.empty(chat))
   try:
    if row.get('name'):
     try:row['logs']=await self.backend.logs(row['name'])
     except (PreviewError,OSError,TimeoutError):pass
    await self.cleanup(row)
    row={**row,'status':'stopped','url':None,'name':None,'session':None,'error':''}
   except (PreviewError,OSError,TimeoutError) as exc:row={**row,'status':'error','url':None,'error':'Could not stop preview: '+str(exc)}
   self.save(chat,row)
  return await self.describe(chat)
 async def read_logs(self,chat):
  self.store.chat(chat)
  row=self.states.get(chat,self.empty(chat))
  if row.get('name'):
   try:return {'logs':await self.backend.logs(row['name']),'error':''}
   except (PreviewError,OSError,TimeoutError) as exc:return {'logs':row.get('logs',''),'error':'Could not read preview logs: '+str(exc)}
  return {'logs':row.get('logs',''),'error':''}
 async def reset_data(self,chat):
  await self.stop(chat)
  async with self.lock(chat):
   row=self.states.get(chat,self.empty(chat))
   if row.get('name'):raise PreviewError('Stop the preview successfully before resetting its data')
   shutil.rmtree(self.data_path(chat),ignore_errors=False) if self.data_path(chat).exists() else None
  return await self.describe(chat)
