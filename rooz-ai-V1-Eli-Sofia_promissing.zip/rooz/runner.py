"""One disposable execution environment for every agent; no host-code execution."""
import asyncio,os,shutil,tempfile,time,uuid
from pathlib import Path
from .docker_environment import image_capability
from .visual import collect_screenshots,SCREENSHOT_FOLDER

class DockerRunner:
    def __init__(self,image='rooz-ai-runner:stage1',timeout=180):self.image=image;self.timeout=timeout
    async def capability(self):
        return await image_capability(self.image)
    async def run(self,workspace,command,stop):
        if not isinstance(command,list) or not command or any(not isinstance(a,str) or '\x00' in a for a in command):raise ValueError('Command must be an argument list')
        if command[0] not in ('python','python3','node','pytest','npm','npx'):raise ValueError('Use python, node, pytest, npm or npx inside the test environment')
        capability=await self.capability()
        if not capability['ready']:return {'status':'unavailable','command':command,'exit_code':None,'output':capability['reason'],'kind':'requested checks'}
        if stop.is_set():raise asyncio.CancelledError()
        name='rooz-test-'+uuid.uuid4().hex[:16];started=time.monotonic();proc=None
        with tempfile.TemporaryDirectory(prefix='rooz-test-') as directory:
            staged=Path(directory)/'project';shutil.copytree(workspace,staged,ignore=shutil.ignore_patterns('.env*','.git','node_modules','__pycache__'))
            captures=staged/SCREENSHOT_FOLDER
            if captures.is_symlink():captures.unlink()
            elif captures.exists():shutil.rmtree(captures)
            captures.mkdir()
            args=['docker','run','--rm','--name',name,'--network','none','--read-only','--cap-drop','ALL',
                  '--security-opt','no-new-privileges','--pids-limit','256','--memory','1g','--cpus','1',
                  '--shm-size','256m','--tmpfs','/tmp:rw,nosuid,size=256m','--user',str(os.getuid())+':'+str(os.getgid()),
                  '-e','HOME=/tmp','-e','PYTHONDONTWRITEBYTECODE=1','-e','PYTHONPATH=/work',
                  '-e','ROOZ_SCREENSHOT_DIR=/work/'+SCREENSHOT_FOLDER,
                  '-v',str(staged)+':/work:rw','-w','/work',self.image,'python','/opt/rooz/execute.py',*command]
            output=bytearray()
            async def collect(stream):
                while chunk:=await stream.read(4096):
                    output.extend(chunk)
                    if len(output)>24000:del output[:-24000]
            async def remove():
                cleanup=await asyncio.create_subprocess_exec('docker','rm','-f',name,stdout=asyncio.subprocess.DEVNULL,stderr=asyncio.subprocess.DEVNULL)
                try:
                    async with asyncio.timeout(8):await cleanup.wait()
                except TimeoutError:cleanup.kill();await cleanup.wait()
            reader=None
            try:
                proc=await asyncio.create_subprocess_exec(*args,stdout=asyncio.subprocess.PIPE,stderr=asyncio.subprocess.STDOUT)
                reader=asyncio.create_task(collect(proc.stdout))
                while proc.returncode is None:
                    if stop.is_set():raise asyncio.CancelledError()
                    if time.monotonic()-started>self.timeout:raise TimeoutError()
                    try:await asyncio.wait_for(proc.wait(),.2)
                    except TimeoutError:pass
                await reader
                decoded=output.decode('utf-8',errors='replace')
                if proc.returncode and "can't open file '/opt/rooz/execute.py'" in decoded:
                    return {'status':'unavailable','exit_code':proc.returncode,'command':command,
                            'output':'The runner image predates Stage 1.8. Rebuild it once: docker build -t rooz-ai-runner:stage1 -f sandbox/Dockerfile .\n'+decoded,
                            'kind':'requested checks'}
                return {'status':'passed' if proc.returncode==0 else 'failed','exit_code':proc.returncode,
                        'command':command,'output':decoded,'elapsed_seconds':round(time.monotonic()-started,2),'kind':'requested checks',
                        '_screenshots':collect_screenshots(staged)}
            except TimeoutError:
                await remove()
                if proc and proc.returncode is None:proc.kill();await proc.wait()
                return {'status':'failed','exit_code':None,'command':command,'output':'Test exceeded '+str(self.timeout)+' seconds.\n'+output.decode('utf-8',errors='replace'),'kind':'requested checks',
                        '_screenshots':collect_screenshots(staged)}
            except asyncio.CancelledError:
                await remove()
                if proc and proc.returncode is None:proc.kill();await proc.wait()
                raise
            finally:
                if reader and not reader.done():reader.cancel();await asyncio.gather(reader,return_exceptions=True)
