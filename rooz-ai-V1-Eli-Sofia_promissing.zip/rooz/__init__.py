"""Rooz-AI: small, independently replaceable application components."""
