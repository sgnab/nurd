"""Shared-room addressing and sequential collaboration policy. No model or Docker code."""
import json,re

AGENT_IDS=('alex','sofia','eli')
NAMES={'alex':'Alex','sofia':'Sofia','eli':'Eli'}
MAX_HANDOFFS=12
MAX_DEPTH=6


def agent_id(value):
    if not isinstance(value,str):raise ValueError('Choose Alex, Sofia or Eli')
    key=value.strip().lstrip('@').casefold()
    if key not in AGENT_IDS:raise ValueError('Choose Alex, Sofia or Eli (names are case-insensitive)')
    return key


def recipients(message,selected='alex'):
    """Explicit @mentions, then an opening name/greeting; ordinary mentions do not call anyone."""
    text=re.sub(r'```[\s\S]*?(?:```|$)','',message)
    text=re.sub(r'`[^`]*`','',text)
    text='\n'.join(line for line in text.splitlines() if not line.lstrip().startswith('>'))
    names=[]
    for match in re.finditer(r'(?<![\w@])@(alex|sofia|eli)\b',text,re.IGNORECASE):
        name=match.group(1).casefold()
        if name not in names:names.append(name)
    if names:return names
    greeting=re.match(r'^\s*(?:(?:hey|hi|hello)\s+)?(alex|sofia|eli)(?=$|[\s,!:?.])',text,re.IGNORECASE)
    return [greeting.group(1).casefold()] if greeting else [agent_id(selected)]


def transcript(messages):
    rows=[]
    for m in messages:
        if m['role']=='handoff':
            try:
                item=json.loads(m['content'])
                text=('[Handoff '+NAMES.get(m['agent'],m['agent'])+' → '+NAMES.get(item['target'],item['target'])+
                      '; '+item.get('status','requested')+'] '+item['message'])
            except (ValueError,KeyError,TypeError):text='[Earlier team handoff] '+m['content']
            role='assistant'
        elif m['role']=='assistant':
            text='['+NAMES.get(m.get('agent'),'Rooz')+' replied] '+m['content'];role='assistant'
        else:text=m['content'];role='user'
        rows.append({'role':role,'content':text,'id':m['id']})
    return rows


class TeamSession:
    def __init__(self):
        self.count=0;self.active_edges=set();self.requests={};self.failure_saved=False
    def begin(self,caller,target,message,depth):
        target=agent_id(target)
        if target==caller:raise ValueError('You are already '+NAMES[caller]+'. Answer directly instead of calling yourself.')
        if not isinstance(message,str) or not message.strip() or len(message)>6000:
            raise ValueError('Give the teammate a clear nonempty task of at most 6000 characters')
        key=(caller,target,re.sub(r'\s+',' ',message).strip().casefold())
        if key in self.requests:
            previous=self.requests[key]
            raise ValueError('This exact teammate request was already made. Use its answer or ask a different scoped question. '+('Previous reply: '+previous[:1500] if previous else 'The teammate is still being called.'))
        if (caller,target) in self.active_edges:
            raise ValueError('This handoff edge is already waiting for an answer. Reply to the pending question instead of repeating the cycle.')
        if depth>=MAX_DEPTH:raise ValueError('The current handoff chain is six agents deep. Finish this answer so the waiting teammates can continue.')
        if self.count>=MAX_HANDOFFS:raise ValueError('This request has used twelve handoffs. Summarize the current result and ask the user for a follow-up if more work is needed.')
        self.count+=1;self.active_edges.add((caller,target));self.requests[key]=''
        return target,key
    def end(self,caller,target,key,answer=''):
        self.active_edges.discard((caller,target));self.requests[key]=answer
