# Sofia UI verification

Do not keep rediscovering dependencies. Node, React, Vite, TypeScript, Tailwind, Python Playwright,
@playwright/test and Chromium are installed. Chromium is under /ms-playwright via PLAYWRIGHT_BROWSERS_PATH.
Radix Dialog/Select and Vitest are not installed; use native controls or installed packages. No npm installs,
CDN requests or network access are available. Inspect a dependency only when actual build evidence requires it.

Save tests/verify.py as the stable fail-fast entrypoint. For React, run npm --prefix frontend run build, then
start the built application and real Chromium in a Python browser script in the SAME test command. For plain
HTML, skip the build and serve the saved page locally. The starter's backend is only a static serving adapter.
Do not add artificial data APIs to pass a frontend mock test. Label mock/UI behavior and true API integration
separately. Add small service tests where useful, not a new test framework the runner does not have.

Python: use playwright.sync_api, launch Chromium with --no-sandbox and --disable-dev-shm-usage.
Node: npx --no-install playwright test <saved spec> --workers=1. Never python -m playwright test.
Do not inspect ~/.cache/ms-playwright to decide browsers are missing; the configured path is /ms-playwright.
Each command uses a fresh disposable project: code must be saved via write_files, and builds/servers/tests
must run together. Do not build lazily inside a request handler. Stop servers in finally blocks.

Exercise the requested product: relevant create/edit/delete, navigation, search/filter/sort, invalid input,
reload persistence and visible error states. Verify local persistence when mocks are requested; avoid claiming
server persistence. Wait for concrete UI readiness using role/label locators and Playwright expect. Capture
browser page errors and failed asset responses. Replace starter assertions when changing the app, preserving
meaningful behavior coverage. A removed starter element is not proof the UI failed to load.

Capture up to four representative images directly in ROOZ_SCREENSHOT_DIR: desktop, mobile, open form and
one useful error/validation state. No horizontal page overflow; controls stay reachable; focus and Escape work.
Call verify_ui, inspect the returned actual pixels and repair defects. A passed build, environment probe or
screenshot file does not establish UI functionality or visual quality.

When a check fails, load debugging, repair the responsible source/test setup, rerun that logical check and
verify_ui on the final revision. Use rerun_check for a corrected command with its original check_id and a
clear reason preserving the intended assertions. Do not repeat obsolete probes or ask the user for routine
permission. Do not remove assertions or accept skipped/mock success as actual verification.
