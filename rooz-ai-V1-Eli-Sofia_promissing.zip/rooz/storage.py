import hashlib,json,re,sqlite3,uuid
from contextlib import contextmanager
from datetime import datetime,timezone
from pathlib import Path


def now():return datetime.now(timezone.utc).isoformat()
def identifier():return uuid.uuid4().hex

def safe_path(root,name):
    if not isinstance(name,str) or not name or len(name)>240 or '\\' in name or ':' in name:
        raise ValueError('Use a relative project filename')
    rel=Path(name)
    if rel.is_absolute() or any(p in ('.','..','.git','node_modules','__pycache__') or p.startswith('.env') for p in rel.parts):
        raise ValueError('This path cannot be read or written')
    result=(root/rel).resolve()
    if not result.is_relative_to(root.resolve()) or result==root.resolve():raise ValueError('Path leaves project workspace')
    return result


class Store:
    def __init__(self,directory):
        self.root=Path(directory);self.root.mkdir(parents=True,exist_ok=True)
        self.database=self.root/'rooz.sqlite3'
        if self.database.is_file():
            # Keep the accepted schema before applying the first team migration.
            with sqlite3.connect(self.database) as source:
                run_cols={row[1] for row in source.execute('PRAGMA table_info(runs)')}
                artifact_cols={row[1] for row in source.execute('PRAGMA table_info(artifacts)')}
                needs_backup=(run_cols and 'root_agent' not in run_cols) or (artifact_cols and 'reply_id' not in artifact_cols)
                backup=self.root/'backups'/'before-stage15.sqlite3'
                if needs_backup and not backup.exists():
                    backup.parent.mkdir(parents=True,exist_ok=True)
                    target=sqlite3.connect(backup)
                    try:source.backup(target)
                    finally:target.close()
        with self.db() as c:
            c.executescript('''
            CREATE TABLE IF NOT EXISTS projects(id TEXT PRIMARY KEY,title TEXT NOT NULL,created TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS chats(id TEXT PRIMARY KEY,project_id TEXT NOT NULL,title TEXT NOT NULL,created TEXT NOT NULL,updated TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS messages(id TEXT PRIMARY KEY,chat_id TEXT NOT NULL,role TEXT NOT NULL,agent TEXT,content TEXT NOT NULL,run_id TEXT,created TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS runs(id TEXT PRIMARY KEY,chat_id TEXT NOT NULL,project_id TEXT NOT NULL,agent TEXT NOT NULL,status TEXT NOT NULL,stage TEXT NOT NULL,checks TEXT NOT NULL DEFAULT '[]',created TEXT NOT NULL,updated TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS artifacts(id TEXT PRIMARY KEY,project_id TEXT NOT NULL,run_id TEXT NOT NULL,path TEXT NOT NULL,content TEXT NOT NULL,created TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS attachments(id TEXT PRIMARY KEY,chat_id TEXT NOT NULL,message_id TEXT,filename TEXT NOT NULL,kind TEXT NOT NULL,content_type TEXT NOT NULL,size INTEGER NOT NULL,sha256 TEXT NOT NULL,created TEXT NOT NULL);
            CREATE INDEX IF NOT EXISTS attachments_chat ON attachments(chat_id,message_id);
            CREATE INDEX IF NOT EXISTS messages_chat ON messages(chat_id,created);
            CREATE INDEX IF NOT EXISTS artifacts_project ON artifacts(project_id,created);
            ''')
            # Additive migrations preserve the accepted Stage 1 database.
            for table,column in (('runs','model'),('runs','end_reason'),('runs','root_agent'),('artifacts','agent'),('artifacts','reply_id')):
                if column not in {r[1] for r in c.execute('PRAGMA table_info('+table+')')}:
                    c.execute('ALTER TABLE '+table+' ADD COLUMN '+column+' TEXT')
            c.execute('UPDATE runs SET root_agent=agent WHERE root_agent IS NULL')
            # Older first-message naming updated only the chat. Adopt its saved
            # title for a one-chat project without moving any files or IDs.
            c.execute('''UPDATE projects SET title=(SELECT title FROM chats WHERE project_id=projects.id)
                         WHERE (SELECT count(*) FROM chats WHERE project_id=projects.id)=1''')
            for r in c.execute("SELECT * FROM runs WHERE status IN ('queued','running','stopping')").fetchall():
                c.execute("UPDATE runs SET status='interrupted',end_reason=COALESCE(end_reason,'server_restart'),stage='Server restarted; send a message to continue from saved files',updated=? WHERE id=?",(now(),r['id']))
                for event in c.execute("SELECT id,content FROM messages WHERE run_id=? AND role='handoff'",(r['id'],)).fetchall():
                    try:
                        payload=json.loads(event['content'])
                        if payload.get('status')=='working':
                            payload['status']='interrupted'
                            c.execute('UPDATE messages SET content=? WHERE id=?',(json.dumps(payload),event['id']))
                    except (ValueError,TypeError,AttributeError):pass
                self._message(c,r['chat_id'],'assistant',r['agent'],'The server restarted during this request. Your conversation and saved files are available. Send a message to continue.',r['id'])
    @contextmanager
    def db(self):
        c=sqlite3.connect(self.database,timeout=15);c.row_factory=sqlite3.Row
        try:
            c.execute('PRAGMA foreign_keys=ON');yield c;c.commit()
        except BaseException:c.rollback();raise
        finally:c.close()
    def workspace(self,project):
        self.project(project)
        path=self.root/'projects'/project;path.mkdir(parents=True,exist_ok=True);return path
    def project(self,project):
        with self.db() as c:r=c.execute('SELECT * FROM projects WHERE id=?',(project,)).fetchone()
        if not r:raise KeyError('Project not found')
        return dict(r)
    def chat(self,chat):
        with self.db() as c:r=c.execute('SELECT * FROM chats WHERE id=?',(chat,)).fetchone()
        if not r:raise KeyError('Chat not found')
        return dict(r)
    def chats(self):
        with self.db() as c:return [dict(r) for r in c.execute('SELECT c.*,p.title AS project_title FROM chats c JOIN projects p ON p.id=c.project_id ORDER BY c.updated DESC,c.rowid DESC')]
    def create_chat(self,title='New conversation',project_id=None):
        if not isinstance(title,str) or not title.strip() or len(title.strip())>100:
            raise ValueError('Project name must contain 1–100 characters')
        title=title.strip()
        stamp=now();chat=identifier()
        with self.db() as c:
            if project_id:
                project=c.execute('SELECT title FROM projects WHERE id=?',(project_id,)).fetchone()
                if not project:raise KeyError('Project not found')
                title=project['title']
            else:
                project_id=identifier();c.execute('INSERT INTO projects VALUES(?,?,?)',(project_id,title[:100],stamp))
            c.execute('INSERT INTO chats VALUES(?,?,?,?,?)',(chat,project_id,title[:100],stamp,stamp))
        return self.chat(chat)
    def rename(self,chat,title):
        context=self.chat(chat)
        if not isinstance(title,str) or not title.strip() or len(title.strip())>100:
            raise ValueError('Project name must contain 1–100 characters')
        title=title.strip()
        with self.db() as c:
            c.execute('UPDATE projects SET title=? WHERE id=?',(title,context['project_id']))
            c.execute('UPDATE chats SET title=?,updated=? WHERE project_id=?',(title,now(),context['project_id']))
    def _message(self,c,chat,role,agent,content,run_id=None,message_id=None):
        mid=message_id or identifier();c.execute('INSERT INTO messages VALUES(?,?,?,?,?,?,?)',(mid,chat,role,agent,content,run_id,now()))
        c.execute('UPDATE chats SET updated=? WHERE id=?',(now(),chat));return mid
    def messages(self,chat):
        self.chat(chat)
        with self.db() as c:return [dict(r) for r in c.execute('SELECT * FROM messages WHERE chat_id=? ORDER BY rowid',(chat,))]
    def start_run(self,chat,agent,message,attachment_ids=None,model=None):
        attachment_ids=attachment_ids or []
        if len(attachment_ids)>8 or len(set(attachment_ids))!=len(attachment_ids):raise ValueError('Choose at most eight distinct attachments')
        context=self.chat(chat);rid=identifier();stamp=now()
        with self.db() as c:
            c.execute('BEGIN IMMEDIATE')
            if c.execute("SELECT id FROM runs WHERE project_id=? AND status IN ('queued','running','stopping')",(context['project_id'],)).fetchone():
                raise ValueError('This project already has a running request. Wait or press Stop.')
            if attachment_ids:
                marks=','.join('?' for _ in attachment_ids)
                available=c.execute('SELECT id FROM attachments WHERE chat_id=? AND message_id IS NULL AND id IN ('+marks+')',(chat,*attachment_ids)).fetchall()
                if len(available)!=len(attachment_ids):raise ValueError('Attachment not available as an unsent file in this room')
            c.execute('INSERT INTO runs(id,chat_id,project_id,agent,status,stage,created,updated,root_agent,model) VALUES(?,?,?,?,?,?,?,?,?,?)',
                      (rid,chat,context['project_id'],agent,'queued','Starting',stamp,stamp,agent,model))
            message_id=self._message(c,chat,'user',None,message,rid)
            for aid in attachment_ids:c.execute('UPDATE attachments SET message_id=? WHERE id=?',(message_id,aid))
        return self.run(rid)
    def run(self,rid):
        with self.db() as c:r=c.execute('SELECT * FROM runs WHERE id=?',(rid,)).fetchone()
        if not r:raise KeyError('Request not found')
        row=dict(r);row['checks']=json.loads(row['checks']);return row
    def runs(self,chat):
        with self.db() as c:ids=[r[0] for r in c.execute('SELECT id FROM runs WHERE chat_id=? ORDER BY rowid DESC LIMIT 30',(chat,))]
        return [self.run(r) for r in ids]
    def update(self,rid,status,stage,checks=None):
        with self.db() as c:
            if checks is None:c.execute('UPDATE runs SET status=?,stage=?,updated=? WHERE id=?',(status,stage[:400],now(),rid))
            else:c.execute('UPDATE runs SET status=?,stage=?,checks=?,updated=? WHERE id=?',(status,stage[:400],json.dumps(checks),now(),rid))
    def finish(self,rid,status,stage,content):
        run=self.run(rid)
        with self.db() as c:
            self._message(c,run['chat_id'],'assistant',run['agent'],content,rid)
            c.execute('UPDATE runs SET status=?,stage=?,updated=? WHERE id=?',(status,stage,now(),rid))
    def append_message(self,chat,role,agent,content,run_id,message_id=None):
        with self.db() as c:return self._message(c,chat,role,agent,content,run_id,message_id)
    def set_speaker(self,rid,agent):
        with self.db() as c:c.execute('UPDATE runs SET agent=?,updated=? WHERE id=?',(agent,now(),rid))
    def set_end_reason(self,rid,reason):
        # The first recorded cause wins (e.g. Stop immediately before shutdown).
        with self.db() as c:c.execute('UPDATE runs SET end_reason=COALESCE(end_reason,?),updated=? WHERE id=?',(reason,now(),rid))
    def complete_run(self,rid,status,stage):
        with self.db() as c:c.execute('UPDATE runs SET status=?,stage=?,updated=? WHERE id=?',(status,stage,now(),rid))
    def update_handoff(self,message_id,payload):
        with self.db() as c:c.execute("UPDATE messages SET content=? WHERE id=? AND role='handoff'",(json.dumps(payload),message_id))
    def read_room(self,chat,before_message_id='',limit=30):
        self.chat(chat);limit=max(1,min(int(limit),50))
        with self.db() as c:
            params=[chat];where='chat_id=?'
            if before_message_id:
                cursor=c.execute('SELECT rowid FROM messages WHERE id=? AND chat_id=?',(before_message_id,chat)).fetchone()
                if cursor is None:raise ValueError('History cursor does not belong to this room')
                where+=' AND rowid<?';params.append(cursor[0])
            rows=c.execute('SELECT * FROM messages WHERE '+where+' ORDER BY rowid DESC LIMIT ?',(*params,limit+1)).fetchall()
        more=len(rows)>limit;rows=[dict(r) for r in reversed(rows[:limit])]
        return {'messages':rows,'has_more':more,'before_message_id':rows[0]['id'] if rows else ''}

    def artifact(self,aid):
        with self.db() as c:r=c.execute('SELECT * FROM artifacts WHERE id=?',(aid,)).fetchone()
        if not r:raise KeyError('Code file not found')
        return dict(r)
    def artifacts(self,project,run_id=None):
        with self.db() as c:
            rows=c.execute('SELECT id,path,run_id,created,agent,reply_id FROM artifacts WHERE project_id=?'+(' AND run_id=?' if run_id else '')+' ORDER BY rowid DESC',
                           (project,run_id) if run_id else (project,)).fetchall()
        return [dict(r) for r in rows]
    def write_files(self,run,files):
        if not isinstance(files,list) or not 1<=len(files)<=20:raise ValueError('Write 1–20 files at a time')
        root=self.workspace(run['project_id']);planned={}
        for f in files:
            path=f.get('path');content=f.get('content')
            target=safe_path(root,path)
            if not isinstance(content,str) or len(content.encode())>200000:raise ValueError('A file must contain at most 200 KB of text')
            planned[path]=(target,content)
        originals={path:target.read_bytes() if target.is_file() else None for path,(target,_) in planned.items()}
        saved=[]
        try:
            with self.db() as c:
                for path,(target,content) in planned.items():
                    target.parent.mkdir(parents=True,exist_ok=True)
                    temp=target.with_name(target.name+'.rooz-tmp');temp.write_text(content,encoding='utf-8');temp.replace(target)
                    aid=identifier();c.execute('INSERT INTO artifacts(id,project_id,run_id,path,content,created,agent,reply_id) VALUES(?,?,?,?,?,?,?,?)',(aid,run['project_id'],run['id'],path,content,now(),run.get('agent'),run.get('reply_id')));saved.append({'id':aid,'path':path})
        except BaseException:
            for path,content in originals.items():
                target=planned[path][0]
                if content is None:target.unlink(missing_ok=True)
                else:target.write_bytes(content)
            raise
        return saved
    def manifest(self,project):
        root=self.workspace(project);rows=[]
        for p in sorted(root.rglob('*')):
            if p.is_file() and not p.is_symlink():
                rows.append({'path':p.relative_to(root).as_posix(),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
        return rows
    def revision(self,project):
        return hashlib.sha256(json.dumps(self.manifest(project),sort_keys=True).encode()).hexdigest()
