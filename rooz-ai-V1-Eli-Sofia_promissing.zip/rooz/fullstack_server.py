"""Fixed Docker entry point: build React and serve frontend + real ASGI backend."""
import argparse
import importlib
import importlib.util
import json
import os
import shutil
import subprocess
import sys
from pathlib import Path

PUBLIC = {'.html', '.css', '.js', '.mjs', '.json', '.png', '.jpg', '.jpeg', '.webp', '.gif', '.svg', '.ico', '.woff', '.woff2', '.ttf', '.txt', '.map', '.webm', '.mp4'}


class CombinedApp:
    def __init__(self, backend, dist, session, static_frontend=False):
        self.backend = backend
        self.dist = Path(dist).resolve()
        self.session = session
        self.static_frontend=static_frontend

    async def __call__(self, scope, receive, send):
        from starlette.responses import FileResponse, JSONResponse, Response
        if scope['type'] != 'http':
            return await self.backend(scope, receive, send)
        path = scope['path']
        headers = {'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff',
                   'Content-Security-Policy': "worker-src 'none'"}
        if path == '/__rooz_health':
            return await JSONResponse({'preview': self.session, 'mode': 'fullstack'}, headers=headers)(scope, receive, send)
        if path == '/api' or path.startswith('/api/') or path in ('/openapi.json', '/docs', '/redoc', '/docs/oauth2-redirect'):
            return await self.backend(scope, receive, send)
        if scope['method'] not in ('GET', 'HEAD'):
            return await Response('API routes must use /api', status_code=405, headers=headers)(scope, receive, send)
        relative = Path(path.lstrip('/') or 'index.html')
        if self.static_frontend and relative.parts and relative.parts[0]=='static' and not (self.dist/relative).is_file():
            relative=Path(*relative.parts[1:])
        target = (self.dist / relative).resolve()
        if '\\' in path or any(part.startswith('.') for part in relative.parts) or not target.is_relative_to(self.dist):
            return await Response(status_code=404, headers=headers)(scope, receive, send)
        # Only extensionless navigation falls back to the SPA. Missing assets stay 404.
        if not target.is_file() and not relative.suffix:
            target = self.dist / 'index.html'
        if not target.is_file() or target.suffix.lower() not in PUBLIC:
            return await Response(status_code=404, headers=headers)(scope, receive, send)
        return await FileResponse(target, headers=headers)(scope, receive, send)


def build(work, settings, runtime):
    bootstrap = Path(__file__).with_name('execute.py')
    if not bootstrap.is_file():
        bootstrap = Path(__file__).parents[1] / 'sandbox/execute.py'
    spec = importlib.util.spec_from_file_location('rooz_execute', bootstrap)
    module = importlib.util.module_from_spec(spec); spec.loader.exec_module(module)
    module.prepare(work, runtime)
    frontend = work / settings['frontend_dir']
    if settings.get('frontend_type')=='static':
        if not (frontend/'index.html').is_file():raise RuntimeError('Static API frontend needs index.html')
        print('Using saved HTML/CSS/JavaScript with its real backend (no frontend build required).',flush=True)
        return frontend
    print('Building frontend production assets…', flush=True)
    subprocess.run(['npm', 'run', 'build'], cwd=frontend, timeout=100, check=True)
    dist = frontend / 'dist'
    if not (dist / 'index.html').is_file():
        raise RuntimeError('Frontend build did not produce dist/index.html')
    return dist


def stage_source(source, work_base):
    source=Path(source).resolve();work_base=Path(work_base).resolve()
    if source==work_base or work_base.is_relative_to(source):
        raise RuntimeError('Preview requires a separate disposable work directory')
    # /work is a root-owned tmpfs mount. The non-root app can create children
    # there, but cannot apply source directory metadata to the mount itself.
    work=work_base/'project'
    if source.is_relative_to(work):
        raise RuntimeError('Preview source cannot be inside its work directory')
    shutil.copytree(source,work)
    return work


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--source', required=True); parser.add_argument('--work', default='/work')
    parser.add_argument('--data', default='/data'); parser.add_argument('--session', required=True)
    parser.add_argument('--profile', required=True); parser.add_argument('--port', type=int, default=8080)
    parser.add_argument('--host', default='0.0.0.0'); parser.add_argument('--runtime', default='/opt/rooz/web-runtime')
    args = parser.parse_args()
    work = stage_source(args.source,args.work); data = Path(args.data).resolve()
    data.mkdir(parents=True, exist_ok=True)
    os.environ.update(ROOZ_DATA_DIR=str(data), DATABASE_PATH=str(data/'app.sqlite3'), DATABASE_URL='sqlite:///'+str(data/'app.sqlite3'))
    settings = json.loads(args.profile)
    dist = build(work, settings, Path(args.runtime))
    backend = work / settings['backend_dir']
    sys.path[:0] = [str(backend), str(work)]
    os.chdir(backend)
    module_name, attribute = settings['backend_app'].split(':')
    application = getattr(importlib.import_module(module_name), attribute)
    print('Starting real backend and frontend at one preview address. Data: '+str(data), flush=True)
    import uvicorn
    uvicorn.run(CombinedApp(application, dist, args.session, settings.get('frontend_type')=='static'), host=args.host, port=args.port, lifespan='on')


if __name__ == '__main__':
    main()
