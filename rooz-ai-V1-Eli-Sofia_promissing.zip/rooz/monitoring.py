"""Metadata-only agent telemetry. Never persist prompts, arguments, results or reasoning."""
import json
import os
import re
import sqlite3
import time
from pathlib import Path
from .storage import now


def redact(value):
    text = str(value)
    for key, secret in os.environ.items():
        if any(word in key.upper() for word in ('KEY', 'TOKEN', 'PASSWORD', 'SECRET')) and len(secret) >= 8:
            text = text.replace(secret, '[REDACTED]')
    return re.sub(r'\bsk-[A-Za-z0-9_-]{8,}', '[REDACTED]', text)


class Monitoring:
    def __init__(self, directory):
        self.database = Path(directory) / 'monitoring.sqlite3'
        with self.connect() as db:
            db.executescript('''
                CREATE TABLE IF NOT EXISTS events(
                  id INTEGER PRIMARY KEY, run_id TEXT NOT NULL, created TEXT NOT NULL, payload TEXT NOT NULL);
                CREATE INDEX IF NOT EXISTS events_run ON events(run_id,id);
                CREATE TABLE IF NOT EXISTS security_runs(
                  id TEXT PRIMARY KEY, created TEXT NOT NULL, updated TEXT NOT NULL,
                  status TEXT NOT NULL, document TEXT NOT NULL);
            ''')
            for row in db.execute("SELECT id,document FROM security_runs WHERE status IN ('queued','running','stopping')").fetchall():
                report = json.loads(row[1])
                report.update(status='interrupted', updated=now())
                for case in report['cases']:
                    if case['status'] in ('pending', 'running'):
                        case.update(status='inconclusive', evidence=['Server restarted before this case finished.'])
                db.execute('UPDATE security_runs SET status=?,updated=?,document=? WHERE id=?',
                           ('interrupted', report['updated'], json.dumps(report), row[0]))

    def connect(self):
        return sqlite3.connect(self.database, timeout=15)

    def event(self, run, kind, **data):
        allowed = ('agent', 'model', 'tool', 'status', 'duration_ms', 'input_tokens', 'output_tokens', 'error_type', 'http_status')
        payload = {'kind': kind, **{k: v for k, v in data.items() if k in allowed}}
        with self.connect() as db:
            db.execute('INSERT INTO events(run_id,created,payload) VALUES(?,?,?)',
                       (run['id'], now(), redact(json.dumps(payload))))
            # Bounded metadata retention; security reports have independent retention.
            db.execute('DELETE FROM events WHERE id <= (SELECT COALESCE(MAX(id),0)-20000 FROM events)')

    def events(self, run_id):
        with self.connect() as db:
            rows = db.execute('SELECT created,payload FROM events WHERE run_id=? ORDER BY id DESC LIMIT 300', (run_id,)).fetchall()
        return [{'created': row[0], **json.loads(row[1])} for row in reversed(rows)]

    def save(self, report):
        report['updated'] = now()
        with self.connect() as db:
            db.execute('INSERT INTO security_runs VALUES(?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET updated=excluded.updated,status=excluded.status,document=excluded.document',
                       (report['id'], report['created'], report['updated'], report['status'], redact(json.dumps(report))))
            db.execute("DELETE FROM security_runs WHERE id IN (SELECT id FROM security_runs WHERE status NOT IN ('queued','running','stopping') ORDER BY created DESC LIMIT -1 OFFSET 100)")

    def reports(self):
        with self.connect() as db:
            return [json.loads(row[0]) for row in db.execute('SELECT document FROM security_runs ORDER BY created DESC LIMIT 100')]

    def report(self, identity):
        with self.connect() as db:
            row = db.execute('SELECT document FROM security_runs WHERE id=?', (identity,)).fetchone()
        if row is None:
            raise KeyError('Security test run not found')
        return json.loads(row[0])

    def runs(self, store):
        with store.db() as db:
            rows = db.execute('SELECT id,project_id,agent,model,status,stage,created,updated FROM runs ORDER BY rowid DESC LIMIT 40').fetchall()
        result = []
        for row in rows:
            item = dict(row)
            events = self.events(item['id'])
            item['events'] = events
            usage = [e for e in events if e['kind'] == 'model_completed']
            item['input_tokens'] = sum(e.get('input_tokens') or 0 for e in usage)
            item['output_tokens'] = sum(e.get('output_tokens') or 0 for e in usage)
            item['usage_available'] = any(e.get('input_tokens') is not None for e in usage)
            item['model_calls'] = sum(e['kind'] == 'model_started' for e in events)
            item['last_activity'] = events[-1]['created'] if events else item['updated']
            item['history_truncated'] = len(events) == 300
            result.append(json.loads(redact(json.dumps(item))))
        return result


def usage_of(response):
    usage = getattr(response, 'usage', None)
    def get(primary, secondary):
        value = getattr(usage, primary, None)
        if value is None:
            value = getattr(usage, secondary, None)
        return value if isinstance(value, int) else None
    return {'input_tokens': get('input_tokens', 'prompt_tokens'),
            'output_tokens': get('output_tokens', 'completion_tokens')}
