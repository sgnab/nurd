"""Declarative preview configuration; no user-supplied shell startup commands."""
import json
import os
import re
from pathlib import Path

FULLSTACK_ENTRY = '@fullstack'
EXCLUDED = {'node_modules', '__pycache__', 'venv', 'dist'}


def directory(root, value):
    if not isinstance(value, str) or '\\' in value or Path(value).is_absolute() or '..' in Path(value).parts:
        raise ValueError('Preview directories must be relative project paths')
    path = root / value
    if any(part.startswith('.') and part != '.' for part in Path(value).parts):
        raise ValueError('Hidden preview directories are not supported')
    if not path.resolve().is_relative_to(root.resolve()) or path.is_symlink():
        raise ValueError('Preview directories must stay inside the project')
    return path


def profile(root):
    config = root / 'rooz-preview.json'
    if config.is_file():
        if config.is_symlink(): raise ValueError('Preview configuration cannot be a symlink')
        settings = json.loads(config.read_text())
        if not isinstance(settings, dict) or set(settings) - {'frontend_dir', 'backend_dir', 'backend_app', 'frontend_type'}:
            raise ValueError('rooz-preview.json supports frontend_dir, backend_dir, backend_app and frontend_type only')
    elif ((root / 'frontend/package.json').is_file() or (root / 'frontend/index.html').is_file()) and (root / 'backend/main.py').is_file():
        settings = {'frontend_dir': 'frontend', 'backend_dir': 'backend', 'backend_app': 'main:app'}
    else:
        return None
    settings = {'frontend_dir': 'frontend', 'backend_dir': 'backend', 'backend_app': 'main:app', **settings}
    frontend = directory(root, settings['frontend_dir'])
    backend = directory(root, settings['backend_dir'])
    application = settings['backend_app']
    if not isinstance(application, str) or not re.fullmatch(r'[A-Za-z_]\w*(?:\.[A-Za-z_]\w*)*:[A-Za-z_]\w*', application):
        raise ValueError('backend_app must be a Python module:app identifier, for example main:app')
    kind=settings.get('frontend_type','auto')
    if kind not in ('auto','static','vite'):
        raise ValueError('frontend_type must be auto, static or vite')
    if kind=='auto':kind='vite' if (frontend/'package.json').is_file() else 'static'
    if kind=='vite':
        metadata = json.loads((frontend / 'package.json').read_text())
        if not isinstance(metadata.get('scripts', {}).get('build'), str):
            raise ValueError('The frontend package.json needs a build script')
    elif not (frontend/'index.html').is_file():
        raise ValueError('Static API frontend needs index.html')
    settings['frontend_type']=kind
    module = application.split(':')[0]
    target = backend / (module.replace('.', '/') + '.py')
    if not target.is_file() or target.is_symlink():
        raise ValueError('The configured backend module does not exist: ' + str(target.relative_to(root)))
    return settings


def source_files(root):
    """Bounded execution snapshot; never copy environment files, data or symlinks."""
    files = {}; total = 0
    for current, dirs, names in os.walk(root, followlinks=False):
        folder = Path(current)
        dirs[:] = [d for d in sorted(dirs) if not d.startswith('.') and d not in EXCLUDED
                   and not (folder == root and d == 'data') and not (folder/d).is_symlink()]
        for name in sorted(names):
            path = folder / name
            if name.startswith('.') or path.is_symlink() or path.suffix.lower() in ('.db', '.sqlite', '.sqlite3', '.pyc', '.log'):
                continue
            if path.stat().st_size > 10*1024*1024:
                raise ValueError('Preview source files must be at most 10 MB: ' + str(path.relative_to(root)))
            content = path.read_bytes(); total += len(content)
            if total > 50*1024*1024 or len(files) >= 1000:
                raise ValueError('Full-stack preview source exceeds 50 MB or 1,000 files')
            files[path.relative_to(root).as_posix()] = content
    return files
