# GPT-6 Luna coding model

## Use this update

Stop Rooz-AI and replace source files with this archive, preserving `.env`, `.venv` and `data`. In your existing `.env`, add or update:

```dotenv
CODING_MODEL=gpt-6-luna
```

Keep your saved `OPENAI_API_KEY`. `CODING_MODEL` takes precedence over an older `OPENAI_MODEL` setting. If the shell already exports a different `CODING_MODEL`, remove that export or start this run explicitly with:

```bash
CODING_MODEL=gpt-6-luna bash start.sh
```

Otherwise `bash start.sh` is enough. No Docker rebuild, new dependency, new key entry or deployment is required. The Settings panel reports the effective model. All three agents currently share this setting, including Eli. Existing generated project source and data are not modified by this update.

## Compatibility

New installations default to `gpt-6-luna`. Explicit existing model settings are preserved, so setting `CODING_MODEL` is necessary when the old `.env` still selects GPT-4.1 mini.

Luna uses the Responses API with medium reasoning effort, function tools, image inputs, retained encrypted reasoning state and `store=false`. Its output allowance is 32,768 tokens per response so reasoning and code have room without increasing usage when fewer tokens are generated. GPT-6.1 Sol retains its existing low-effort Responses route; other existing models retain their current route. There is no silent model substitution.

The existing 64-round and 15-minute limits, autonomous repair behavior, Stop, preview readiness and screenshot review remain in place.

## Verification

Tests use the actual OpenAI SDK with mocked HTTP responses and controlled local execution. Luna-specific checks cover Responses routing, request parameters, preserved reasoning/tool IDs, a failed check followed by repair, screenshot pixels, startup configuration precedence, cancellation, and a visible account-access error without fallback. This does not establish live account/model access or measure Luna's coding quality. Those require the first authorized real request using your local saved key.

Official model reference: https://developers.openai.com/api/docs/models/gpt-6-luna
