# Stage 1.9 — real full-stack preview and functional verification

This stage connects generated React frontends to their actual FastAPI backends in
the user Preview. It strengthens Eli's individual workflow; it does not introduce
Alex's orchestration, project rollback or parallel development yet.

## Install

Stop Rooz-AI, extract this ZIP over the existing project, then run:

```bash
bash setup.sh
bash start.sh
```

Your .env and existing data are not included in the ZIP. setup.sh rebuilds the
runner with cached layers and executes both Stage 1.8 checks and the new disposable
full-stack acceptance scenario. It reports success only after both pass. No provider
key is needed for those setup checks. Normal restarts use start.sh alone.

## Use Preview

For supported apps, choose **Full-stack app (React + API)** and Start Preview.
The runtime builds React's dist/, loads the real backend and serves both through
one local address. Open in new tab uses the same running application and data.
Loading/build/backend errors remain visible in the preview logs; Running is shown
only after the fixed runtime health check responds with the current session ID.

- Frontend requests must use relative /api URLs. Unknown /api routes return backend
  errors and never fall back to the frontend HTML.
- Extensionless frontend navigation supports SPA fallback; missing assets stay 404.
- Refresh rebuilds code and restarts the backend, preserving the preview origin/data.
- Stop, Start and Rooz-AI restart preserve preview data. Previews stop when Rooz-AI
  restarts and can be started again explicitly.
- Reset preview data asks for confirmation, stops the app and deletes only that
  chat's preview database/files. It does not delete source code or another chat's data.
- Static HTML previews continue to work independently.

## Supported project layout

The default is frontend/package.json with a build script and backend/main.py with
an app object. Existing projects with another layout can save rooz-preview.json:

```json
{
  "frontend_dir": "frontend",
  "backend_dir": "backend",
  "backend_app": "main:app"
}
```

Paths are relative to the project, and backend_app is a Python module:attribute.
Shell startup commands are not accepted. Apps outside the currently supported
React/Vite + Python/ASGI profile need an explicit runtime extension, not silent fallback.

The backend must honor DATABASE_PATH or ROOZ_DATA_DIR for SQLite/files. These point
to the chat's persistent preview directory. DATABASE_URL is also supplied as a
SQLite URL; applications requiring an async SQLAlchemy URL must normalize its driver.
A database hardcoded into the rebuilt source directory will not persist. Ask Eli
to adapt existing apps to the convention and verify it; Rooz-AI does not silently
rewrite the generated application or migrate arbitrary existing databases.

## Isolation and runtime limits

Generated backend code runs in Docker, not in the Rooz-AI host process. Source
snapshots are mounted read-only and copied into a bounded writable work directory.
Only the current chat's preview-data directory is writable/persistent. Host .env,
provider credentials, Docker socket and unrelated room files are not mounted.
The preview port is loopback-only. Build/backend logs are available during startup.
Full-stack limits: 1 GiB memory, 1 CPU, 256 PIDs, 256 MiB work directory and 128 MiB
temporary directory. Preview startup allows up to 150 seconds; failed startup
cleans up its container and snapshot while retaining diagnostic logs and data.

Dependency downloads happen during setup/image build. The running application uses
the supported bundled frontend/Python dependencies. Additional packages, external
databases, live providers and credentials need explicit setup. No external-provider
credentials are injected and no claim is made that provider functionality passed.

## Eli verification

Eli receives the new preview/data conventions and a stronger acceptance checklist:
backend tests, production build, real browser/API/database flow, relevant CRUD,
invalid inputs, visible error behavior, reload and required restart persistence.
He saves a fail-fast tests/verify.py orchestrator and calls verify_app. The host
also attempts that script before returning changed supported full-stack apps.
Failures are returned to Eli for investigation. Missing checks remain visible;
a health-only starter check is not feature acceptance for a notes/CRUD application.

Final reports must identify which requested behaviors were verified and which remain
unverified. These instructions and checks support better development; they do not
prove that arbitrary model output is flawless or replace testing real Eli sessions.

## Test your existing app

In the app's original chat, send:

> @Eli Inspect the existing app and connect its frontend to its real backend using
> the one-origin Preview conventions. Preserve the app and its stack. Use persistent
> preview storage. Implement tests/verify.py covering the actual requested features,
> relevant CRUD, UI/API communication, blank/invalid inputs, visible failures and
> reload/restart persistence. Run verify_app, investigate and repair failures, then
> report the actual results and any unverified behaviors. Do not regenerate the app
> or replace application endpoints with mocked responses.

Then open Preview and manually perform the same primary workflow. A passing setup
fixture validates the runtime, not every application Eli has generated.
