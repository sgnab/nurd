# Request time budget: no agent step cap

The former 64-turn limit for Eli and 24-turn limit for Alex/Sofia are removed. Agent tool and repair loops now continue without a turn-count quota. A turn is a model response, not a test count.

The request has one shared 45-minute overall deadline, including teammate calls and verification. It is not reset after a repair or handoff. Completion ends the request earlier, and Stop remains available throughout. Individual-operation timeouts still detect stalled provider calls or subprocesses; actual provider and infrastructure errors remain visible. There is no new automatic repeat of failed requests or model fallback.

Saved files, past check results, model choices, provider configuration and preview data are preserved. An existing failed job does not restart automatically after installing the source. Send Eli a follow-up to continue from the saved project rather than regenerate it.

Install: stop Rooz, merge the source into your existing folder, keep `.env`, `data/` and `.venv/`, then run `bash start.sh`. No dependency or Docker image changes are included.

Verification: regression tests exercise repair beyond 64 turns, more than 75 tool turns for each agent, and Stop/deadline cancellation after passing the former turn boundary. Existing request lifecycle, model routing and verification regressions are included in the full test suite. Live provider access and Docker/browser execution are not established by these controlled tests.

Full regression result: 183 automated tests passed. Test fixtures that formerly relied on turn exhaustion now explicitly exercise deadline cancellation or an unavailable runner. No application test failures are cleared by this change.
