# HTML/API preview validation — 2026-11-07

- 116 host tests passed against the final source. Includes plain HTML detection,
  real HTTP/SQLite API operations without package.json or a frontend build,
  refresh persistence, /static asset handling, upgrade from a remembered/running
  static preview, plus prior React, isolation, setup and agent regressions.
- Nine real Chromium preview-UI checks passed with a plain HTML/FastAPI application:
  detection, iframe start, real API create/list, new tab, Refresh, logs, Stop/Start,
  confirmed data reset and mobile layout.
- JavaScript syntax check passed.
- The submitted notes project was tested unchanged separately: its two included
  backend tests both failed. See HTML_API_PREVIEW_FIX.md for the precise causes.

These host/browser checks use controlled native runtime adapters. Docker is unavailable
in this build workspace; setup.sh runs the real Docker checks on the Mac. Scripted
agent tests do not establish live Eli performance. The submitted app remains unchanged
and unverified until Eli repairs its actual failures.
