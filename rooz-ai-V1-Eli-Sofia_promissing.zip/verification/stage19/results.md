# Stage 1.9 validation — 2026-11-07

- 111 host tests passed (Python 3.12 in the build environment). Includes prior
  regressions, full-stack profile/snapshot validation, loopback-only Docker command
  contract, real local HTTP/SQLite CRUD, invalid inputs, Refresh, preview lifecycle,
  room-data isolation, reset and failing-build diagnostics.
- The six full-stack tests were rerun after final snapshot/lifecycle changes.
- A real React/TypeScript/Tailwind application was built using Vite 6.4.5, started
  through the actual fullstack_server implementation and driven with Chromium.
  Create/read/edit/delete, blank-title rejection, UI error display, reload, API record
  values, Refresh, backend Stop/Start persistence and scoped reset passed.
- Nine preview UI checks passed in Chromium: full-stack detection, iframe start,
  real API create/list, new-tab view, Refresh/origin persistence, logs, Stop/Start,
  confirmed reset and mobile overflow. Mobile screenshot inspected internally.
- Fourteen existing static-preview browser checks passed, including origin isolation,
  static assets, JavaScript interaction, Refresh/localStorage, missing runtime,
  independent rooms, unsupported source-entry errors and mobile sizing.
- JavaScript syntax checks and Bash syntax checks passed.

Scope and limitations:

- Runtime and browser tests used controlled native adapters because Docker is not
  available in the build workspace. Production execution still uses Docker only.
- Chromium used a local executable adapter. APIs and SQLite data were real;
  browser-to-application requests were not mocked.
- Host agent tests use scripted model responses, not a live Eli evaluation.
- tests/check_stage19_docker.py is included and invoked by setup.sh. It exercises a
  disposable real Docker preview with compiled React, browser CRUD, Refresh,
  Stop/Start persistence and data reset. Local Docker execution remains to be confirmed.
- Passing the supplied fixture validates runtime behavior, not every generated app.
  Existing apps must honor /api and preview data conventions and provide their own
  functional tests. Live providers, external databases and deployment were not tested.
