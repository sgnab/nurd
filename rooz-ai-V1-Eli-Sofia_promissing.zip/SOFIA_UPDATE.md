# Sofia frontend workflow

Merge this source update into your current Rooz folder, keeping `.env`, `data/`
and `.venv/`. Restart with `bash start.sh`. No new dependency or Docker rebuild
is required. Existing projects and saved files are retained.

Select Sofia and continue the existing ClientFlow project, or start a new project.
You do not need to repeat a large operating prompt. A useful follow-up is:

> @Sofia, continue the saved ClientFlow project. Inspect what exists, implement
> the remaining frontend requirements using mock data, run UI tests, review
> desktop/mobile/form screenshots and repair failures before returning.
> Preserve saved work and leave the backend to Eli.

## Scope and isolation

Only Sofia's execution branch changes. `rooz/agents.py` adds three lines that
lazily dispatch Sofia to `rooz/sofia_flow.py`. All other original code in that
module is unchanged. Eli's prompts, tool definitions, workflow, skills, full-stack
starter, model routing, runner, preview implementation and request limits remain
unchanged. Alex's branch is unchanged as well. A parent calling Sofia receives
her upgraded behavior, but keeps its own original tools/context and resumes after
her reply as before. Calls remain sequential.

Tests compare the original shared agent module's syntax tree after removing the
Sofia-only dispatch. Protected-file hashes compare Eli's files, templates and
shared services against the uploaded source. Existing regression tests are run
alongside the Sofia tests. This is code/regression evidence, not a guarantee
about every possible future model response.

## What Sofia now has

- Independent frontend ownership instructions, with on-demand frontend, testing,
  visual and debugging guides. No changes to Eli's guides.
- `scaffold_frontend`: an empty-project React/TypeScript/Vite/Tailwind starter
  using installed dependencies, a typed localStorage mock-service adapter and
  clearly labeled sample records. Scaffolding never overwrites a nonempty project.
- `verify_ui`: runs saved `tests/verify.py` to build first, then run real-browser
  behavior checks in the same disposable container. The starter browser test
  covers create/edit/toggle/delete, validation, reload, empty/error states,
  focus/Escape and desktop/mobile overflow. Sofia must adapt those tests to the
  requested product; the starter is not a completed ClientFlow application.
- `view_screenshot`: actual project-scoped browser images, automatically supplied
  after checks. UI delivery returns for visual review when the current frontend
  acceptance result has no screenshots. Desktop/mobile/open-form coverage remains
  part of Sofia's guide and starter tests; one screenshot is not proof of every
  UI state or semantic review quality.
- `rerun_check` and `report_execution_blocker`, preserving actual failed evidence
  and only settling it with a relevant executed pass. Unrelated inventory probes
  cannot replace frontend acceptance after an implementation change.
- Inspect-before-edit protection and automatic repair feedback for failed checks.
  A provisional 'confirm to proceed' draft returns to diagnosis/repair rather
  than being delivered as the final result.

The frontend template includes a minimal ASGI static-serving adapter under
`backend/main.py` solely for the existing Preview system. It provides a health
route and serves the built SPA; it does not implement application/business APIs.
Frontend data stays in the mock service until Eli adds a real backend later.
This avoids changing Rooz's shared Preview or runner code. Mock UI verification
must never be reported as real backend/API/provider verification.

## Timeouts and work limits

Sofia gets the known installed runtime in her initial context: React/Vite/
TypeScript/Tailwind, Python Playwright, Node @playwright/test and Chromium under
`PLAYWRIGHT_BROWSERS_PATH=/ms-playwright`. This avoids repeated global/cache
probes and mistaken missing-browser diagnoses. Full Radix Dialog/Select and
Vitest are not available; she should use native controls or installed packages.
No npm downloads or CDN dependencies are expected in keyless Docker checks.

Transient model request timeouts now identify the Sofia operation and retry the
same model with a brief backoff, preserving conversation and saved work. No local
tool is executed twice by that retry. Previously accepted provider requests may
still be billed even if the local wait timed out. Non-timeout provider errors
are reported using the existing error handling; no silent model fallback.
Runner setup/operation timeouts are recorded as failed check evidence to diagnose
and rerun, not shown as successful application verification.

There is no Sofia step quota or three-attempt repair limit. The existing shared
45-minute request deadline and Stop remain in force, including during retry
backoff and nested calls. Existing individual runner/model operation timeouts
still detect stalled operations. A real unavailable environment remains unverified.
Document-only changes do not automatically trigger a UI rebuild/browser run.

## Implementation files

- `rooz/sofia.py`: Sofia context, guide catalog, frontend scaffold and check policy.
- `rooz/sofia_flow.py`: Sofia's independent tool/model/repair/image loop.
- `rooz/sofia_guides/`: four Sofia-specific development guides.
- `rooz/templates/sofia/`: frontend/mock overrides, preview adapter, verification
  entrypoint and browser test. Dependency/configuration assets are copied from
  the existing immutable frontend template without changing that template.
- `tests/test_sofia.py`: orchestration, isolation, SDK formats, timeouts, Stop,
  starter service/HTTP adapter and current-revision image delivery checks.
- `tests/check_sofia_mock_service.cjs`: executes the actual mock TypeScript service
  using Node's native type stripping; validates CRUD, empty-state persistence and
  preservation of corrupt stored data. This is not browser/backend verification.
- `tests/sofia_eli_baseline.json`: protected hashes of the uploaded Eli/shared code.

Run host checks with `python -m unittest discover -s tests -p 'test_*.py' -q`.
Actual live-model frontend construction and Docker browser verification must be
confirmed in your local Rooz environment. No live provider pass is implied by
scripted model/container fixtures used to test host orchestration.

## Validation of this update

All **225 automated host tests passed** on the final source: the original 204
regressions plus 21 Sofia/isolation checks. The actual TypeScript mock service
was executed with Node's native type stripping, and the static preview adapter
was exercised through HTTP against controlled asset fixtures. Real OpenAI SDK
serialization was tested for Responses and DeepSeek Chat Completions with
controlled HTTP responses; no paid provider calls were made.

The original uploaded files are unchanged except for the three-line Sofia-only
branch in `rooz/agents.py`. Eli's protected-file hashes and the remaining shared
module syntax tree match the uploaded source.

Docker is unavailable in this execution environment and installed Chromium could
not launch under its process/socket restrictions. Therefore no actual Vite build,
Docker browser workflow or live Sofia model result is claimed here. The generated
starter browser script is supplied for Sofia to execute in your existing runner.
