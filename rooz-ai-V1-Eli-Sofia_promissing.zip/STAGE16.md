# Stage 1.6 — file attachments and image input

This update builds on your supplied `rooz-ai-review(1).zip`. It adds attachments to the existing shared chat. Live Preview remains a separate stage.

## Install once

1. Stop Rooz-AI with Ctrl+C.
2. Extract `rooz-ai-stage16.zip` **inside your existing rooz-ai folder**, replacing matching files. Keep your `.env`, `.venv` and `data/`.
3. From that folder, install the two added host dependencies:

   ```bash
   .venv/bin/python -m pip install -r requirements.txt
   bash start.sh
   ```

4. Refresh the browser with Cmd+Shift+R.

No Docker image rebuild is needed. Subsequent restarts only require `bash start.sh`. Your existing saved provider configuration is used; there is no new key form. The runner, sandbox image, startup scripts and agent addressing logic are unchanged.

On startup, storage adds an attachments table and index. Existing messages, runs and project files are retained. Attachments are stored separately under `data/attachments/`; keep the entire `data/` folder in backups. Rolling back to the supplied Stage 1.5 source leaves its existing tables intact, but that older interface will not display attachments.

## Use

- Click the paperclip, drop files into the page, or paste a screenshot into the message box.
- Add a request and choose Alex, Sofia or Eli. Existing case-insensitive addressing works, for example `@sOfIa review this screenshot`.
- An image or file can also be sent without typed text.
- Unsent files show above the composer and can be removed. They survive refresh in that room.
- Sent files appear with their original user message. Click one to download the original bytes.
- Any agent in that room can retrieve sent references. A called teammate receives the current request's images and text automatically. Other rooms and unsent drafts are excluded from model access.

Images are delivered as actual image inputs through both supported API paths, including the existing GPT-6.1-sol Responses path. Older room images can be requested through `list_attachments` and `read_attachment`; text can be read in windows. Uploading a code file supplies a reference, without copying it into the executable project or running it. If you want an agent to edit or run it, explicitly ask them to create the appropriate project file.

## Supported files and limits

Text/code: `.py`, `.js`, `.jsx`, `.ts`, `.tsx`, `.html`, `.css`, `.md`, `.markdown`, `.json`, `.txt`, `.yaml`, `.yml`, `.csv`, `.sql`, `.toml`, `.ini`, `.sh`, `.xml`, `.log`. Save these as UTF-8.

Images: `.png`, `.jpg`, `.jpeg`, `.webp`. File bytes are checked against the extension. Image input is orientation-corrected and reduced to at most 2048 pixels on its longest side; the original download is preserved. Transparent images are viewed against white. Animated images supply their first frame.

- Up to 8 files per message, 10 MB per file and 20 MB combined.
- Text/code: up to 1 MB per file. The initial model context includes an 8,000-character excerpt per file; agents can read the rest with the attachment tool.
- Images: up to 20 megapixels. PDF, ZIP, SVG and binary executables are outside this stage.

## Verification

66 Python tests passed, including 19 attachment tests. Actual Chromium checks passed: 13 attachment workflows, 10 existing Stage 1 workflows and 10 existing team workflows. Reports are included under `verification/stage16/`.

Coverage includes original-byte downloads, persistent drafts, separate rooms, atomic binding, invalid uploads, actual image payloads through both OpenAI SDK paths, teammate access, mobile layout, Stop, and navigating away while a Send response is pending.

Model responses in automated checks are controlled fixtures; no paid OpenAI call was made. Existing execution checks use a controlled native fixture adapter because Docker is unavailable in this verification environment. Production remains Docker-only for running generated code. These checks confirm image transport, not a live model's visual interpretation.

## Quick check on your machine

1. Attach a `.py` or `.md` file and ask Eli to explain it. Confirm it stays out of Project files unless you ask him to save or execute a copy.
2. Paste a screenshot and ask Sofia what she sees. This checks your actual model's image support.
3. Ask Alex to have Sofia review that screenshot. Confirm the handoff and her reply appear.
4. Refresh, then open another room. The original room retains its files; the new room starts empty.

## Module boundaries

`rooz/attachments.py` owns file validation, storage and model views. `rooz/api.py` exposes upload/download routes. `rooz/storage.py` binds references atomically to user messages. `rooz/agents.py` supplies references and attachment tools. The existing chat interface renders drafts and sent files. No Live Preview or workflow orchestration was added.
