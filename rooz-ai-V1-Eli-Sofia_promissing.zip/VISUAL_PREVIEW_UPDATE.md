# Preview readiness and visual development

## Install locally

Stop Rooz-AI, replace its source files with this archive and preserve your `.env`, `.venv` and `data` directory. Restart:

```bash
bash start.sh
```

This update needs no new dependencies or Docker rebuild. Nothing is deployed. Open the existing project and ask Eli to review and repair its functional and visual defects, then finish verification. Existing generated project files and preview data are unchanged by installing this update.

## Preview startup

Previously both preview modes inspected Docker's port mapping once immediately after starting a container. An empty or incomplete mapping was reported as a missing loopback port without waiting for it to become available.

Both modes now wait for a valid 127.0.0.1 binding, rechecking metadata while the same container starts. The port wait is bounded to 12 seconds with short inspect timeouts, respects Stop, rejects non-loopback publication, and distinguishes an exited/dead container from a mapping that never appears. Existing health/session checks still wait for the actual application to become ready. The original container logs are preserved by the startup error handler.

This repairs the demonstrated readiness-handling gap. We did not observe the user's failed Mac container directly; it does not establish that every historical failure was a timing race. Crashes and persistent Docker failures remain explicit errors with evidence rather than blind restarts.

## Eli's visual workflow

- Add focused UI/CSS guidance for typography, spacing, form boundaries, keyboard focus, readable contrast, modal layout, card actions and responsive states.
- Require screenshot evidence for the current source revision before delivering supported full-stack UI changes, alongside existing functional acceptance. Backend-only changes do not require screenshots.
- Save representative desktop, mobile and open-form screenshots from real browser tests. The starter browser test demonstrates the capture convention; existing applications' tests must be adapted by Eli.
- Export images before the disposable test workspace is deleted, including images from failing tests. Send actual normalized image pixels to the model. Metadata and filenames alone do not count as image access.
- Preserve project/revision/run attribution in private local evidence outside executable source. Allow Eli to re-open an image by its returned ID. Invalid images and cross-project references are rejected.
- Keep only the latest image batch in active model context to avoid repeatedly sending all historical screenshots. Up to four regular PNG/JPEG/WebP files are exported per command, with byte/dimension limits; symlinks and nested paths are not exported.

Browser tests save directly under `ROOZ_SCREENSHOT_DIR`, supplied by the test runtime. The images are from the disposable test app, not the user's running Live Preview. Images and transcripts are evidence, not instructions.

Eli must combine screenshot inspection with actual application tests: a task status change must make a successful API write, move the displayed card and remain correct after reload. Passing DOM assertions alone does not establish visual quality; screenshots alone do not establish functional correctness. Live model design judgment still requires evaluation on real tasks.

## Verification

144 automated Python checks passed. Coverage includes delayed/missing/unsafe port mappings, exited containers, Stop during port discovery, evidence export from failed runs before cleanup, image validation/isolation/revision attribution, the UI delivery guard, and actual SDK image serialization.

A controlled real Chromium/HTTP/SQLite recovery test reproduced a stale starter selector, repaired the test through the host loop, exercised create/edit/reload/delete and backend reads, and delivered three actual desktop/form/mobile screenshots to the model interface before final acceptance passed. The model responses were scripted; this is proof of the evidence/control pipeline, not a live Eli quality evaluation.

Nine existing real-browser full-stack preview checks passed: detection, start/iframe, API create/list, new tab, refresh/origin persistence, logs, stop/start data persistence, scoped reset and mobile layout. Native adapters were used only for these controlled tests. Production still uses Docker; Docker was not executable in this environment. The user's task board and its reported movement/form defects have not been repaired by this host update.
