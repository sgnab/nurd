# Plain HTML + FastAPI preview correction

This complete source update includes the earlier Stage 1.9 browser-runner correction.
It updates Rooz-AI, not the generated notes app. Stop Rooz-AI, replace matching source
files, then run:

```bash
bash setup.sh
bash start.sh
```

The .env and user data are not included or replaced. Setup uses cached Docker layers
and verifies the supported React and plain HTML/API runtime paths.

## Confirmed host gap

The uploaded notes app has frontend/index.html and backend/main.py, but no frontend
package.json. Previous full-stack detection required package.json, so it offered only
the static server. That server cannot implement /api/notes or POST requests.

Detection now recognizes plain HTML + backend without requiring React or a fake build
step. Full-stack mode serves saved frontend assets with the actual ASGI backend.
The selector says Full-stack app (UI + API). A remembered static selection no longer
takes priority when starting a detected API application; explicit static mode remains
available and warns that it does not run the backend.

rooz-preview.json supports frontend_type: auto, static or vite. Existing three-field
configurations remain valid. React projects still run their production build.

## Separate confirmed problems in the submitted app

The generated project was inspected and its included backend tests were executed
unchanged in a disposable local copy. Both fail on the current uploaded revision:

- test_create_list_notes: GET /api/notes returns 404 instead of 200.
- test_update_note_and_delete: its final GET returns an error object rather than a
  notes array, producing a TypeError during the deletion assertion.

In backend/main.py, GET /{full_path:path} is registered before /health and GET
/api/notes. It catches those GET requests first, and deliberately returns 404 for
paths beginning with api. POST/PUT/DELETE can work while GET remains broken.
The earlier passing-test report does not establish that this revision passed.

Other source findings for Eli to repair and verify:

- DB_PATH = "notes.db" ignores DATABASE_PATH/ROOZ_DATA_DIR, so the database sits in
  the disposable preview source/work directory and will not survive rebuilds.
- The browser test triggers a blank-title alert without accepting the dialog.
- The blank-title-reversion toHaveValue assertion is missing await.
- The verification script needs disposable database setup and reliable process
  cleanup; current startup waits on the very GET route that is intercepted.

No generated-application source was edited in this update. These failures must stay
visible until Eli repairs the application and reruns the final revision.

## Send Eli this task

> Inspect the current notes app. Keep its plain HTML/JavaScript and FastAPI stack.
> Move the catch-all frontend GET route after the specific API and health routes so
> it cannot intercept GET /api/notes. Honor DATABASE_PATH/ROOZ_DATA_DIR and initialize
> storage reliably. Fix the browser test's alert handling and missing awaited
> assertion without removing validation checks. Run the saved verification against
> disposable storage, covering real UI/API CRUD, blank-title rejection and
> reload/restart persistence. Use verify_app, repair failures and report actual
> results from the final source revision. Do not claim integration from API tests alone.

After Eli verifies the app, use Preview -> Full-stack app (UI + API) -> Start/Refresh.
Running means the runtime started; it does not itself establish that all app features
passed acceptance. Real external providers remain outside this check.
