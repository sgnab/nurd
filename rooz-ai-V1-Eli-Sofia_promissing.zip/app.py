"""Run: python -m uvicorn app:app --host 127.0.0.1 --port 8001"""
import os
from pathlib import Path
from dotenv import load_dotenv
from rooz.api import create_app
from rooz.models import ModelRouter
ROOT=Path(__file__).resolve().parent
load_dotenv(ROOT/'.env')
DEFAULT_MODEL=os.getenv('CODING_MODEL') or os.getenv('OPENAI_MODEL') or 'gpt-6-luna'
router=ModelRouter(DEFAULT_MODEL)
def client_factory():return router.client(DEFAULT_MODEL)
app=create_app(Path(os.getenv('ROOZ_DATA_DIR',str(ROOT/'data'))),ROOT/'static',client_factory,
               DEFAULT_MODEL,model_router=router)
