# Stage 1.5 — shared team conversation

This update is based on your accepted `rooz-ai-review.zip`. Live Preview remains deferred.

## Install

1. Stop Rooz-AI with Ctrl+C.
2. Extract this update **inside your existing rooz-ai folder**, replacing matching source files. Keep your `data/`, `.env` and `.venv`.
3. Run `bash start.sh`.
4. Refresh the browser with Cmd+Shift+R once to load the updated chat interface.

No package installation or Docker image rebuild is needed. The entrypoint, test runner, image, dependency files and startup scripts are unchanged. On the first startup against the accepted Stage 1 database, the app backs it up to `data/backups/before-stage15.sqlite3` before applying additive schema changes. Existing rooms, messages, files and downloads remain available. Keep your original review ZIP as the source checkpoint; reverting to its old storage code also requires its matching pre-migration database backup because the old code uses positional inserts.

## Addressing agents

All names are case-insensitive, for user messages and agent-to-agent calls:

- `@Sofia`, `@sofia`, `@SOFIA` and `@sOfIa` are equivalent.
- `Hey Sofia`, `HI ELI`, and `Alex, ...` also address that agent at the start of a message.
- Several explicit mentions, such as `@Sofia @ELI`, ask those agents to respond sequentially, in mention order.
- Without an address, the dropdown chooses the responding agent.
- Ordinary references such as “Is Sofia here?” do not automatically call Sofia. All agents know the team roster.
- Mentions in code blocks, inline code and quoted lines do not trigger another agent.

The composer follows a direct user address and remembers the request's original recipient when reopening the room. It does not switch to a helper simply because that helper was called during the request.

## Shared history and teammate calls

All agents use this room's transcript and project workspace. Recent context is supplied with explicit speaker labels. Agents can use `read_room` to page through earlier room history. That tool cannot access another room.

Agents use the structured `call_agent` tool to ask each other for help. A visible handoff shows the caller, recipient, reason and task. The called agent's answer appears under their own name, and the caller receives that answer and the current project file manifest before continuing. Plain model-written claims or mentions do not silently launch work; an actual tool call is required.

Example:

> @Alex ask Sofia to suggest a small settings screen, then summarize her proposal.

Sofia may call Eli about a backend question; Eli may ask Alex for a clarification. All calls are sequential in this stage, including calls back to a waiting caller. Code and test results are attributed to the agent/reply that produced them. A shared project remains locked to one active root request, so a second chat cannot race its writes.

Stop cancels the entire current chain and any active test container. Saved replies and code remain. A server restart marks unfinished requests and handoffs interrupted rather than leaving them “working.”

Repeated identical requests and active call cycles receive feedback instead of creating another call. A request allows up to 12 handoffs, six nested levels, 24 model/tool rounds per agent reply, and 15 minutes overall. These are loop/deadline safeguards, not release gates. Agents can use an existing answer or finish with a clear explanation when a limit is reached. This stage has no acceptance registry, release approval or parallel implementation workflow.

## Try these checks

1. Send `@SOFIA hello`, `@sofia hello` and `Hey sOfIa`. Confirm Sofia replies.
2. Send `@ELI hello`. Confirm Eli replies.
3. Tell Alex a simple project detail, then ask Sofia about it in the same room. Confirm shared context.
4. Ask Alex to call Sofia for a small UI opinion. Confirm the visible handoff, Sofia's reply and Alex's continuation.
5. Ask Sofia to call Eli for a backend opinion. Confirm the same behavior.
6. Stop during a teammate call. Confirm the chain stops and another request can start.
7. Refresh/restart and verify the shared replies and handoff statuses remain.
8. Open a new room and confirm it does not display the prior room's messages.

## Implementation boundaries

- `rooz/team.py` owns case-insensitive addressing, transcript speaker labels and handoff safeguards.
- `rooz/agents.py` owns model/tool execution and waiting for a called agent's reply. The tested GPT-6.1 Sol Responses path is retained.
- `rooz/storage.py` adds shared-history access, handoff messages, recipient/check/file attribution and additive migrations.
- `rooz/api.py` routes the user's addressed recipients into one sequential request.
- The existing chat UI displays handoffs and keeps check/file results attached to the producing reply.

There are no changes to Live Preview, provider credentials, the Docker runner or generated projects in this update.

## Verification scope

Run the local protocol/backend tests with your development dependencies installed:

```bash
.venv/bin/python -m unittest discover -s tests -p 'test_*.py' -v
```

Optional browser checks:

```bash
.venv/bin/python -m tests.browser_stage1
.venv/bin/python -m tests.browser_team
```

Verification used real Chromium, HTTP, SQLite, downloads and controlled Python test execution. Agent replies were scripted, and SDK Responses/Chat requests used mock HTTP transports. This establishes the routing and tool protocol; it does not establish that a real model will choose the right teammate on every task. Actual OpenAI collaboration should be checked with the prompts above using your existing saved key. Docker test execution remains the same implementation you accepted in Stage 1.

Reports are in `verification/stage15/`. No browser screenshots, credentials or user data are included.
