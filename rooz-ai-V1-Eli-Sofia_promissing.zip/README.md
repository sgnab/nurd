# Rooz-AI

Latest update: [GPT-6 Luna coding model](LUNA_UPDATE.md).

Previous runtime update: [Preview readiness and visual development](VISUAL_PREVIEW_UPDATE.md).

Previous developer update: [Eli autonomous implementation and repair](ELI_AUTONOMOUS_REPAIR.md).

Previous update: [Named projects and preview startup](NAMED_PROJECTS_PREVIEW_FIX.md).

A separate local app for direct conversations with Alex, Sofia and Eli. No old Chaos Room orchestrator, requirement registry, release gates, or automatic delegation is loaded.

## Start on your Mac

Extract this folder beside your existing Chaos Room folder. Open Terminal in **rooz-ai**:

```bash
bash setup.sh
```

Open `.env` and set `OPENAI_API_KEY` once. Use your existing key; no new provider account is needed. Set `OPENAI_MODEL` to a model your account can use. An already-exported `OPENAI_API_KEY` is reused automatically. Keys remain on the server and are not sent to the browser or test containers.

The default coding model is now `gpt-6-luna`. Set `CODING_MODEL=gpt-6-luna` in an existing `.env` to override an older `OPENAI_MODEL` value. The chosen coding model is shared by Alex, Sofia and Eli.

With Docker Desktop running, `bash setup.sh` installs dependencies, builds or updates the shared test/preview image, and checks it. You do not rebuild on every restart.

The first image build downloads Python/Node/browser dependencies and can take several minutes. Subsequent tests reuse it. Verify that environment:

```bash
.venv/bin/python -m tests.check_environment
```

Then start the app:

```bash
bash start.sh
```

Open **http://127.0.0.1:8001**. This uses its own environment and port; Chaos Room is unchanged. Use Ctrl+C in Terminal to stop the server. `ROOZ_PORT` can select another port.

You can chat without Docker. Code is still returned when checks fail or the test environment is unavailable, with the actual result displayed. Nothing unavailable is marked as passed. The local service is intended to run on `127.0.0.1`, not as a public hosted application.

## What is included

- Polished responsive chat with five recent conversations and older conversations collapsed.
- Alex, Sofia and Eli selected in the composer; no agent list in the sidebar.
- Persistent conversations and project workspaces; server restarts preserve saved files.
- Markdown, highlighted code, Copy and Download on code blocks.
- Immutable downloadable versions of saved files and a current-project ZIP.
- One shared isolated test environment: Python, Node, pytest, FastAPI/httpx, and Playwright/Chromium.
- Practical agent-written tests. If new saved code has no current check, an automatic syntax/browser-load smoke check is attempted.
- Executed check output, failures and unavailable results displayed separately from model-written claims.
- Stop cancels pending model work or the active test container. Saved code remains available.

A completed chat request means its response was delivered. It does not mean the project passed release approval. Check badges report executed commands for the identified code revision. Syntax/browser-load smoke is explicitly labeled and does not establish functional coverage.

Stage 1 supports standalone Python and plain HTML/CSS/JavaScript particularly well. React/TypeScript or other additional dependencies need their own project build setup; the runner does not download dependencies while executing generated code. Network calls in tests need local fixtures.

## Boundaries for later stages

| Component | Responsibility | Later extension |
|---|---|---|
| `rooz/storage.py` | SQLite conversations, projects, runs, immutable artifacts and workspace paths | Extend schemas without replacing stored chats |
| `rooz/agents.py` | Direct agent roles, tool calls, practical checks, Stop | Add Alex's coordination through a separate module |
| `rooz/runner.py` | Disposable Docker snapshots and process cleanup | Reuse for later checks without mixing in preview |
| `rooz/api.py` | Small HTTP endpoints between UI and services | Add preview endpoints separately |
| `static/` | Chat presentation and downloads | Keep conversation endpoints stable |
| `sandbox/` | Shared agent runtime and small smoke checker | Version the image when dependencies change |

`app.py` only loads configuration and connects these components. Each new chat gets a project by default. The API already supports creating another chat against an existing `project_id`, so projects are separate from conversations. One active request per project prevents overlapping writes in Stage 1; different projects can run independently.

Live preview, mock-first frontend/backend development, parallel assignments and final staging integration are **not** included in this stage.

## Stage 1 checks

Install development dependencies only if you want to rerun the app's tests:

```bash
.venv/bin/python -m pip install -r requirements-dev.txt
.venv/bin/python -m unittest discover -s tests -p 'test_*.py' -v
```

For browser tests:

```bash
.venv/bin/python -m playwright install chromium
.venv/bin/python -m tests.browser_stage1
```

Development verification passed 20 backend/protocol checks, ten real-Chromium UI workflow checks, and the smoke checker's valid/broken-browser cases. Python and Node fixture tests actually executed. Tests use a scripted model or mock HTTP transport and a controlled native test adapter; production uses only Docker. The Docker image and real OpenAI calls could not be executed in the development environment and must be verified on your Mac. `tests.check_environment` exercises actual Python/SQLite, Node and browser interaction inside your built image. Test reports are in `verification/`.

UI browser tests use a temporary data directory and a scripted test server. They do not call OpenAI or alter normal app data. Native subprocess execution exists only in test fixtures; it is never a production fallback.

## Continuing to Stage 2

After you test and accept Stage 1, export the current source:

```bash
bash export-review.sh
```

This saves **rooz-ai-review.zip** beside the Rooz-AI folder, excluding credentials, conversations, generated project files and installed dependencies. Send that ZIP with your next-stage feedback. Keep `data/` in place when updating Rooz-AI; it contains your conversations and saved project code.

The renderer is already bundled: Node is not required to launch the host UI. Optional renderer build sources are in `ui/`; third-party licenses are in `static/vendor/NOTICES.txt`.


## Corrected-check recovery and 45-minute requests

See [CHECK_RECOVERY_UPDATE.md](CHECK_RECOVERY_UPDATE.md) for explicit corrected-test reruns, retained failure history, accurate cancellation reasons, and build-before-browser guidance. The request deadline is 45 minutes; there is no agent turn-count cutoff. Individual operation timeouts still detect stalled calls.


## Choose a coding model in chat

Use the Coding model dropdown to select GPT-6 Luna, DeepSeek V4.1 Flash or GPT-6.1 Sol per request. Add `DEEPSEEK_API_KEY` alongside your existing OpenAI key in `.env`, then restart to enable DeepSeek. See [MODEL_PICKER_DEEPSEEK.md](MODEL_PICKER_DEEPSEEK.md) for setup and verification details.

## Agent monitoring and security tests

Open **Monitor & tests** in the top bar. Free boundary checks run automatically
for a new agent fingerprint; opt-in live model tests use temporary projects and
fake secrets. See [SECURITY_MONITORING.md](SECURITY_MONITORING.md) for results,
limits and verification scope. No Docker rebuild or new dependency is needed.
