# Rooz-AI — complete source through Stage 1.7

This is the complete application, not an incremental update. It includes shared team chat, case-insensitive addressing and handoffs, code downloads, attachments/image input, isolated code tests and user-operated static Live Preview.

## New laptop setup

Prerequisites: Python 3.11 or newer and Docker Desktop. Python, Docker, downloaded dependencies and the Docker image are not inside this source ZIP.

1. Extract the ZIP and open Terminal inside the extracted `rooz-ai` folder.
2. Run:

   ```bash
   bash setup.sh
   ```

3. Open the newly created `.env` file. Set `OPENAI_API_KEY` to your own key and `OPENAI_MODEL` to your preferred available model. The example matches the app's existing default. If moving your old `.env`, copy that instead to preserve your previous configuration. Update any old-machine absolute paths in it, such as `ROOZ_DATA_DIR`.
4. Start Docker Desktop, then build the shared image once on this laptop:

   ```bash
   docker build -t rooz-ai-runner:stage1 -f sandbox/Dockerfile .
   bash start.sh
   ```

5. Open http://127.0.0.1:8001 in your browser.

For subsequent launches, start Docker Desktop and run `bash start.sh`. The image and installed dependencies are reused. Chat can work without Docker; running code tests and Live Preview requires it.

## Moving conversations and generated projects

This ZIP contains application source, tests and the previous verification reports. It does not contain your private API key, saved chats, uploads or generated project data from the old laptop.

To retain those, stop Rooz-AI on the old laptop and copy its entire `data/` folder into this new `rooz-ai` folder before starting. If you configured a custom `ROOZ_DATA_DIR`, copy that directory instead and update the new configuration. Copy your old `.env` privately if you want to reuse its saved settings. Recreate the Python virtual environment with setup; do not copy `.venv` across laptops.

## Optional checks

```bash
.venv/bin/python -m tests.check_environment
.venv/bin/python -m tests.check_preview_docker
```

The second command checks an actual Docker-backed static preview, then removes its disposable container and files. No provider call is required for these checks. Build-environment reports are under `verification/`; they are historical reports, not results from your new laptop. Docker launch was unavailable in that environment, so it still needs verification locally.

For preview usage and limits, see `STAGE17.md`. `STAGE15.md` and `STAGE16.md` describe the earlier shared-chat and attachment features. Their incremental-update installation instructions are unnecessary for this complete bundle.
