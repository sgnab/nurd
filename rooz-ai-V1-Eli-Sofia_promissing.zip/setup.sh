#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
valid_python() {
  "$1" -c 'import sys; raise SystemExit(0 if sys.version_info >= (3,11) else 1)' >/dev/null 2>&1
}
rooz_python=""
if [ -n "${ROOZ_PYTHON:-}" ]; then
  if ! valid_python "$ROOZ_PYTHON"; then
    printf 'ROOZ_PYTHON must point to Python 3.11 or newer.\n' >&2
    exit 1
  fi
  rooz_python="$ROOZ_PYTHON"
else
  for candidate in .venv/bin/python python3.13 python3.12 python3.11 python3 python; do
    if command -v "$candidate" >/dev/null 2>&1 && valid_python "$candidate"; then
      rooz_python="$candidate"
      break
    fi
  done
  if [ -z "$rooz_python" ] && command -v conda >/dev/null 2>&1; then
    candidate="$(conda run -n rooz python -c 'import sys; print(sys.executable)' 2>/dev/null || true)"
    if [ -n "$candidate" ] && valid_python "$candidate"; then rooz_python="$candidate"; fi
  fi
fi
if [ -z "$rooz_python" ]; then
  printf 'Python 3.11+ was not found. If you use Conda, run:\n  conda create -n rooz python=3.11\n  conda activate rooz\n  bash setup.sh\n' >&2
  exit 1
fi
if [ -e .venv ] && { [ ! -x .venv/bin/python ] || ! valid_python .venv/bin/python; }; then
  printf 'The existing .venv is not usable with Python 3.11+. Rename it, then rerun setup; your .env and data stay in place.\n' >&2
  exit 1
fi
printf 'Using: %s\n' "$rooz_python"
if [ -x /Applications/Docker.app/Contents/Resources/bin/docker ]; then
  export PATH="/Applications/Docker.app/Contents/Resources/bin:$PATH"
fi
if ! command -v docker >/dev/null 2>&1; then
  printf 'Docker CLI was not found. Install/start Docker Desktop, then rerun bash setup.sh.\n' >&2
  exit 1
fi
"$rooz_python" - <<'PY'
import subprocess
import sys
try:
    result = subprocess.run(['docker', 'info'], stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, timeout=20)
except (OSError, subprocess.TimeoutExpired):
    print('Docker did not respond. Start Docker Desktop, wait until it is ready, then rerun bash setup.sh.', file=sys.stderr)
    raise SystemExit(1)
if result.returncode:
    print('Docker is not ready. Start Docker Desktop, then rerun bash setup.sh.', file=sys.stderr)
    print(result.stderr[-1000:], file=sys.stderr)
    raise SystemExit(1)
PY
if [ ! -x .venv/bin/python ]; then "$rooz_python" -m venv .venv; fi
.venv/bin/python -m pip install -r requirements.txt
if [ ! -f .env ]; then
  if [ -f .env.example ]; then
    (umask 077; cp .env.example .env)
  else
    (umask 077; printf 'OPENAI_API_KEY=\nDEEPSEEK_API_KEY=\nCODING_MODEL=gpt-6-luna\n' > .env)
  fi
fi
printf '\nBuilding/updating the Docker runner using cached layers…\n'
docker build -t rooz-ai-runner:stage1 -f sandbox/Dockerfile .
printf '\nVerifying the Docker runner: API, React production build and browser connection…\n'
.venv/bin/python tests/check_stage18_docker.py
.venv/bin/python tests/check_stage19_docker.py
.venv/bin/python tests/check_browser_runner_docker.py
printf '\nSetup and runner verification passed.\nYour existing .env and data were preserved. Configure OPENAI_API_KEY in .env if needed.\nStart Rooz-AI: bash start.sh\n'
