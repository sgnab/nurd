# Node Playwright runner correction

This patch applies over Stage 1.9. Stop Rooz-AI, replace the matching files, then run:

```bash
bash setup.sh
bash start.sh
```

setup.sh installs/builds the updated runner and now also executes a JavaScript
Playwright/Chromium smoke check. No separate npm install or global Playwright setup
is required on the Mac. Normal restarts still use start.sh alone.

## Cause

The image included Python Playwright but not @playwright/test. The Python CLI also
has the name playwright, but has no test subcommand. The reported unknown command
therefore establishes a runner/setup failure, not a failed browser assertion.
The original bootstrap also linked dependencies only beside package.json; root-level
verification scripts could not resolve frontend test tools when metadata was nested.

## Changes

- Add @playwright/test 1.64.1 to the bundled Node dependency profile and lockfile,
  matching the image's existing Python Playwright/browser version.
- Link test dependencies at the disposable project root when it has no package.json.
  Preserve writable Vite caches and the read-only installed package tree.
- Prefer the Node test CLI in the test process PATH; keep Python imports unchanged.
- Give Eli explicit commands for TypeScript specs and Python tests, plus CLI recovery
  guidance. Add a specific runtime hint to failed tool output for unknown command test.
- State clearly that passing API tests alone do not verify frontend integration.
- Run the new Node browser check as part of setup; failed checks prevent setup success.

## Verified here

- 113 host tests passed against the final source. Models in these tests are scripted
  fixtures.
- Actual `npx --no-install playwright test frontend/runner.spec.ts --workers=1`
  executed a TypeScript test and a real Chromium click/assertion successfully from
  a root without package.json. A local browser-executable adapter was used; this
  was not a Docker run and does not validate the user's notes app.
- React TypeScript/production build passed with the updated lockfile.
- The new Docker check is tests/check_browser_runner_docker.py and runs during setup.
  Actual Docker execution remains to be confirmed on the Mac.

This patch updates the developer environment and guidance. It does not modify the
generated notes app. After setup, tell Eli:

> Rerun the existing UI and integration tests using the updated browser runner.
> Diagnose and fix any failures. Preserve the application and valid assertions;
> report actual results. Backend tests alone do not establish end-to-end acceptance.
