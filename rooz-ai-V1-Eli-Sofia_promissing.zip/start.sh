#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
if [ -x /Applications/Docker.app/Contents/Resources/bin/docker ]; then
  export PATH="/Applications/Docker.app/Contents/Resources/bin:$PATH"
fi
if [ ! -x .venv/bin/python ]; then printf 'Run bash setup.sh first.\n'; exit 1; fi
exec .venv/bin/python -m uvicorn app:app --host 127.0.0.1 --port "${ROOZ_PORT:-8001}"
