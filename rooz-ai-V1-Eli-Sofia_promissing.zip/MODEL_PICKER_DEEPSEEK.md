# Coding-model dropdown and DeepSeek V4.1 Flash

## Use it

Keep your existing `.env` and `data/`. Stop Rooz, replace its source with this release, and add your DeepSeek key locally:

```dotenv
OPENAI_API_KEY=your-existing-openai-key
DEEPSEEK_API_KEY=your-deepseek-key
CODING_MODEL=gpt-6-luna
```

Do not paste keys into chat. An existing `CODING_MODEL`/`OPENAI_MODEL` setting still supplies the initial default. Both keys are independent; only configure the providers you intend to use.

Start `bash start.sh`. Select **DeepSeek V4.1 Flash** from the **Coding model** dropdown beside the agent selector. Switch back to **GPT-6 Luna** whenever wanted. GPT-6.1 Sol is also available with an OpenAI key and model access. If the dropdown is absent after replacement, refresh the browser.

The dropdown remembers the selection per project in that browser. Every submitted request saves its model in SQLite, so the chosen model is visible beside its replies and survives conversation reload. The selected model applies to the addressed agent and its teammate calls. It is fixed throughout that request. You can select another model for the next request.

A configured key means present on the server, not connectivity verified. Missing keys are identified before a job is queued. Provider access, billing and connection errors remain visible; there is no automatic model/provider fallback. Existing projects, generated apps, previews, tests and repair behavior are preserved.

## API compatibility

DeepSeek uses the official model ID `deepseek-flash` at `https://api.deepseek.com/chat/completions`, currently the V4.1 Flash route. The provider controls upgrades behind that ID; this is not a pinned model revision.

The integration uses the existing OpenAI Python SDK with DeepSeek's documented Chat Completions format: thinking enabled, high reasoning effort and `max_tokens=32768`. OpenAI's `max_completion_tokens` is not sent to DeepSeek. Current-request reasoning state is returned to the API during tool/repair turns, including provisional final answers. It is not stored in chat/check results or displayed to the user. Earlier stored assistant text has no retained reasoning state. Uploaded images and captured screenshots use the existing image-input flow.

Luna and Sol keep the existing OpenAI Responses route. The API client is selected per request; another project's selection cannot change an active request's provider or model. Truncated DeepSeek responses are rejected before tool execution.

References checked:
- https://api-docs.deepseek.com/
- https://api-docs.deepseek.com/guides/thinking_mode/
- https://api-docs.deepseek.com/guides/tool_calls/
- https://api-docs.deepseek.com/guides/vision/

## Installation impact

No dependency or runner-image changes are needed. No Docker rebuild is needed. The database migration adds a nullable `model` column to run records. Older replies without recorded models remain readable and are not assigned invented historical model labels.

The shared request deadline is 45 minutes. Agent turn-count limits have been removed; individual-operation timeouts remain for stalled calls. This update does not alter Eli's generated apps or install DeepSeek Harness.

## Verification

180 automated tests passed. Coverage includes the existing suite, DeepSeek SDK serialization, reasoning-state preservation across provisional replies and tool repairs, actual screenshot pixels in requests, truncated-output handling, cancellation, provider-key isolation, simultaneous project selections, saved run-model metadata, missing-key rejection, teammate handoffs, and the production dropdown/send/render functions exercised with a minimal Node DOM adapter. JavaScript and shell syntax checks passed.

Automated provider tests use the real OpenAI SDK with controlled HTTP responses; this establishes request serialization and routing, not live DeepSeek access or model quality. Live validation requires your local DeepSeek key and account balance. Actual browser and Docker execution were not run in this environment. No screenshot or Docker success is claimed from the JavaScript-function tests.
