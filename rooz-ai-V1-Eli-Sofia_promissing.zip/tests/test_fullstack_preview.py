import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import AsyncMock
import httpx
from rooz.app_profile import FULLSTACK_ENTRY,profile,source_files
from rooz.preview import PreviewService,DockerPreview
from rooz.storage import Store
from tests.fullstack_support import NativeFullstackPreview,write_app


class ProfileTests(unittest.TestCase):
    def test_plain_html_plus_backend_does_not_need_package_json(self):
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory);write_app(root)
            (root/'frontend/package.json').unlink()
            self.assertEqual(profile(root)['frontend_type'],'static')
            (root/'rooz-preview.json').write_text(json.dumps({'frontend_type':'auto'}))
            self.assertEqual(profile(root)['frontend_type'],'static')

    def test_inference_and_explicit_configuration(self):
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory);write_app(root)
            self.assertEqual(profile(root)['backend_app'],'main:app')
            (root/'rooz-preview.json').write_text(json.dumps({'frontend_dir':'../outside'}))
            with self.assertRaises(ValueError):profile(root)
            (root/'rooz-preview.json').write_text(json.dumps({'backend_app':'main:app; rm -rf /'}))
            with self.assertRaises(ValueError):profile(root)

    def test_source_snapshot_excludes_credentials_data_dependencies_and_links(self):
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory);write_app(root)
            for name in ['.env','notes.sqlite3','data/secret.json','node_modules/x.js','frontend/dist/index.html']:
                p=root/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text('do not copy')
            (root/'leak.py').symlink_to(root/'.env')
            (root/'frontend/src/data').mkdir(parents=True)
            (root/'frontend/src/data/options.json').write_text('{"source_asset":true}')
            files=source_files(root)
            self.assertIn('backend/main.py',files)
            self.assertIn('frontend/src/data/options.json',files)
            self.assertFalse(any('do not copy' in b.decode() for b in files.values()))


class FullstackPreviewTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.temp=tempfile.TemporaryDirectory();self.addCleanup(self.temp.cleanup)
        self.store=Store(self.temp.name);self.chat=self.store.create_chat()
        self.root=self.store.workspace(self.chat['project_id']);write_app(self.root)
        self.backend=NativeFullstackPreview();self.addAsyncCleanup(self.backend.close)
        self.service=PreviewService(self.store,self.backend)

    async def test_plain_html_real_api_persistence_and_old_selection_upgrade(self):
        (self.root/'frontend/package.json').unlink()
        (self.root/'frontend/build.cjs').unlink()
        (self.root/'frontend/app.js').write_text('console.log("asset")')
        self.service.save(self.chat['id'],{**self.service.empty(self.chat['id']),'entry':'frontend/index.html'})
        started=await self.service.start(self.chat['id'])
        self.assertEqual(started['status'],'running',started)
        self.assertEqual(started['entry'],FULLSTACK_ENTRY)
        async with httpx.AsyncClient(base_url=started['url'],trust_env=False) as client:
            self.assertEqual((await client.get('/api/notes')).json(),[])
            self.assertEqual((await client.get('/static/app.js')).status_code,200)
            await client.post('/api/notes',json={'title':'Plain HTML API'})
        row=await self.service.start(self.chat['id'],refresh=True)
        self.assertEqual(row['status'],'running',row)
        self.assertIn('no frontend build required',row['logs'])
        async with httpx.AsyncClient(base_url=row['url'],trust_env=False) as client:
            self.assertEqual((await client.get('/api/notes')).json()[0]['title'],'Plain HTML API')
        await self.service.stop(self.chat['id'])

    async def test_start_upgrades_running_static_server_when_backend_is_detected(self):
        (self.root/'frontend/package.json').unlink()
        first=await self.service.start(self.chat['id'],'frontend/index.html')
        self.assertEqual(first['mode'],'static')
        second=await self.service.start(self.chat['id'])
        self.assertEqual(second['status'],'running',second)
        self.assertEqual(second['mode'],'fullstack')
        async with httpx.AsyncClient(trust_env=False) as client:
            self.assertEqual((await client.get(second['url']+'api/notes')).status_code,200)
        await self.service.stop(self.chat['id'])

    async def test_real_http_crud_validation_refresh_stop_restart_reset_and_spa(self):
        before=self.store.revision(self.chat['project_id'])
        started=await self.service.start(self.chat['id'])
        self.assertEqual(started['status'],'running',started)
        self.assertEqual(started['mode'],'fullstack')
        self.assertEqual(started['entry'],FULLSTACK_ENTRY)
        url=started['url']
        async with httpx.AsyncClient(base_url=url,trust_env=False) as client:
            self.assertIn('Notes preview',(await client.get('/')).text)
            self.assertEqual((await client.get('/saved/123')).status_code,200)
            self.assertEqual((await client.get('/assets/missing.js')).status_code,404)
            self.assertEqual((await client.get('/api/missing')).status_code,404)
            for path in ['/.env','/backend/main.py']:
                self.assertEqual((await client.get(path)).status_code,404)
            self.assertEqual((await client.post('/api/notes',json={'title':'   '})).status_code,422)
            created=(await client.post('/api/notes',json={'title':'First'})).json()
            self.assertEqual((await client.get('/api/notes')).json(),[created])
            self.assertEqual((await client.put('/api/notes/'+str(created['id']),json={'title':'Edited'})).status_code,200)
        refreshed=await self.service.start(self.chat['id'],refresh=True)
        self.assertEqual(refreshed['status'],'running',refreshed)
        self.assertEqual(refreshed['url'],url)
        restarted=PreviewService(self.store,self.backend)
        await restarted.recover()
        self.assertEqual((await restarted.describe(self.chat['id']))['status'],'stopped')
        final=await restarted.start(self.chat['id'])
        self.assertEqual(final['status'],'running',final)
        async with httpx.AsyncClient(base_url=final['url'],trust_env=False) as client:
            rows=(await client.get('/api/notes')).json();self.assertEqual(rows[0]['title'],'Edited')
            self.assertEqual((await client.delete('/api/notes/'+str(created['id']))).status_code,204)
            self.assertEqual((await client.get('/api/notes')).json(),[])
            await client.post('/api/notes',json={'title':'Reset me'})
        await restarted.reset_data(self.chat['id'])
        final=await restarted.start(self.chat['id'])
        async with httpx.AsyncClient(base_url=final['url'],trust_env=False) as client:
            self.assertEqual((await client.get('/api/notes')).json(),[])
        await restarted.stop(self.chat['id'])
        self.assertEqual(self.store.revision(self.chat['project_id']),before)

    async def test_build_failure_reports_logs_without_running(self):
        (self.root/'frontend/build.cjs').write_text('throw Error("deliberate build failure")')
        failed=await self.service.start(self.chat['id'])
        self.assertEqual(failed['status'],'error');self.assertIsNone(failed['url'])
        self.assertIn('deliberate build failure',failed['logs'])

    async def test_room_data_isolation(self):
        other=self.store.create_chat();write_app(self.store.workspace(other['project_id']))
        one=await self.service.start(self.chat['id']);two=await self.service.start(other['id'])
        async with httpx.AsyncClient(trust_env=False) as client:
            await client.post(one['url']+'api/notes',json={'title':'Private room'})
            self.assertEqual((await client.get(two['url']+'api/notes')).json(),[])
        await self.service.reset_data(other['id'])
        async with httpx.AsyncClient(trust_env=False) as client:
            self.assertEqual(len((await client.get(one['url']+'api/notes')).json()),1)
        await self.service.shutdown()


class DockerFullstackTests(unittest.IsolatedAsyncioTestCase):
    async def test_launch_keeps_source_read_only_data_scoped_and_port_local(self):
        docker=DockerPreview();docker.command=AsyncMock(side_effect=[(0,'id'),(0,json.dumps({'8080/tcp':[{'HostIp':'127.0.0.1','HostPort':'32124'}]}))])
        url=await docker.launch_fullstack('name',Path('/tmp/source'),{'frontend_dir':'frontend','backend_dir':'backend','backend_app':'main:app'},Path('/tmp/data'),'session','owner')
        self.assertEqual(url,'http://127.0.0.1:32124/')
        args=docker.command.call_args_list[0].args
        for value in ['/tmp/source:/source:ro','/tmp/data:/data:rw','--read-only','no-new-privileges','127.0.0.1::8080','/opt/rooz/fullstack_server.py']:
            self.assertIn(value,args)
        self.assertNotIn('OPENAI_API_KEY',' '.join(args))
