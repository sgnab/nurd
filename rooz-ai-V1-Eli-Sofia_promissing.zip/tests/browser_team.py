"""Real Chromium/HTTP/storage; scripted agent replies and native controlled-test adapter."""
import json,os,socket,subprocess,sys,tempfile,time,urllib.request
from pathlib import Path
from playwright.sync_api import sync_playwright,expect
from tests.browser_projects_support import create_project

app_root=Path(__file__).parents[1];evidence=Path(os.getenv('ROOZ_TEST_OUTPUT') or tempfile.mkdtemp(prefix='rooz-team-evidence-'));evidence.mkdir(parents=True,exist_ok=True)
with socket.socket() as sock:sock.bind(('127.0.0.1',0));port=sock.getsockname()[1]
with tempfile.TemporaryDirectory() as data:
 env=os.environ.copy();env.update(ROOZ_FIXTURE_DATA=data,ROOZ_FIXTURE_PORT=str(port))
 log=(evidence/'server.log').open('w');server=subprocess.Popen([sys.executable,str(app_root/'tests/team_fixture_server.py')],env=env,stdout=log,stderr=subprocess.STDOUT)
 try:
  base='http://127.0.0.1:'+str(port)
  for _ in range(100):
   try:urllib.request.urlopen(base+'/api/chats',timeout=1);break
   except OSError:time.sleep(.1)
  else:raise RuntimeError('Fixture did not start')
  results=[]
  with sync_playwright() as p:
   browser=p.chromium.launch(executable_path=os.getenv('ROOZ_BROWSER_EXECUTABLE') or None,headless=True,args=['--no-sandbox','--disable-dev-shm-usage','--disable-gpu'])
   context=browser.new_context(viewport={'width':1440,'height':1050},accept_downloads=True);page=context.new_page();errors=[]
   page.on('pageerror',lambda e:errors.append(str(e)));page.goto(base);create_project(page,"Initial project")
   expect(page.locator('#agentSelect')).to_be_enabled()
   def send(text):page.locator('#prompt').fill(text);page.locator('#send').click()
   send('Hey sOfIa')
   expect(page.locator('.message-meta strong').last).to_have_text('Sofia',timeout=15000);expect(page.locator('#agentSelect')).to_have_value('sofia')
   page.reload();expect(page.locator('#agentSelect')).to_have_value('sofia');results.append('Mixed-case greeting routes to Sofia and recipient survives reload')
   send('@ELI hello')
   expect(page.locator('.message-meta strong').last).to_have_text('Eli',timeout=15000);expect(page.locator('#agentSelect')).to_have_value('eli');results.append('Uppercase @ELI routes to Eli')
   send('@aLeX @SOFIA both say hello')
   expect(page.locator('.message-meta strong')).to_have_count(4,timeout=15000)
   assert page.locator('.message-meta strong').all_text_contents()[-2:]==['Alex','Sofia'];results.append('Several explicit names respond sequentially in mention order')
   send('@ALex teamflow')
   expect(page.get_by_text('ALEX_RESULT: combined answer',exact=True)).to_be_visible(timeout=20000)
   expect(page.locator('.team-handoff')).to_have_count(2)
   assert page.locator('.team-handoff strong').all_text_contents()==['Alex → Sofia','Sofia → Eli']
   expect(page.locator('.handoff-status.completed')).to_have_count(2)
   answers=page.locator('.message-meta strong').all_text_contents()[-3:];assert answers==['Eli','Sofia','Alex'],answers
   eli=page.locator('article').filter(has_text='ELI_RESULT: saved and tested logic')
   expect(eli.get_by_text('Checks passed',exact=True)).to_be_visible();expect(eli.get_by_role('link',name='↓ logic.py',exact=True)).to_be_visible()
   sofia=page.locator('article').filter(has_text='SOFIA_RESULT: UI uses Eli’s logic');expect(sofia.locator('.check-card')).to_have_count(0)
   page.locator('.team-handoff summary').first.click();expect(page.get_by_text('teamflow: prepare the UI with Eli’s help',exact=True)).to_be_visible()
   results.append('Nested visible handoffs complete and check/file attribution stays with Eli')
   with page.expect_download() as item:eli.get_by_role('link',name='↓ logic.py',exact=True).click()
   item.value.save_as(evidence/'logic.py');assert (evidence/'logic.py').read_text()=='def double(n): return n*2\n';results.append('Peer-created code downloads match the executed file')
   page.reload();expect(page.locator('.team-handoff')).to_have_count(2);expect(page.get_by_text('ALEX_RESULT: combined answer',exact=True)).to_be_visible();results.append('Shared replies and handoff statuses persist after refresh')
   page.screenshot(path=str(evidence/'team-desktop.png'),full_page=True)
   send('@alex stopflow')
   expect(page.locator('.handoff-status.working')).to_have_count(1,timeout=15000)
   expect(page.locator('.working').filter(has_text='Sofia')).to_be_visible()
   page.get_by_role('button',name='■ Stop').click()
   expect(page.locator('.handoff-status.cancelled')).to_have_count(1,timeout=10000);expect(page.locator('#send')).to_be_visible();results.append('Stop cancels the called agent and entire waiting chain')
   send('@eLI hello again');expect(page.locator('.message-meta strong').last).to_have_text('Eli',timeout=15000);results.append('A new addressed request succeeds after Stop')
   page.set_viewport_size({'width':390,'height':844});page.wait_for_timeout(200)
   assert page.evaluate('document.documentElement.scrollWidth<=innerWidth')
   expect(page.locator('#prompt')).to_be_visible();page.screenshot(path=str(evidence/'team-mobile.png'),full_page=True);results.append('Mobile team conversation has no horizontal page overflow')
   page.get_by_label('Open navigation').click();create_project(page,'Another project')
   expect(page.locator('#agentSelect')).to_be_enabled();expect(page.locator('.team-handoff')).to_have_count(0);expect(page.locator('.message-meta')).to_have_count(0);results.append('New room starts without another room’s messages or handoffs')
   assert not errors,errors;browser.close()
  (evidence/'results.json').write_text(json.dumps({'real_chromium':True,'real_openai':False,'docker_execution':False,'test_execution':'Native subprocesses on controlled fixtures only','passed':results},indent=2))
  print('\n'.join('PASS '+r for r in results));print('Evidence:',evidence)
 finally:server.terminate();server.wait(timeout=10);log.close()
