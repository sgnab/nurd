"""Real UI -> HTTP -> SQLite CRUD, validation and reload; no intercepted API requests."""
import sys
from playwright.sync_api import sync_playwright, expect

def run(url):
    with sync_playwright() as playwright:
        browser=playwright.chromium.launch(args=['--no-sandbox','--disable-dev-shm-usage'])
        try:
            page=browser.new_page();errors=[]
            page.on('pageerror',lambda error:errors.append(str(error)))
            page.on('response',lambda response:errors.append(f'HTTP {response.status} {response.url}') if response.status>=500 else None)
            page.goto(url)
            expect(page.get_by_role('heading',name='Notes integration fixture')).to_be_visible()
            page.get_by_label('Title').fill('Browser note')
            with page.expect_response(lambda r:r.url.endswith('/api/notes') and r.request.method=='POST') as created:
                page.get_by_role('button',name='Add note',exact=True).click()
            assert created.value.status==201
            row=page.get_by_role('listitem').filter(has_text='Browser note');expect(row).to_be_visible()
            row.get_by_role('button',name='Edit',exact=True).click()
            page.get_by_label('Title').fill('Edited browser note')
            page.get_by_role('button',name='Save note',exact=True).click()
            row=page.get_by_role('listitem').filter(has_text='Edited browser note');expect(row).to_be_visible()
            page.reload();expect(row).to_be_visible()
            records=page.request.get(url+'api/notes').json()
            assert any(r['title']=='Edited browser note' for r in records)
            row.get_by_role('button',name='Delete',exact=True).click();expect(row).to_have_count(0)
            page.get_by_label('Title').fill('   ')
            with page.expect_response(lambda r:r.url.endswith('/api/notes') and r.request.method=='POST') as invalid:
                page.get_by_role('button',name='Add note',exact=True).click()
            assert invalid.value.status==422
            expect(page.get_by_role('alert')).to_have_text('Title cannot be blank')
            page.get_by_label('Title').fill('Persist across restart')
            page.get_by_role('button',name='Add note',exact=True).click()
            expect(page.get_by_role('listitem').filter(has_text='Persist across restart')).to_be_visible()
            assert not errors,errors
            print('PASS: browser create/read/edit/delete, reload persistence, real API values, blank-title failure and console/server-error checks')
        finally:browser.close()

if __name__=='__main__':run(sys.argv[1])
