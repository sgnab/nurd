import { useEffect, useState, FormEvent } from 'react';
import { Button } from './components/ui/button';
type Note = { id: number; title: string };
export default function App() {
  const [notes, setNotes] = useState<Note[]>([]);
  const [title, setTitle] = useState('');
  const [editing, setEditing] = useState<number | null>(null);
  const [error, setError] = useState('');
  async function load() {
    const response = await fetch('/api/notes');
    if (!response.ok) throw new Error('Unable to load notes');
    setNotes(await response.json());
  }
  useEffect(() => { load().catch(error => setError(String(error))); }, []);
  async function save(event: FormEvent) {
    event.preventDefault();setError('');
    try {
      const response = await fetch('/api/notes' + (editing === null ? '' : '/' + editing), {
        method: editing === null ? 'POST' : 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ title })
      });
      if (!response.ok) throw new Error((await response.json()).detail);
      setTitle('');setEditing(null);await load();
    } catch (error) { setError(error instanceof Error ? error.message : 'Save failed'); }
  }
  async function remove(id: number) {
    try {
      const response = await fetch('/api/notes/' + id, { method: 'DELETE' });
      if (!response.ok) throw new Error('Delete failed');
      await load();
    } catch (error) { setError(String(error)); }
  }
  return <main className="mx-auto max-w-2xl px-6 py-16">
    <h1 className="mb-8 text-3xl font-semibold">Notes integration fixture</h1>
    <form onSubmit={save} className="flex flex-wrap items-end gap-3">
      <label className="grid gap-2">Title<input className="rounded border p-3" value={title} onChange={event => setTitle(event.target.value)} /></label>
      <Button type="submit">{editing === null ? 'Add note' : 'Save note'}</Button>
    </form><p role="alert" className="py-4 text-red-700">{error}</p>
    <ul className="grid gap-4">{notes.map(note => <li key={note.id} className="flex items-center gap-3 rounded border bg-white p-4">
      <span className="mr-auto">{note.title}</span>
      <button onClick={() => { setEditing(note.id);setTitle(note.title); }}>Edit</button>
      <button onClick={() => remove(note.id)}>Delete</button>
    </li>)}</ul>
  </main>;
}
