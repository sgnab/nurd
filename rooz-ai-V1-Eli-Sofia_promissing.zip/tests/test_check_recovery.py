"""A corrected executed probe settles its own failure, with the original preserved."""
import asyncio
import json
import tempfile
import unittest
from pathlib import Path
from rooz import eli
from rooz.agents import AgentService
from rooz.storage import Store
from tests.support import Message, Model, call, NativeTestRunner


def invoke(name, **args):return Message(calls=[call(name,args)])

class CorrectedModel(Model):
    """Use the actual check ID returned by the host, as a real model must."""
    async def create(self, **kwargs):
        if self.script and self.script[0]=='corrected':
            self.script.pop(0)
            result=json.loads(next(m['content'] for m in reversed(kwargs['messages']) if m['role']=='tool'))
            self.script.insert(0,invoke('rerun_check',check_id=result['check_id'],command=self.corrected,
                reason='Build the fixture first in this fresh workspace; retain the same rendered-content assertion.'))
        return await super().create(**kwargs)

class CorrectedChecks(unittest.IsolatedAsyncioTestCase):
    async def test_corrected_command_runs_and_settles_original_without_repeating_broken_probe(self):
        with tempfile.TemporaryDirectory() as directory:
            store=Store(directory);chat=store.create_chat('Corrected check');root=store.workspace(chat['project_id'])
            # The runner copies the source anew for EVERY command; an earlier build cannot leak in.
            (root/'source.txt').write_text('Requested UI')
            original=['python','-c',"from pathlib import Path; assert Path('built.txt').read_text() == 'Requested UI'"]
            corrected=['python','-c',"from pathlib import Path; Path('built.txt').write_text(Path('source.txt').read_text()); assert Path('built.txt').read_text() == 'Requested UI'"]
            model=CorrectedModel([invoke('run_tests',command=original),'corrected',Message('Verified the corrected probe.')]);model.corrected=corrected
            runner=NativeTestRunner();run=store.start_run(chat['id'],'eli','Verify the requested UI')
            await AgentService(store,runner,lambda:model,'fixture').execute(run,asyncio.Event())
            result=store.run(run['id']);self.assertEqual(result['status'],'completed')
            self.assertEqual(runner.commands,[original,corrected])
            first,second=result['checks'];self.assertEqual([first['status'],second['status']],['failed','passed'])
            self.assertEqual(first['check_id'],second['check_id']);self.assertNotEqual(first['execution_id'],second['execution_id'])
            self.assertEqual(first['superseded_by'],second['execution_id'])
            self.assertEqual(second['replaces_execution'],first['execution_id'])
            self.assertIn('FileNotFoundError',first['output'])
            self.assertFalse((root/'built.txt').exists(),'Disposable build output must not change project source')
            self.assertEqual(eli.verification_state(result['checks'],first['reply_id'],first['revision'])['failed'],[])

    async def test_failed_corrected_command_stays_unresolved(self):
        with tempfile.TemporaryDirectory() as directory:
            store=Store(directory);chat=store.create_chat('Failed corrected check')
            model=CorrectedModel([invoke('run_tests',command=['python','-c','assert False']),
                'corrected',Message('Premature completion'),TimeoutError()]);model.corrected=['python','-c','assert 1 == 2']
            run=store.start_run(chat['id'],'eli','Verify behavior')
            await AgentService(store,NativeTestRunner(),lambda:model,'fixture').execute(run,asyncio.Event())
            result=store.run(run['id']);self.assertEqual(result['status'],'failed')
            checks=result['checks'];self.assertEqual([c['status'] for c in checks],['failed','failed'])
            self.assertNotIn('superseded_by',checks[0])
            state=eli.verification_state(checks,checks[0]['reply_id'],checks[0]['revision'])
            self.assertEqual(state['failed'],[checks[1]])
            self.assertTrue(any('Host verification feedback' in str(m) for m in model.prompts[-1]['messages']))

    async def test_python_alias_reruns_the_same_full_acceptance_check(self):
        with tempfile.TemporaryDirectory() as directory:
            store=Store(directory);chat=store.create_chat('Acceptance alias');root=store.workspace(chat['project_id'])
            (root/'tests').mkdir();(root/'tests/verify.py').write_text('assert False')
            model=Model([invoke('run_tests',command=['python3','tests/verify.py']),
                invoke('read_files',paths=['tests/verify.py']),
                invoke('write_files',files=[{'path':'tests/verify.py','content':'assert 2 + 3 == 5'}]),
                invoke('verify_app'),Message('Acceptance verified.')])
            run=store.start_run(chat['id'],'eli','Verify acceptance')
            await AgentService(store,NativeTestRunner(),lambda:model,'fixture').execute(run,asyncio.Event())
            result=store.run(run['id']);self.assertEqual(result['status'],'completed')
            self.assertEqual(result['checks'][0]['check_id'],result['checks'][1]['check_id'])

    async def test_verify_then_python_alias_share_the_same_acceptance_identity(self):
        with tempfile.TemporaryDirectory() as directory:
            store=Store(directory);chat=store.create_chat('Reverse alias');root=store.workspace(chat['project_id'])
            (root/'tests').mkdir();(root/'tests/verify.py').write_text('assert False')
            model=Model([invoke('verify_app'),invoke('read_files',paths=['tests/verify.py']),
                invoke('write_files',files=[{'path':'tests/verify.py','content':'assert 2 + 3 == 5'}]),
                invoke('run_tests',command=['python3','tests/verify.py']),Message('Acceptance verified.')])
            run=store.start_run(chat['id'],'eli','Verify acceptance')
            await AgentService(store,NativeTestRunner(),lambda:model,'fixture').execute(run,asyncio.Event())
            result=store.run(run['id']);self.assertEqual(result['status'],'completed')
            self.assertEqual(result['checks'][0]['check_id'],result['checks'][1]['check_id'])

    def test_unknown_other_reply_and_passed_check_cannot_be_replaced(self):
        check={'check_id':'check-one','reply_id':'reply-one','status':'failed','command':['python','test.py']}
        for reply,ident,reason in [('reply-two','check-one','Correct setup and retain behavior assertions'),
                                   ('reply-one','made-up','Correct setup and retain behavior assertions'),
                                   ('reply-one','check-one','skip')]:
            with self.assertRaises(ValueError):eli.replacement_target([check],reply,ident,reason)
        self.assertIs(eli.replacement_target([check],'reply-one','check-one','Correct setup and retain behavior assertions'),check)
        with self.assertRaises(ValueError):eli.replacement_target([check,{**check,'status':'passed'}],'reply-one','check-one','Correct setup and retain behavior assertions')

    async def test_full_acceptance_cannot_be_relabelled_as_a_smaller_probe(self):
        with tempfile.TemporaryDirectory() as directory:
            store=Store(directory);chat=store.create_chat('Acceptance entrypoint');root=store.workspace(chat['project_id'])
            (root/'tests').mkdir();(root/'tests/verify.py').write_text('assert False, "full acceptance still failing"')
            model=CorrectedModel([invoke('verify_app'),'corrected',TimeoutError()]);model.corrected=['python','-c','assert True']
            runner=NativeTestRunner();run=store.start_run(chat['id'],'eli','Verify full app')
            await AgentService(store,runner,lambda:model,'fixture').execute(run,asyncio.Event())
            self.assertEqual(runner.commands,[['python','tests/verify.py']])
            self.assertEqual(store.run(run['id'])['checks'][0]['status'],'failed')
            self.assertIn('Keep tests/verify.py',str(model.prompts[-1]['messages']))
