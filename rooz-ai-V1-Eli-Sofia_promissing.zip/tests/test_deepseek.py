"""DeepSeek's documented wire format with real SDK + controlled HTTP replies."""
import asyncio,base64,io,json,os,tempfile,unittest
from pathlib import Path
from unittest.mock import patch
import httpx
from openai import AsyncOpenAI
from PIL import Image
from rooz.agents import AgentService,request_error
from rooz.models import ModelRouter
from rooz.storage import Store
from tests.support import NativeTestRunner

class DeepSeekTests(unittest.IsolatedAsyncioTestCase):
    async def test_thinking_tools_repair_images_and_draft_history(self):
        requests=[]
        check='''import os
from pathlib import Path
from PIL import Image
from calc import add
Image.new('RGB',(40,30),(80,130,160)).save(Path(os.environ['ROOZ_SCREENSHOT_DIR'])/'desktop.png')
assert add(2,3)==5
'''
        actions=[('write_files',{'files':[{'path':'calc.py','content':'def add(a,b): return a-b\n'},{'path':'check.py','content':check}]}),
                 ('run_tests',{'command':['python','check.py']}),'Confirm to proceed.',
                 ('read_files',{'paths':['calc.py']}),('write_files',{'files':[{'path':'calc.py','content':'def add(a,b): return a+b\n'}]}),
                 ('run_tests',{'command':['python','check.py']}),'Saved and verified.']
        async def handler(request):
            self.assertEqual(str(request.url),'https://api.deepseek.com/chat/completions')
            body=json.loads(request.content);index=len(requests);requests.append(body)
            self.assertEqual(body['model'],'deepseek-flash');self.assertEqual(body['max_tokens'],32768)
            self.assertNotIn('max_completion_tokens',body);self.assertEqual(body['thinking'],{'type':'enabled'})
            self.assertEqual(body['reasoning_effort'],'high')
            assistants=[m for m in body['messages'] if m['role']=='assistant']
            for m in assistants:self.assertIn('reasoning_content',m)
            if index>0:self.assertTrue(any(m.get('reasoning_content')=='private-reasoning-0' for m in assistants))
            if index>=3:
                drafts=[m for m in assistants if m.get('content')=='Confirm to proceed.']
                self.assertEqual(len(drafts),1);self.assertEqual(drafts[0]['reasoning_content'],'private-reasoning-2')
            if index>=2:
                images=[p for m in body['messages'] if isinstance(m.get('content'),list) for p in m['content'] if p.get('type')=='image_url']
                self.assertEqual(len(images),1)
                image=Image.open(io.BytesIO(base64.b64decode(images[0]['image_url']['url'].split(',',1)[1])))
                self.assertEqual(image.size,(40,30))
            action=actions[index];message={'role':'assistant','content':None,'reasoning_content':'private-reasoning-'+str(index)}
            if isinstance(action,tuple):
                name,args=action;message['tool_calls']=[{'id':'call-'+str(index),'type':'function','function':{'name':name,'arguments':json.dumps(args)}}]
            else:message['content']=action
            return httpx.Response(200,json={'id':'deepseek-'+str(index),'object':'chat.completion','created':1,'model':'deepseek-flash',
                'choices':[{'index':0,'message':message,'finish_reason':'tool_calls' if isinstance(action,tuple) else 'stop'}]})
        with tempfile.TemporaryDirectory() as directory:
            store=Store(directory);chat=store.create_chat('DeepSeek repair');run=store.start_run(chat['id'],'eli','Implement and verify addition',model='deepseek-flash')
            client=AsyncOpenAI(api_key='fixture-deepseek',base_url='https://api.deepseek.com',max_retries=0,http_client=httpx.AsyncClient(transport=httpx.MockTransport(handler)))
            await AgentService(store,NativeTestRunner(),lambda:client,'gpt-6-luna').execute(run,asyncio.Event())
            result=store.run(run['id']);self.assertEqual(result['status'],'completed',store.messages(chat['id'])[-1]['content'])
            self.assertEqual([c['status'] for c in result['checks']],['failed','passed'])
            self.assertEqual(result['model'],'deepseek-flash');self.assertEqual(len(requests),7)
            self.assertNotIn('private-reasoning',json.dumps(store.messages(chat['id'])))
            self.assertNotIn('private-reasoning',json.dumps(result))

    async def test_truncated_tool_response_cannot_write_files(self):
        async def handler(request):
            return httpx.Response(200,json={'id':'truncated','object':'chat.completion','created':1,'model':'deepseek-flash',
                'choices':[{'index':0,'finish_reason':'length','message':{'role':'assistant','content':None,'reasoning_content':'fixture',
                    'tool_calls':[{'id':'c','type':'function','function':{'name':'write_files','arguments':json.dumps({'files':[{'path':'partial.py','content':'bad'}]})}}]}}]})
        with tempfile.TemporaryDirectory() as directory:
            store=Store(directory);chat=store.create_chat();run=store.start_run(chat['id'],'eli','Write code',model='deepseek-flash')
            client=AsyncOpenAI(api_key='fixture',base_url='https://api.deepseek.com',max_retries=0,http_client=httpx.AsyncClient(transport=httpx.MockTransport(handler)))
            await AgentService(store,NativeTestRunner(),lambda:client,'gpt-6-luna').execute(run,asyncio.Event())
            self.assertEqual(store.run(run['id'])['status'],'failed');self.assertFalse((store.workspace(chat['project_id'])/'partial.py').exists())
            self.assertIn('no partial tools',store.messages(chat['id'])[-1]['content'])

    async def test_provider_error_names_deepseek_and_redacts_both_keys(self):
        response=httpx.Response(401,request=httpx.Request('POST','https://api.deepseek.com/chat/completions'))
        from openai import AuthenticationError
        with patch.dict(os.environ,{'OPENAI_API_KEY':'openai-fixture-value','DEEPSEEK_API_KEY':'deepseek-fixture-value'}):
            error=AuthenticationError('Invalid deepseek-fixture-value and openai-fixture-value',response=response,body={'message':'Invalid deepseek-fixture-value and openai-fixture-value'})
            text=request_error(error,'deepseek-flash')
            self.assertIn('DEEPSEEK_API_KEY',text);self.assertNotIn('deepseek-fixture-value',text);self.assertNotIn('openai-fixture-value',text)

    async def test_stop_cancels_deepseek_call_without_changing_model(self):
        from types import SimpleNamespace
        from unittest.mock import AsyncMock
        async def create(**kwargs):await asyncio.sleep(1000)
        with tempfile.TemporaryDirectory() as directory:
            store=Store(directory);chat=store.create_chat();run=store.start_run(chat['id'],'eli','Wait',model='deepseek-flash')
            client=SimpleNamespace(chat=SimpleNamespace(completions=SimpleNamespace(create=create)),close=AsyncMock())
            service=AgentService(store,NativeTestRunner(),lambda:client,'gpt-6-luna');service.start(run);await asyncio.sleep(.02)
            task=service.active[run['id']][1];service.stop(run['id']);await asyncio.wait_for(task,2)
            self.assertEqual(store.run(run['id'])['end_reason'],'user_stop');self.assertEqual(store.run(run['id'])['model'],'deepseek-flash')
            client.close.assert_awaited_once()

class ModelConfiguration(unittest.TestCase):
    def test_provider_clients_use_separate_keys_and_endpoint(self):
        with patch.dict(os.environ,{'OPENAI_API_KEY':'openai-fixture','DEEPSEEK_API_KEY':'deepseek-fixture'},clear=True),patch('rooz.models.AsyncOpenAI') as factory:
            router=ModelRouter('gpt-6-luna');router.client('deepseek-flash')
            self.assertEqual(factory.call_args.kwargs['api_key'],'deepseek-fixture')
            self.assertEqual(factory.call_args.kwargs['base_url'],'https://api.deepseek.com')
            router.client('gpt-6-luna');self.assertEqual(factory.call_args.kwargs['api_key'],'openai-fixture')
            self.assertNotIn('base_url',factory.call_args.kwargs)
            self.assertNotIn('fixture',json.dumps(router.public_models()))
    def test_missing_selected_key_never_falls_back_to_other_provider(self):
        with patch.dict(os.environ,{'OPENAI_API_KEY':'openai-fixture'},clear=True),patch('rooz.models.AsyncOpenAI') as factory:
            with self.assertRaisesRegex(ValueError,'DEEPSEEK_API_KEY'):ModelRouter('gpt-6-luna').client('deepseek-flash')
            factory.assert_not_called()
    def test_invalid_model_is_rejected_and_existing_default_is_preserved(self):
        router=ModelRouter('gpt-4.1-mini');self.assertIn('gpt-4.1-mini',{r['id'] for r in router.public_models()})
        with self.assertRaisesRegex(ValueError,'dropdown'):router.validate('invented-model')
