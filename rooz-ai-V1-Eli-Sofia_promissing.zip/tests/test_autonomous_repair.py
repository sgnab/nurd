"""Scripted model + real subprocess regressions for the host's completion loop."""
import asyncio
import json
import tempfile
import unittest
from pathlib import Path
from rooz import eli
from rooz.agents import AgentService
from rooz.storage import Store
from tests.support import Model, Message, call, NativeTestRunner


def tool(name, **args):
    return Message(calls=[call(name, args)])


class RepairFlowTests(unittest.IsolatedAsyncioTestCase):
    async def execute_script(self, script, existing=None, runner=None):
        temp=tempfile.TemporaryDirectory();self.addCleanup(temp.cleanup)
        store=Store(temp.name);chat=store.create_chat('Task board')
        root=store.workspace(chat['project_id'])
        for name,content in (existing or {}).items():
            path=root/name;path.parent.mkdir(parents=True,exist_ok=True);path.write_text(content)
        run=store.start_run(chat['id'],'eli','Build and verify the task board; repair failures within scope.')
        model=Model(script)
        await AgentService(store,runner or NativeTestRunner(),lambda:model,'fixture').execute(run,asyncio.Event())
        return store,chat,run,model

    async def test_repeated_proposals_do_not_end_failed_repair_and_unrelated_pass_does_not_clear_it(self):
        command=['python','tests/browser_check.py']
        script=[tool('run_tests',command=command),
                Message('The old Check backend button is gone. Confirm to proceed.'),
                tool('run_tests',command=['python','-c','assert True']),
                Message('Backend passed. I will fix browser checks next.'),
                tool('run_tests',command=command),
                Message('This fulfills acceptance. Confirm to proceed.'),
                tool('read_files',paths=['tests/browser_check.py']),
                tool('write_files',files=[{'path':'tests/browser_check.py','content':'from app_ui import controls\nassert "Create task" in controls\n'}]),
                tool('run_tests',command=command),Message('Updated the stale test and verified the requested control.')]
        store,chat,run,model=await self.execute_script(script,{
            'app_ui.py':'controls=["Create task", "Search tasks"]\n',
            'tests/browser_check.py':'from app_ui import controls\nassert "Check backend" in controls\n'})
        self.assertEqual(store.run(run['id'])['status'],'completed')
        checks=store.run(run['id'])['checks']
        self.assertEqual([c['status'] for c in checks],['failed','passed','failed','passed'])
        answers=[m['content'] for m in store.messages(chat['id']) if m['role']=='assistant']
        self.assertEqual(answers,['Updated the stale test and verified the requested control.'])
        feedback=[m for m in model.prompts[-1]['messages'] if m['role']=='user' and 'Host verification feedback:' in str(m['content'])]
        self.assertEqual(len(feedback),3)
        self.assertTrue(all('Check backend' in m['content'] for m in feedback))

    async def test_host_runs_acceptance_on_the_edited_revision_then_returns_result_to_model(self):
        script=[tool('read_files',paths=['backend/main.py']),
                tool('write_files',files=[{'path':'backend/main.py','content':'value=2\n'}]),
                Message('Draft before host verification.'),Message('Final acceptance passed on the saved source.')]
        store,chat,run,model=await self.execute_script(script,{
            'backend/main.py':'value=1\n','frontend/index.html':'<h1>Task board</h1>',
            'tests/verify.py':'from backend.main import value\nassert value == 2\nprint("final revision verified")\n'})
        self.assertEqual(store.run(run['id'])['status'],'completed')
        self.assertEqual(store.messages(chat['id'])[-1]['content'],'Final acceptance passed on the saved source.')
        self.assertIn('final revision verified',json.dumps(model.prompts[-1]['messages']))
        self.assertEqual(store.run(run['id'])['checks'][0]['kind'],'full-stack acceptance')

    async def test_stale_acceptance_pass_is_rerun_after_another_edit(self):
        script=[tool('verify_app'),tool('read_files',paths=['backend/main.py']),
                tool('write_files',files=[{'path':'backend/main.py','content':'value=2\n'}]),
                Message('Ready.'),Message('Acceptance reran after the change.')]
        store,chat,run,model=await self.execute_script(script,{
            'backend/main.py':'value=1\n','frontend/index.html':'<h1>Task board</h1>',
            'tests/verify.py':'from backend.main import value\nassert value in (1,2)\n'})
        checks=store.run(run['id'])['checks']
        self.assertEqual(len(checks),2)
        self.assertNotEqual(checks[0]['revision'],checks[1]['revision'])
        self.assertEqual(checks[-1]['revision'],store.revision(run['project_id']))

    async def test_unavailable_runtime_remains_incomplete_instead_of_fake_success(self):
        store,chat,run,model=await self.execute_script([
            tool('write_files',files=[{'path':'calc.py','content':'value=2\n'}]),
            Message('Draft.'),Message('Docker is unavailable; no passing verification is claimed.')],
            runner=NativeTestRunner(unavailable=True))
        self.assertEqual(store.run(run['id'])['status'],'failed')
        self.assertEqual(store.run(run['id'])['checks'][-1]['status'],'unavailable')
        self.assertIn('completion is not established',store.messages(chat['id'])[-1]['content'])

    async def test_observed_external_blocker_is_recorded_without_turning_failure_into_pass(self):
        command=['python','external.py'];diagnostic='Missing API key: LIVE_PROVIDER_API_KEY is not configured'
        store,chat,run,model=await self.execute_script([
            tool('run_tests',command=command),
            tool('report_execution_blocker',command=command,category='external_service',evidence=diagnostic,
                 reason='The disposable runtime has no authorized external provider credentials.',
                 next_action='Configure an authorized provider environment for this external-only check.'),
            Message('Local checks do not establish this external integration.')],
            {'external.py':'raise RuntimeError('+repr(diagnostic)+')\n'})
        self.assertEqual(store.run(run['id'])['status'],'failed')
        check=store.run(run['id'])['checks'][0]
        self.assertEqual(check['status'],'failed')
        self.assertEqual(check['blocker']['category'],'external_service')

    async def test_repair_continues_beyond_old_64_turn_cap_and_finishes_after_verified_fix(self):
        command=['python','check.py']
        store,chat,run,model=await self.execute_script([
            tool('run_tests',command=command),
            *[Message('Confirm to proceed.') for _ in range(70)],
            tool('read_files',paths=['check.py']),
            tool('write_files',files=[{'path':'check.py','content':'assert 2 + 3 == 5\n'}]),
            tool('run_tests',command=command),Message('Repaired and verified after the previous turn boundary.')],
            {'check.py':'assert 2 + 3 == 4\n'})
        result=store.run(run['id'])
        self.assertEqual(result['status'],'completed')
        self.assertGreater(len(model.prompts),64)
        self.assertEqual([c['status'] for c in result['checks']],['failed','passed'])
        self.assertNotIn('work-step limit',store.messages(chat['id'])[-1]['content'])

    async def test_stale_environment_diagnostic_cannot_block_a_repaired_revision(self):
        command=['python','external.py'];diagnostic='Missing API key: LIVE_PROVIDER_API_KEY is not configured'
        store,chat,run,model=await self.execute_script([
            tool('run_tests',command=command),tool('read_files',paths=['external.py']),
            tool('write_files',files=[{'path':'external.py','content':'assert True\n'}]),
            tool('report_execution_blocker',command=command,category='external_service',evidence=diagnostic,
                 reason='This diagnostic came from a previous source revision.',next_action='Configure external credentials for testing this check.'),
            tool('run_tests',command=command),Message('The repaired revision passes.')],
            {'external.py':'raise RuntimeError('+repr(diagnostic)+')\n'})
        self.assertEqual(store.run(run['id'])['status'],'completed')
        self.assertIn('current revision before reporting a blocker',json.dumps(model.prompts[-1]['messages']))
        self.assertNotIn('blocker',store.run(run['id'])['checks'][0])

    async def test_responses_api_recovery_preserves_call_results_and_continues_after_two_proposals(self):
        import httpx
        from openai import AsyncOpenAI
        with tempfile.TemporaryDirectory() as directory:
            store=Store(directory);chat=store.create_chat('Responses repair')
            root=store.workspace(chat['project_id']);(root/'feature.py').write_text('value=1\n')
            (root/'check.py').write_text('from feature import value\nassert value == 2\n')
            command=['python','check.py'];requests=[]
            script=[('run_tests',{'command':command}), 'Confirm to proceed.', 'I will repair next. Confirm?',
                    ('read_files',{'paths':['feature.py']}),
                    ('write_files',{'files':[{'path':'feature.py','content':'value=2\n'}]}),
                    ('run_tests',{'command':command}), 'Repaired and verified.']
            async def handler(request):
                self.assertEqual(request.url.path,'/v1/responses')
                body=json.loads(request.content);requests.append(body);index=len(requests)-1
                action=script[index]
                if isinstance(action,tuple):
                    name,args=action
                    output=[{'type':'function_call','id':'item_'+str(index),'call_id':'call_'+str(index),
                             'name':name,'arguments':json.dumps(args),'status':'completed'}]
                else:
                    output=[{'type':'message','id':'msg_'+str(index),'role':'assistant','status':'completed',
                             'content':[{'type':'output_text','text':action,'annotations':[]}]}]
                return httpx.Response(200,json={'id':'response_'+str(index),'object':'response','created_at':1,
                                               'status':'completed','model':'gpt-6.1-sol','output':output})
            client=AsyncOpenAI(api_key='fixture-not-real',http_client=httpx.AsyncClient(transport=httpx.MockTransport(handler)))
            run=store.start_run(chat['id'],'eli','Repair and test the function.')
            await AgentService(store,NativeTestRunner(),lambda:client,'gpt-6.1-sol').execute(run,asyncio.Event())
            self.assertEqual(store.run(run['id'])['status'],'completed',store.messages(chat['id'])[-1]['content'])
            self.assertEqual(store.messages(chat['id'])[-1]['content'],'Repaired and verified.')
            results={item['call_id']:json.loads(item['output']) for item in requests[-1]['input']
                     if item.get('type')=='function_call_output'}
            self.assertEqual(results['call_0']['status'],'failed')
            self.assertEqual(results['call_5']['status'],'passed')
            self.assertEqual(len(requests),7)


class VerificationEvidenceTests(unittest.TestCase):
    def test_other_reply_and_stale_pass_cannot_change_current_failure(self):
        def check(command,status,reply='eli',revision='old'):
            return dict(command=command,status=status,reply_id=reply,revision=revision,kind='full-stack acceptance')
        failed=check(['python','tests/verify.py'],'failed')
        state=eli.verification_state([failed,check(['python','-c','assert True'],'passed'),
                                     check(['python','tests/verify.py'],'passed',reply='sofia')],'eli','new')
        self.assertEqual(state['failed'],[failed]);self.assertIsNone(state['acceptance'])

    def test_starter_locator_and_missing_project_file_cannot_be_external_blockers(self):
        for evidence in ('Timeout waiting for get_by_role button Check backend',
                         "No such file or directory: '/work/tests/verify.py'",
                         'Connection refused at http://127.0.0.1:8080/api/tasks'):
            check={'status':'failed','output':evidence}
            with self.assertRaises(ValueError):
                eli.execution_blocker(check,'runtime_setup',evidence,'Sufficient explanatory reason here','Specific next external action here')

    def test_fabricated_blocker_evidence_is_rejected(self):
        with self.assertRaises(ValueError):
            eli.execution_blocker({'status':'failed','output':'Assertion failed'},'external_service',
                                  'Missing API key in runtime','Credentials unavailable for testing','Configure the provider credentials')
