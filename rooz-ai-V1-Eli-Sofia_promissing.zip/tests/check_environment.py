"""Run after building the image: .venv/bin/python -m tests.check_environment"""
import asyncio,json,tempfile
from pathlib import Path
from rooz.runner import DockerRunner
async def main():
 runner=DockerRunner();stop=asyncio.Event()
 with tempfile.TemporaryDirectory() as d:
  root=Path(d)
  (root/'check.py').write_text('import sqlite3\nc=sqlite3.connect(":memory:")\nc.execute("create table tasks(id integer, title text)")\nc.execute("insert into tasks values(1, ?)", ("Read",))\nassert c.execute("select title from tasks").fetchone()[0]=="Read"\nprint("Python and SQLite behavior passed")\n')
  (root/'index.html').write_text('<!doctype html><html><body><button id="add">Add</button><output id="n">0</output><script>add.onclick=()=>n.textContent=Number(n.textContent)+1</script></body></html>')
  (root/'browser.py').write_text('from playwright.sync_api import sync_playwright\nwith sync_playwright() as p:\n b=p.chromium.launch(headless=True,args=["--no-sandbox","--disable-dev-shm-usage"])\n page=b.new_page()\n page.goto("file:///work/index.html")\n page.locator("#add").click()\n assert page.locator("#n").inner_text()=="1"\n b.close()\nprint("Browser interaction passed")\n')
  for command in (['python','check.py'],['node','-e','require("node:assert/strict").equal(2+3,5); console.log("Node behavior passed")'],['python','browser.py']):
   result=await runner.run(root,command,stop);print(json.dumps(result,indent=2))
   if result['status']!='passed':raise SystemExit(1)
 print('Shared Docker test environment verified for Python, Node and browser interactions.')
asyncio.run(main())
