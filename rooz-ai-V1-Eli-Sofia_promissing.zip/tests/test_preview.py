import asyncio,json,tempfile,unittest
from pathlib import Path
from unittest.mock import AsyncMock,patch
import httpx
from fastapi.testclient import TestClient
from rooz.api import create_app
from rooz.storage import Store
from rooz.preview import DockerPreview,PreviewService,PreviewError,static_files
from tests.preview_support import NativePreview
from tests.support import NativeTestRunner,Model

HTML='<!doctype html><html><head><link rel="stylesheet" href="style.css"></head><body><h1>Counter</h1><button id="add">Add</button><output id="count">0</output><script src="app.js"></script></body></html>'
JS='let n=0;document.querySelector("#add").onclick=()=>document.querySelector("#count").textContent=++n;'

class PreviewTests(unittest.IsolatedAsyncioTestCase):
 async def asyncSetUp(self):
  self.temp=tempfile.TemporaryDirectory();self.addCleanup(self.temp.cleanup);self.store=Store(self.temp.name);self.chat=self.store.create_chat();self.backend=NativePreview();self.service=PreviewService(self.store,self.backend);self.addAsyncCleanup(self.backend.close)
 def write(self,name,content):
  path=self.store.workspace(self.chat['project_id'])/name;path.parent.mkdir(parents=True,exist_ok=True);path.write_text(content);return path
 def counter(self,prefix=''):
  self.write(prefix+'index.html',HTML);self.write(prefix+'style.css','body{color:rgb(20,60,30)}');self.write(prefix+'app.js',JS)
 async def test_no_html_reports_actionable_error_without_starting_a_container(self):
  self.write('main.py','print("not a web app")');row=await self.service.start(self.chat['id'])
  self.assertEqual(row['status'],'error');self.assertIn('Save a plain HTML',row['error']);self.assertEqual(self.backend.launches,[])
 async def test_static_snapshot_serves_html_css_js_without_workspace_or_secrets_exposure(self):
  self.counter();root=self.store.workspace(self.chat['project_id']);self.write('.env','KEY=secret');self.write('backend/main.py','print("private")');self.write('node_modules/x.js','secret');self.write('hidden/.config/a.json','secret')
  (root/'leak.txt').symlink_to(self.store.database);(root/'linked').symlink_to(root/'backend',target_is_directory=True)
  before=self.store.revision(self.chat['project_id']);row=await self.service.start(self.chat['id'])
  self.assertEqual(row['status'],'running',row);self.assertEqual(row['entries'],['index.html'])
  async with httpx.AsyncClient(trust_env=False) as client:
   for path,value in [('',HTML),('app.js',JS),('style.css','body{color:rgb(20,60,30)}')]:self.assertEqual((await client.get(row['url']+path)).text,value)
   for path in ['.env','backend/main.py','leak.txt','node_modules/x.js','hidden/.config/a.json','%2e%2e/rooz.sqlite3']:
    self.assertEqual((await client.get(row['url']+path)).status_code,404,path)
  self.assertEqual(self.store.revision(self.chat['project_id']),before)
  snapshot=self.backend.launches[0][1];self.assertEqual(set(p.relative_to(snapshot).as_posix() for p in snapshot.rglob('*') if p.is_file()),{'index.html','style.css','app.js'})
 async def test_refresh_uses_saved_changes_and_removes_previous_snapshot(self):
  self.counter();one=await self.service.start(self.chat['id']);snapshot=self.backend.launches[-1][1];self.write('index.html',HTML.replace('Counter','Updated counter'))
  self.assertTrue((await self.service.describe(self.chat['id']))['stale'])
  async with httpx.AsyncClient(trust_env=False) as client:self.assertIn('<h1>Counter</h1>',(await client.get(one['url'])).text)
  two=await self.service.start(self.chat['id'],refresh=True);self.assertEqual(two['status'],'running');self.assertEqual(one['url'],two['url']);self.assertFalse(snapshot.exists());self.assertFalse(two['stale'])
  async with httpx.AsyncClient(trust_env=False) as client:self.assertIn('Updated counter',(await client.get(two['url'])).text)
 async def test_repeated_start_is_idempotent_and_stop_preserves_saved_source(self):
  self.counter();await asyncio.gather(self.service.start(self.chat['id']),self.service.start(self.chat['id']));self.assertEqual(len(self.backend.launches),1)
  snapshot=self.backend.launches[0][1];row=await self.service.stop(self.chat['id']);self.assertEqual(row['status'],'stopped');self.assertIsNone(row['url']);self.assertFalse(snapshot.exists())
  self.assertEqual((self.store.workspace(self.chat['project_id'])/'index.html').read_text(),HTML)
  self.assertEqual((await self.service.stop(self.chat['id']))['status'],'stopped')
 async def test_nested_entry_uses_its_parent_as_web_root(self):
  self.counter('web/');row=await self.service.start(self.chat['id'],'web/index.html');self.assertEqual(row['status'],'running')
  async with httpx.AsyncClient(trust_env=False) as client:self.assertEqual((await client.get(row['url']+'app.js')).text,JS)
 async def test_rooms_have_independent_servers_and_stop_does_not_affect_other_room(self):
  self.counter();one=await self.service.start(self.chat['id']);other=self.store.create_chat();(self.store.workspace(other['project_id'])/'index.html').write_text('Second room')
  two=await self.service.start(other['id']);await self.service.stop(self.chat['id'])
  self.assertEqual((await self.service.describe(other['id']))['status'],'running')
  async with httpx.AsyncClient(trust_env=False) as client:self.assertEqual((await client.get(two['url'])).text,'Second room')
  self.assertNotEqual(one['url'],two['url'])
 async def test_unavailable_docker_and_failed_start_return_errors_without_fake_running(self):
  self.counter();self.backend.ready=False;row=await self.service.start(self.chat['id']);self.assertEqual(row['status'],'error');self.assertIn('Docker Desktop',row['error']);self.assertIsNone(row['url'])
  self.backend.ready=True;self.backend.fail=True;row=await self.service.start(self.chat['id']);self.assertIn('address in use',row['error']);self.assertEqual(row['status'],'error');self.assertFalse(any((self.service.root/'snapshots').iterdir()))
 async def test_unsupported_build_entry_and_foreign_path_do_not_start(self):
  self.counter();self.write('react.html','<script type="module" src="/src/main.jsx"></script>');self.write('typescript.html','<SCRIPT src=/src/main.ts?version=1></SCRIPT>')
  for entry in ['../index.html','not-there.html','react.html','typescript.html']:
   row=await self.service.start(self.chat['id'],entry);self.assertEqual(row['status'],'error');self.assertIsNone(row['url'])
  self.assertEqual(self.backend.launches,[])
 async def test_logs_liveness_and_restart_cleanup_are_truthful(self):
  self.counter();row=await self.service.start(self.chat['id']);self.assertIn('listening',(await self.service.read_logs(self.chat['id']))['logs'])
  recreated=PreviewService(self.store,self.backend);await recreated.recover();status=await recreated.describe(self.chat['id']);self.assertEqual(status['status'],'stopped');self.assertIn('Server restarted',status['error']);self.assertFalse(await self.backend.running(self.backend.launches[0][0]))
  await recreated.start(self.chat['id']);await self.backend.remove(self.backend.launches[-1][0]);status=await recreated.describe(self.chat['id']);self.assertEqual(status['status'],'error');self.assertIsNone(status['url'])
 async def test_stop_requested_while_starting_cancels_before_launch(self):
  self.counter();entered=asyncio.Event();release=asyncio.Event()
  async def capability():entered.set();await release.wait();return {'ready':True}
  self.backend.capability=capability;task=asyncio.create_task(self.service.start(self.chat['id']));await entered.wait();stop=asyncio.create_task(self.service.stop(self.chat['id']));await asyncio.sleep(0);release.set();await task;row=await stop
  self.assertEqual(row['status'],'stopped');self.assertEqual(self.backend.launches,[])
 async def test_cleanup_failure_retains_container_identity_for_retry(self):
  self.counter();await self.service.start(self.chat['id']);remove=self.backend.remove;self.backend.remove=AsyncMock(side_effect=PreviewError('Docker disconnected'))
  row=await self.service.stop(self.chat['id']);self.assertEqual(row['status'],'error');self.assertIsNotNone(self.service.states[self.chat['id']]['name'])
  self.backend.remove=remove;self.assertEqual((await self.service.stop(self.chat['id']))['status'],'stopped')
 async def test_interrupted_start_without_container_is_reset_on_restart(self):
  self.service.save(self.chat['id'],{**self.service.empty(self.chat['id']),'status':'starting'})
  restarted=PreviewService(self.store,self.backend);await restarted.recover();row=await restarted.describe(self.chat['id']);self.assertEqual(row['status'],'stopped');self.assertIn('Server restarted',row['error'])
 async def test_wrong_health_identity_cannot_report_running_and_is_cleaned_up(self):
  self.counter();launch=self.backend.launch
  async def wrong_identity(name,snapshot,entry,session,owner,port=None,stop=None):return await launch(name,snapshot,entry,session+'wrong',owner,port=port,stop=stop)
  self.backend.launch=wrong_identity;self.service.ready_timeout=.2;row=await self.service.start(self.chat['id']);self.assertEqual(row['status'],'error');self.assertIn('did not become ready',row['error']);self.assertIsNone(row['url']);self.assertFalse(await self.backend.running(self.backend.launches[0][0]));self.assertFalse(self.backend.launches[0][1].exists())

class DockerPreviewTests(unittest.IsolatedAsyncioTestCase):
 async def test_docker_contract_uses_loopback_read_only_static_server_and_no_project_execution(self):
  docker=DockerPreview();docker.command=AsyncMock(side_effect=[(0,'container-id'),(0,json.dumps({'8080/tcp':[{'HostIp':'127.0.0.1','HostPort':'32123'}]}))])
  url=await docker.launch('name',Path('/tmp/snapshot'),'web/index.html','session','owner');self.assertEqual(url,'http://127.0.0.1:32123/')
  args=docker.command.call_args_list[0].args
  for required in ['--read-only','ALL','no-new-privileges','--pull=never','127.0.0.1::8080','/tmp/snapshot:/work:ro','/opt/rooz-preview.py','/work/web']:self.assertIn(required,args)
  self.assertNotIn('OPENAI_API_KEY',' '.join(args));self.assertNotIn('npm',args);self.assertNotIn('sh',args);self.assertNotIn('--rm',args)
 async def test_docker_missing_daemon_and_image_are_distinguished(self):
  docker=DockerPreview();docker.command=AsyncMock(side_effect=[(0,'v'),(1,'No such image')]);self.assertIn('docker build',(await docker.capability())['reason'])
  docker.command=AsyncMock(side_effect=PreviewError('Cannot connect to the Docker daemon'));self.assertIn('daemon',(await docker.capability())['reason'])
 async def test_missing_cli_and_timeout_are_bounded_and_actionable(self):
  with patch('rooz.preview.shutil.which',return_value=None):
   with self.assertRaisesRegex(PreviewError,'Docker is not installed'):await DockerPreview().command('info')
  process=type('Process',(),{})();process.returncode=None;process.communicate=AsyncMock(side_effect=TimeoutError());process.kill=unittest.mock.Mock();process.wait=AsyncMock()
  with patch('rooz.preview.shutil.which',return_value='/fake/docker'),patch('rooz.preview.asyncio.create_subprocess_exec',new=AsyncMock(return_value=process)):
   with self.assertRaises(TimeoutError):await DockerPreview().command('info')
  process.kill.assert_called_once();process.wait.assert_awaited_once()

class PreviewApiTests(unittest.TestCase):
 def test_routes_reject_unknown_room_and_preview_origins_cannot_mutate_chat(self):
  with tempfile.TemporaryDirectory() as directory:
   backend=NativePreview();app=create_app(directory,Path(__file__).parents[1]/'static',lambda:Model(),'fixture',NativeTestRunner(),backend)
   with TestClient(app) as client:
    self.assertEqual(client.get('/api/chats/not-a-room/preview').status_code,404)
    chat=client.post('/api/chats',json={}).json();root=app.state.store.workspace(chat['project_id']);(root/'index.html').write_text(HTML)
    started=client.post('/api/chats/'+chat['id']+'/preview/start',json={}).json();self.assertEqual(started['status'],'running',started)
    self.assertEqual(client.post('/api/chats',json={},headers={'Origin':started['url'].rstrip('/')}).status_code,403)
    self.assertEqual(client.get('/api/chats/'+chat['id']+'/preview/logs').status_code,200)
    self.assertEqual(client.post('/api/chats/'+chat['id']+'/preview/stop',json={}).json()['status'],'stopped')
   backend.temp.cleanup()

if __name__=='__main__':unittest.main()
