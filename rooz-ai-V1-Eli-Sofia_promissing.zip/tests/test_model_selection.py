"""HTTP model selection, request snapshots, provider isolation and reload persistence."""
import asyncio,json,os,tempfile,time,unittest
from pathlib import Path
from unittest.mock import patch
import httpx
from fastapi.testclient import TestClient
from openai import AsyncOpenAI
from rooz.agents import AgentService
from rooz.api import create_app
from rooz.models import ModelRouter
from rooz.storage import Store
from tests.support import NativeTestRunner

STATIC=Path(__file__).parents[1]/'static'

def final_message(model,text):
    if model=='deepseek-flash':return {'id':'d','object':'chat.completion','created':1,'model':model,'choices':[{'index':0,'finish_reason':'stop','message':{'role':'assistant','content':text,'reasoning_content':'private fixture reasoning'}}]}
    return {'id':'o','object':'response','created_at':1,'status':'completed','model':model,'output':[{'type':'message','id':'m','role':'assistant','status':'completed','content':[{'type':'output_text','text':text,'annotations':[]}]}]}

class SelectionHTTP(unittest.TestCase):
    def wait(self,client,run):
        for _ in range(150):
            result=client.get('/api/runs/'+run['id']).json()
            if result['status'] in ('completed','failed','cancelled','interrupted'):return result
            time.sleep(.01)
        self.fail('Request did not settle')
    def test_parallel_projects_route_separate_models_and_credentials_without_global_mutation(self):
        requests=[];original=AsyncOpenAI
        async def handler(request):
            body=json.loads(request.content);requests.append((request.url.host,request.headers['authorization'],body['model']))
            await asyncio.sleep(.03)
            return httpx.Response(200,json=final_message(body['model'],'Reply from '+body['model']))
        def factory(**kwargs):return original(**kwargs,http_client=httpx.AsyncClient(transport=httpx.MockTransport(handler)))
        with tempfile.TemporaryDirectory() as directory,patch.dict(os.environ,{'OPENAI_API_KEY':'fixture-openai','DEEPSEEK_API_KEY':'fixture-deepseek'},clear=True),patch('rooz.models.AsyncOpenAI',side_effect=factory):
            router=ModelRouter('gpt-6-luna');app=create_app(directory,STATIC,lambda:None,'gpt-6-luna',NativeTestRunner(),model_router=router)
            with TestClient(app) as client:
                config=client.get('/api/config').json();self.assertEqual({m['id'] for m in config['models']},{'gpt-6-luna','gpt-6.1-sol','deepseek-flash'})
                self.assertNotIn('fixture-openai',json.dumps(config));self.assertNotIn('fixture-deepseek',json.dumps(config))
                chats=[client.post('/api/projects',json={'title':name}).json() for name in ['Luna','DeepSeek']]
                runs=[client.post('/api/chats/'+chat['id']+'/messages',json={'agent':'eli','content':'Say hello','model':model}).json() for chat,model in zip(chats,['gpt-6-luna','deepseek-flash'])]
                for run,model in zip(runs,['gpt-6-luna','deepseek-flash']):
                    result=self.wait(client,run);self.assertEqual((result['status'],result['model']),('completed',model))
                self.assertEqual(app.state.agents.model,'gpt-6-luna')
                for chat,model in zip(chats,['gpt-6-luna','deepseek-flash']):
                    reload=client.get('/api/chats/'+chat['id']).json();self.assertEqual(reload['runs'][0]['model'],model)
                    self.assertIn(model,reload['messages'][-1]['content'])
            self.assertCountEqual(requests,[('api.openai.com','Bearer fixture-openai','gpt-6-luna'),('api.deepseek.com','Bearer fixture-deepseek','deepseek-flash')])
            reopened=Store(directory);self.assertEqual(reopened.run(runs[1]['id'])['model'],'deepseek-flash')
    def test_missing_key_and_unknown_model_fail_before_creating_a_job(self):
        with tempfile.TemporaryDirectory() as directory,patch.dict(os.environ,{'OPENAI_API_KEY':'fixture-openai'},clear=True):
            app=create_app(directory,STATIC,lambda:None,'gpt-6-luna',NativeTestRunner(),model_router=ModelRouter('gpt-6-luna'))
            with TestClient(app) as client:
                chat=client.post('/api/projects',json={'title':'Selection'}).json()
                response=client.post('/api/chats/'+chat['id']+'/messages',json={'agent':'eli','content':'Build','model':'deepseek-flash'})
                self.assertEqual(response.status_code,409);self.assertIn('DEEPSEEK_API_KEY',response.json()['detail'])
                response=client.post('/api/chats/'+chat['id']+'/messages',json={'agent':'eli','content':'Build','model':'unconfigured-provider'})
                self.assertEqual(response.status_code,409)
                data=client.get('/api/chats/'+chat['id']).json();self.assertEqual(data['runs'],[]);self.assertEqual(data['messages'],[])
    def test_old_client_without_model_uses_existing_configured_default(self):
        from tests.support import Model,Message
        with tempfile.TemporaryDirectory() as directory:
            app=create_app(directory,STATIC,lambda:Model([Message('Hello')]),'legacy-model',NativeTestRunner())
            with TestClient(app) as client:
                chat=client.post('/api/projects',json={'title':'Legacy client'}).json()
                run=client.post('/api/chats/'+chat['id']+'/messages',json={'agent':'eli','content':'Hello'}).json()
                self.assertEqual(self.wait(client,run)['model'],'legacy-model')

class DeepSeekHandoff(unittest.IsolatedAsyncioTestCase):
    async def test_handoff_stays_on_selected_model_and_preserves_parent_reasoning(self):
        requests=[]
        async def handler(request):
            body=json.loads(request.content);requests.append(body);self.assertEqual(body['model'],'deepseek-flash')
            speaker=body['messages'][0]['content'];results=[m for m in body['messages'] if m['role']=='tool']
            if speaker.startswith('You are Alex') and not results:
                message={'role':'assistant','content':None,'reasoning_content':'parent-private-reasoning','tool_calls':[{'id':'call-eli','type':'function','function':{'name':'call_agent','arguments':json.dumps({'agent':'eli','message':'Explain this implementation','reason':'Engineering input'})}}]}
                payload={'id':'r','object':'chat.completion','created':1,'model':'deepseek-flash','choices':[{'index':0,'finish_reason':'tool_calls','message':message}]}
            elif speaker.startswith('You are Eli'):payload=final_message('deepseek-flash','Eli engineering answer')
            else:
                self.assertIn('Eli engineering answer',results[-1]['content'])
                self.assertTrue(any(m.get('reasoning_content')=='parent-private-reasoning' for m in body['messages']))
                payload=final_message('deepseek-flash','Alex combined answer')
            return httpx.Response(200,json=payload)
        with tempfile.TemporaryDirectory() as directory:
            store=Store(directory);chat=store.create_chat();run=store.start_run(chat['id'],'alex','Ask Eli for help',model='deepseek-flash')
            client=AsyncOpenAI(api_key='fixture',base_url='https://api.deepseek.com',max_retries=0,http_client=httpx.AsyncClient(transport=httpx.MockTransport(handler)))
            await AgentService(store,NativeTestRunner(),lambda:client,'gpt-6-luna').execute(run,asyncio.Event())
            self.assertEqual(store.run(run['id'])['status'],'completed');self.assertEqual(len(requests),3)
            self.assertEqual([m['agent'] for m in store.messages(chat['id']) if m['role']=='assistant'],['eli','alex'])
            self.assertNotIn('parent-private-reasoning',json.dumps(store.messages(chat['id'])))
