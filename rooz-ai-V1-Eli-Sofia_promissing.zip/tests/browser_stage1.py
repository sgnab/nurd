"""Actual Chromium + HTTP + SQLite; scripted model, controlled native test adapter."""
import json,os,socket,subprocess,sys,tempfile,time,urllib.request
from pathlib import Path
from playwright.sync_api import sync_playwright,expect
from tests.browser_projects_support import create_project
app_root=Path(__file__).parents[1];root=Path(tempfile.mkdtemp(prefix='rooz-browser-evidence-'))
with socket.socket() as s:s.bind(('127.0.0.1',0));port=s.getsockname()[1]
with tempfile.TemporaryDirectory() as data:
 env=os.environ.copy();env.update(ROOZ_FIXTURE_DATA=data,ROOZ_FIXTURE_PORT=str(port))
 log=(root/'ui-server.log').open('w');proc=subprocess.Popen([sys.executable,str(app_root/'tests/fixture_server.py')],env=env,stdout=log,stderr=subprocess.STDOUT)
 try:
  base='http://127.0.0.1:'+str(port)
  for i in range(100):
   try:urllib.request.urlopen(base+'/api/chats',timeout=1);break
   except OSError:time.sleep(.1)
  else:raise RuntimeError('Fixture did not start')
  results=[]
  with sync_playwright() as p:
   browser=p.chromium.launch(executable_path=os.getenv('ROOZ_BROWSER_EXECUTABLE') or None,headless=True,args=['--no-sandbox','--disable-dev-shm-usage','--disable-gpu'])
   context=browser.new_context(viewport={'width':1440,'height':1000},permissions=['clipboard-read','clipboard-write'],accept_downloads=True)
   page=context.new_page();errors=[];page.on('pageerror',lambda e:errors.append(str(e)));page.goto(base);create_project(page,"Initial project")
   expect(page.get_by_text('Make something',exact=False)).to_be_visible();page.screenshot(path=str(root/'desktop.png'),full_page=True)
   for _ in range(6):
    previous=len(page.request.get(base+'/api/chats').json()['chats']);create_project(page,'Another project')
    page.wait_for_function('(n)=>document.querySelectorAll("#recentChats button,#olderList button").length>n',arg=previous)
   expect(page.locator('#recentChats button')).to_have_count(5);expect(page.locator('#olderList button')).to_have_count(2)
   expect(page.locator('#olderChats')).not_to_have_attribute('open','');page.locator('#olderChats summary').click();expect(page.locator('#olderList button').first).to_be_visible();results.append('Five recent chats; older chats collapsed and expandable')
   page.locator('#agentSelect').select_option('sofia');page.get_by_label('Message',exact=True).fill('write tested code');page.get_by_role('button',name='Send message',exact=True).click()
   expect(page.get_by_text('A small, tested implementation',exact=True)).to_be_visible(timeout=15000)
   expect(page.get_by_text('Checks passed',exact=True)).to_be_visible();expect(page.locator('.message-meta strong').last).to_have_text('Sofia')
   assert not page.evaluate('Boolean(window.ROOZ_XSS)');results.append('Sofia response, highlighted code and actual Python check result; HTML escaped')
   page.locator('.code-actions button').filter(has_text='Copy').first.click();expect(page.locator('.code-actions button').filter(has_text='Copied')).to_be_visible()
   assert 'def total' in page.evaluate('navigator.clipboard.readText()');results.append('Code Copy preserves exact code')
   with page.expect_download() as info:page.locator('.code-actions button').filter(has_text='Download').first.click()
   download=info.value;download.save_as(root/'snippet.py');assert (root/'snippet.py').read_text()=='def total(values):\n    return sum(values)\n';results.append('Code-block Download preserves exact bytes')
   with page.expect_download() as info:page.get_by_role('link',name='↓ total.py',exact=True).click()
   info.value.save_as(root/'artifact.py');assert (root/'artifact.py').read_text()==(root/'snippet.py').read_text();results.append('Saved artifact download matches tested file')
   page.reload();expect(page.get_by_text('A small, tested implementation',exact=True)).to_be_visible();expect(page.get_by_text('Checks passed',exact=True)).to_be_visible();results.append('Conversation, agent and check evidence survive reload')
   page.get_by_role('button',name='Project files',exact=False).click();expect(page.get_by_role('heading',name='Project files')).to_be_visible()
   with page.expect_download() as info:page.get_by_role('link',name='Download project ZIP').click()
   info.value.save_as(root/'project.zip')
   import zipfile
   with zipfile.ZipFile(root/'project.zip') as z:assert set(z.namelist())=={'total.py','test_total.py'}
   page.get_by_label('Close panel').click();results.append('Project file panel and ZIP download')
   page.locator('#agentSelect').select_option('eli');page.locator('#prompt').fill('Hello Eli');page.locator('#send').click();expect(page.locator('.message-meta strong').last).to_have_text('Eli',timeout=10000)
   page.locator('#agentSelect').select_option('alex');page.locator('#prompt').fill('wait for stop');page.locator('#send').click();expect(page.get_by_role('button',name='■ Stop')).to_be_visible();page.get_by_role('button',name='■ Stop').click();expect(page.get_by_text('Stopped. Code already saved',exact=False)).to_be_visible(timeout=10000);expect(page.locator('#send')).to_be_visible();results.append('All three recipients; Stop cancels a pending model call and restores composer')
   page.locator('#prompt').fill('mixed checks');page.locator('#send').click()
   expect(page.get_by_text('Mixed checks recorded.',exact=True)).to_be_visible(timeout=15000)
   expect(page.locator('article').filter(has_text='Mixed checks recorded.').locator('summary strong')).to_have_text('Checks failed')
   results.append('A different passing check cannot hide an unresolved failure on the same code revision')
   for width,height in [(1024,900),(390,844)]:
    page.set_viewport_size({'width':width,'height':height});page.wait_for_timeout(200)
    assert page.evaluate('document.documentElement.scrollWidth<=innerWidth'),str(width)+' page overflow'
    expect(page.locator('#prompt')).to_be_visible();expect(page.locator('#send')).to_be_visible()
    if width==390:
     page.get_by_label('Open navigation').click();expect(page.locator('#newChat')).to_be_visible();page.get_by_label('Close navigation').click()
    page.screenshot(path=str(root/('mobile.png' if width==390 else 'tablet.png')),full_page=True)
   results.append('Desktop, tablet and mobile layout; mobile navigation')
   assert not errors,errors
   browser.close()
  (root/'ui-results.json').write_text(json.dumps({'real_browser':True,'real_model':False,'production_docker_executed':False,'test_execution':'Native subprocess adapter on controlled generated fixtures','passed':results},indent=2))
  print('\n'.join('PASS '+r for r in results))
 finally:proc.terminate();proc.wait(timeout=10);log.close()
