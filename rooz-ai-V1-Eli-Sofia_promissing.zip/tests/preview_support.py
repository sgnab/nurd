"""Controlled fixed-server adapter for tests only. Never used by production."""
import asyncio,socket,sys,tempfile
from pathlib import Path
from rooz.preview import PreviewError

class NativePreview:
 def __init__(self):self.processes={};self.launches=[];self.removed=[];self.ready=True;self.fail=False;self.temp=tempfile.TemporaryDirectory()
 async def capability(self):return {'ready':self.ready,'reason':'Fixture: Docker Desktop unavailable'}
 async def launch(self,name,snapshot,entry,session,owner,port=None,stop=None):
  if self.fail:raise PreviewError('Fixture bind failure: address in use')
  if port is None:
   with socket.socket() as sock:sock.bind(('127.0.0.1',0));port=sock.getsockname()[1]
  logfile=Path(self.temp.name)/name;output=logfile.open('wb')
  script=Path(__file__).parents[1]/'rooz/preview_server.py'
  process=await asyncio.create_subprocess_exec(sys.executable,'-u',str(script),'--root',str(snapshot/Path(entry).parent),'--entry',Path(entry).name,'--session',session,'--host','127.0.0.1','--port',str(port),stdout=output,stderr=asyncio.subprocess.STDOUT)
  self.processes[name]=(process,logfile,output);self.launches.append((name,snapshot,entry,session));return 'http://127.0.0.1:'+str(port)+'/'
 async def running(self,name):return name in self.processes and self.processes[name][0].returncode is None
 async def logs(self,name):return self.processes[name][1].read_text(errors='replace')[-12000:] if name in self.processes else ''
 async def remove(self,name):
  self.removed.append(name)
  if name in self.processes:
   process,logfile,output=self.processes[name]
   if process.returncode is None:process.terminate();await process.wait()
   output.close()
 async def close(self):
  for name in list(self.processes):await self.remove(name)
  self.temp.cleanup()
