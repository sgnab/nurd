"""Controlled host recovery with actual Chromium/HTTP/SQLite; no live model or Docker."""
import asyncio
import json
import os
import tempfile
from pathlib import Path
from rooz.agents import AgentService
from rooz.preview import PreviewService
from rooz.storage import Store
from tests.fullstack_support import NativeFullstackPreview,write_app
from tests.support import NativeTestRunner,Model,Message,call


async def main():
    with tempfile.TemporaryDirectory(prefix='rooz-repair-browser-') as directory:
        store=Store(directory);chat=store.create_chat('Browser recovery fixture')
        root=store.workspace(chat['project_id']);write_app(root)
        (root/'tests').mkdir()
        (root/'tests/verify.py').write_text('import subprocess,sys\nsubprocess.run([sys.executable,"tests/browser_check.py"],check=True)\n')
        runtime=NativeFullstackPreview();preview=PreviewService(store,runtime)
        try:
            started=await preview.start(chat['id'])
            assert started['status']=='running',started
            common='''import os
from pathlib import Path
from playwright.sync_api import sync_playwright,expect
with sync_playwright() as p:
 browser=p.chromium.launch(executable_path=os.getenv('ROOZ_BROWSER_EXECUTABLE') or None,args=['--no-sandbox','--disable-dev-shm-usage','--use-gl=angle','--use-angle=swiftshader'])
 try:
  page=browser.new_page()
  page.goto(URL)
BODY
 finally:browser.close()
'''.replace('URL',repr(started['url']))
            stale=common.replace('BODY',"  page.get_by_role('button',name='Check backend',exact=True).click(timeout=1000)")
            fixed=common.replace('BODY','''  page.get_by_label('Title',exact=True).fill('Verified recovery')
  with page.expect_response(lambda r:r.url.endswith('/api/notes') and r.request.method=='POST' and r.status==201):
   page.get_by_role('button',name='Add note',exact=True).click()
  expect(page.get_by_role('listitem')).to_contain_text('Verified recovery')
  evidence=Path(os.environ['ROOZ_SCREENSHOT_DIR'])
  page.screenshot(path=str(evidence/'desktop.png'))
  page.get_by_role('button',name='Edit',exact=True).click()
  page.get_by_label('Title',exact=True).fill('Edited recovery')
  page.screenshot(path=str(evidence/'form.png'))
  page.get_by_role('button',name='Save note',exact=True).click()
  page.reload();expect(page.get_by_role('listitem')).to_contain_text('Edited recovery')
  page.set_viewport_size({'width':390,'height':844})
  page.screenshot(path=str(evidence/'mobile.png'))
  page.get_by_role('button',name='Delete',exact=True).click()
  expect(page.get_by_role('listitem')).to_have_count(0)
  assert page.request.get(URL+'api/notes').json()==[]
  print('PASS: actual browser create, edit, reload persistence, delete and backend reads')'''.replace('URL',repr(started['url'])))
            (root/'tests/browser_check.py').write_text(stale)
            run=store.start_run(chat['id'],'eli','Implement the requested UI, update tests and verify it.')
            command=['python','tests/browser_check.py']
            def invoke(name,args):return Message(calls=[call(name,args)])
            model=Model([
                invoke('run_tests',{'command':command}),
                Message('The old Check backend button is gone. Confirm to proceed.'),
                Message('I will update the browser test next. Confirm to proceed.'),
                invoke('read_files',{'paths':['tests/browser_check.py','frontend/index.html']}),
                invoke('write_files',{'files':[{'path':'tests/browser_check.py','content':fixed}]}),
                invoke('run_tests',{'command':command}),
                Message('Focused browser repair passed.'),
                Message('Browser repair and final acceptance passed on the saved revision.')])
            await AgentService(store,NativeTestRunner(),lambda:model,'fixture').execute(run,asyncio.Event())
            result=store.run(run['id']);assert result['status']=='completed',store.messages(chat['id'])[-1]
            checks=result['checks'];assert [c['status'] for c in checks]==['failed','passed','passed'],checks
            assert 'Check backend' in checks[0]['output']
            assert checks[-1]['kind']=='full-stack acceptance'
            assert checks[-1]['revision']==store.revision(chat['project_id'])
            assert len(checks[-1]['screenshots'])==3
            image_messages=[m for m in model.prompts[-1]['messages'] if isinstance(m.get('content'),list)
                            and any(p.get('type')=='image_url' for p in m['content'])]
            assert len(image_messages)==1,'The latest actual browser pixels must reach the model without accumulating old images'
            assert all(row['revision']==checks[-1]['revision'] for row in checks[-1]['screenshots'])
            assert len([m for m in store.messages(chat['id']) if m['role']=='assistant'])==1
            print(json.dumps({'scripted_model':True,'docker':False,'real_browser':True,'real_http':True,
                              'actual_images_delivered_to_model':True,
                              'checks':[{'command':c['command'],'status':c['status'],'kind':c['kind'],'screenshots':len(c.get('screenshots',[]))} for c in checks]},indent=2))
        finally:await preview.shutdown();runtime.temp.cleanup()


if __name__=='__main__':asyncio.run(main())
