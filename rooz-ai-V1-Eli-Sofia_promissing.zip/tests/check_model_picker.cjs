// Exercise production selection/send/render functions with a minimal DOM adapter.
const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict');
class Element {
 constructor(){this.children=[];this.value='';this.style={};this.disabled=false;this.scrollHeight=0;this.scrollTop=0;this.clientHeight=0;}
 append(...children){this.children.push(...children);}replaceChildren(...children){this.children=[...children];}
}
const elements=new Map(),$=id=>{if(!elements.has(id))elements.set(id,new Element());return elements.get(id);};
const memory=new Map(),localStorage={getItem:k=>memory.get(k)||null,setItem:(k,v)=>memory.set(k,v)};
const state={chat:'first',signature:'',sending:false,uploading:false,mutation:0,config:{model:'gpt-6-luna',models:[{id:'gpt-6-luna',label:'GPT-6 Luna',provider:'openai',key_configured:true},{id:'deepseek-flash',label:'DeepSeek V4.1 Flash',provider:'deepseek',key_configured:false}]},data:{chat:{id:'first',title:'First'},messages:[],runs:[],artifacts:[],files:[],revision:'r',pending_attachments:[]}};
let sent;
const context={state,$,localStorage,names:{eli:'Eli'},terminal:new Set(['completed','failed','cancelled','interrupted']),document:{},el:()=>new Element(),welcome:()=>new Element(),renderDrafts:()=>{},updateAgent:()=>{},error:()=>{},refreshChats:async()=>{},api:async(path,method,body)=>{
 if(method==='POST'){sent=body;return {id:'run',model:body.model,agent:'eli'};}return state.data;
}};
vm.createContext(context);const source=fs.readFileSync('static/app.js','utf8');
vm.runInContext(source.slice(source.indexOf('function modelName('),source.indexOf('function updateAgent(')),context);
vm.runInContext(source.slice(source.indexOf('function currentRun('),source.indexOf('function renderChats(')),context);
vm.runInContext(source.slice(source.indexOf('async function send('),source.indexOf('async function poll(')),context);
(async()=>{
 context.syncModelPicker();assert.equal($('modelSelect').value,'gpt-6-luna');
 $('modelSelect').value='deepseek-flash';$('modelSelect').onchange();assert.match($('modelHint').textContent,/DEEPSEEK_API_KEY/);
 $('modelSelect').value='';context.syncModelPicker();assert.equal($('modelSelect').value,'deepseek-flash');
 memory.set('rooz.model.second','gpt-6-luna');state.chat='second';context.syncModelPicker();assert.equal($('modelSelect').value,'gpt-6-luna');
 state.chat='first';context.syncModelPicker();$('agentSelect').value='eli';$('prompt').value='Build the requested app';
 await context.send();assert.equal(sent.model,'deepseek-flash');assert.equal(sent.agent,'eli');assert.equal(memory.get('rooz.model.first'),'deepseek-flash');
 state.data.runs=[{id:'r',status:'running',agent:'eli',model:'deepseek-flash',stage:'Working'}];state.signature='';context.render();
 assert.equal($('modelSelect').disabled,true);assert.equal($('modelSelect').value,'deepseek-flash');assert.equal($('stop').hidden,false);
 state.data.runs[0].status='completed';state.signature='';context.render();assert.equal($('modelSelect').disabled,false);
 memory.set('rooz.model.first','removed-model');memory.delete('rooz.model');context.syncModelPicker('deepseek-flash');assert.equal($('modelSelect').value,'deepseek-flash');
 console.log('PASS model selection, per-project persistence, missing-key hint, send payload, active-run lock, Stop access and legacy fallback');
})().catch(e=>{console.error(e);process.exitCode=1;});
