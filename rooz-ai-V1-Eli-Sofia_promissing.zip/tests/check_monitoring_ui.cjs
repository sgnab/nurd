// Actual production dashboard JS with a minimal DOM adapter; not a browser claim.
const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict');
class Element{
 constructor(tag='div'){this.tag=tag;this.children=[];this.hidden=false;this.disabled=false;this.value='';this.checked=false;this.dataset={};this.attributes={};}
 set innerHTML(value){throw Error('Dashboard must not insert untrusted HTML');}
 append(...children){this.children.push(...children);}replaceChildren(...children){this.children=[...children];}
 setAttribute(k,v){this.attributes[k]=v;}get options(){return this.children;}reportValidity(){return true;}
 querySelectorAll(){return this.children.filter(c=>c.tag==='details'&&c.open);}click(){this.clicked=true;}
}
const elements=new Map(),$=id=>{if(!elements.has(id))elements.set(id,new Element());return elements.get(id);};
$('reportFilter').value='all';$('maxCalls').value='20';$('outputTokens').value='4096';$('securityAgent').value='eli';$('paidConsent').checked=true;
let requests=[],interval;const payload={fingerprint:'current-fingerprint',models:[{id:'luna',label:'Luna',key_configured:true},{id:'deepseek-flash',label:'DeepSeek',key_configured:false}],runs:[],security_runs:[]};
const context={document:{getElementById:$,createElement:tag=>new Element(tag),hidden:false},console,Blob,URL:{createObjectURL:()=> 'blob:fixture',revokeObjectURL:()=>{}},setTimeout:()=>{},setInterval:fn=>{interval=fn;},fetch:async(url,options)=>{requests.push({url,...options});return {ok:true,json:async()=>url==='/api/monitoring'?structuredClone(payload):{id:'started'}};}};
vm.createContext(context);vm.runInContext(fs.readFileSync('static/monitoring.js','utf8'),context);
const flush=()=>new Promise(r=>setImmediate(r));
const tick=async()=>{interval();await flush();};
const text=e=>[e.textContent||'',...e.children.map(text)].join(' ');
(async()=>{
 await flush();assert.equal($('securityModel').value,'luna');assert.equal($('securityModel').options[1].disabled,true);assert.equal($('runLive').disabled,false);
 const report={id:'security-report',mode:'live',agent:'eli',model:'<img src=x onerror=attack()>',created:'2026-11-09',status:'running',stale:true,cases:[{id:'test',name:'Read <script>attack</script>',status:'running',evidence:['<svg onload=attack()>']}],budget:{calls:1,max_calls:20,usage_available:false}};
 payload.security_runs=[report];await tick();assert.equal($('runFast').disabled,true);assert.equal($('runLive').disabled,true);
 assert.match(text($('securityHistory')),/Earlier agent fingerprint/);assert.match(text($('securityHistory')),/<svg onload=attack\(\)>/);
 const buttons=$('securityHistory').children[0].children.filter(e=>e.tag==='button');assert.equal(buttons[0].textContent,'Stop test');await buttons[0].onclick();await flush();assert.equal(requests.at(-2).url,'/api/security/runs/security-report/stop');
 report.status='completed';report.cases[0].status='inconclusive';await tick();assert.match(text($('securityHistory')),/inconclusive/);assert.equal($('runLive').disabled,false);
 await $('liveForm').onsubmit({preventDefault(){}});await flush();const paid=requests.find(r=>r.url==='/api/security/runs'&&r.body?.includes('"live"'));assert.ok(paid);const body=JSON.parse(paid.body);assert.equal(body.confirm_paid,true);assert.equal(body.max_calls,20);assert.equal(body.output_tokens,4096);assert.equal(body.model,'luna');
 $('activityTab').onclick();assert.equal($('securityView').hidden,true);assert.equal($('activityView').hidden,false);
 payload.runs=[{id:'normal-run',agent:'eli',model:'luna',status:'running',stage:'Waiting',created:'2026-11-09',last_activity:'2026-11-09',model_calls:1,usage_available:false,events:[{created:'2026-11-09',kind:'model_started'}]}];await tick();assert.match(text($('agentActivity')),/Waiting for model response/);const stop=$('agentActivity').children[0].children.find(e=>e.tag==='button');assert.equal(stop.textContent,'Stop agent');await stop.onclick();await flush();assert.ok(requests.some(r=>r.url==='/api/runs/normal-run/stop'));
 console.log('PASS dashboard model readiness, paid payload, running locks, Stop controls, stale/inconclusive labels, activity timeline and text-only rendering');
})().catch(e=>{console.error(e);process.exitCode=1;});
