"""Optional real-Docker smoke check. No model calls, no generated code execution."""
import asyncio,tempfile
from pathlib import Path
import httpx
from rooz.storage import Store
from rooz.preview import DockerPreview,PreviewService

async def main():
 backend=DockerPreview();capability=await backend.capability()
 if not capability['ready']:print('UNAVAILABLE: '+capability['reason']);return 2
 # Under the project folder so Docker Desktop uses the same shared location.
 with tempfile.TemporaryDirectory(prefix='rooz-preview-check-',dir=Path(__file__).parents[1]) as directory:
  store=Store(directory);chat=store.create_chat();workspace=store.workspace(chat['project_id'])
  (workspace/'index.html').write_text('<!doctype html><h1>Rooz preview Docker check</h1><script src="app.js"></script>')
  (workspace/'app.js').write_text('document.body.dataset.preview="ready";')
  service=PreviewService(store,backend);name=None
  try:
   row=await service.start(chat['id']);name=service.states[chat['id']].get('name')
   if row['status']!='running':print('FAILED: '+row['error']+'\n'+row['logs']);return 1
   async with httpx.AsyncClient(trust_env=False,timeout=3) as client:
    response=await client.get(row['url']);assert response.status_code==200 and 'Rooz preview Docker check' in response.text
    response=await client.get(row['url']+'app.js');assert response.status_code==200 and 'dataset.preview' in response.text
   print('PASS: Real Docker container served saved HTML and JavaScript over loopback.')
  finally:
   result=await service.stop(chat['id'])
   if result['status']!='stopped':raise RuntimeError(result['error'])
  if name:assert not await backend.running(name),'Preview container remained running'
  print('PASS: Stop removed the preview container and snapshot.');return 0

if __name__=='__main__':raise SystemExit(asyncio.run(main()))
