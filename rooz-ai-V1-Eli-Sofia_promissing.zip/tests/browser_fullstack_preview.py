"""Real browser/HTTP/SQLite preview UI acceptance; controlled native fixture, no Docker/model."""
import json
import os
import socket
import subprocess
import sys
import tempfile
import time
import urllib.request
from pathlib import Path
from playwright.sync_api import sync_playwright,expect

root=Path(__file__).parents[1]
evidence=Path(os.getenv('ROOZ_TEST_OUTPUT') or tempfile.mkdtemp(prefix='rooz-fullstack-ui-'))
evidence.mkdir(parents=True,exist_ok=True)
with socket.socket() as sock:
    sock.bind(('127.0.0.1',0));port=sock.getsockname()[1]
with tempfile.TemporaryDirectory() as directory:
    env={**os.environ,'ROOZ_FIXTURE_DATA':directory,'ROOZ_FIXTURE_PORT':str(port)}
    with (evidence/'server.log').open('w') as log:
        server=subprocess.Popen([sys.executable,str(root/'tests/fullstack_fixture_server.py')],env=env,stdout=log,stderr=subprocess.STDOUT)
        try:
            base='http://127.0.0.1:'+str(port)
            for _ in range(100):
                try:urllib.request.urlopen(base+'/api/chats',timeout=1);break
                except OSError:time.sleep(.1)
            else:raise RuntimeError('UI fixture did not start')
            with sync_playwright() as playwright:
                browser=playwright.chromium.launch(executable_path=os.getenv('ROOZ_BROWSER_EXECUTABLE') or None,args=['--no-sandbox','--disable-dev-shm-usage'])
                try:
                    page=browser.new_page(viewport={'width':1440,'height':1050})
                    errors=[];page.on('pageerror',lambda error:errors.append(str(error)))
                    page.goto(base);page.get_by_role('button',name='Live Preview',exact=True).click()
                    expect(page.locator('#previewEntry')).to_have_value('@fullstack')
                    page.get_by_role('button',name='Start Preview',exact=True).click()
                    expect(page.locator('#previewStatus')).to_have_text('Running',timeout=30000)
                    frame=page.frame_locator('#previewFrame')
                    expect(frame.get_by_role('heading',name='Notes preview')).to_be_visible()
                    frame.get_by_label('Title').fill('UI-connected note')
                    frame.get_by_role('button',name='Add note',exact=True).click()
                    expect(frame.get_by_role('listitem')).to_contain_text('UI-connected note')
                    with page.expect_popup() as popup:
                        page.get_by_role('link',name='Open in new tab').click()
                    opened=popup.value;expect(opened.get_by_role('listitem')).to_contain_text('UI-connected note');opened.close()
                    address=page.locator('#previewFrame').get_attribute('src')
                    page.get_by_role('button',name='Refresh',exact=True).click()
                    expect(page.locator('#previewStatus')).to_have_text('Running',timeout=30000)
                    expect(frame.get_by_role('listitem')).to_contain_text('UI-connected note')
                    assert page.locator('#previewFrame').get_attribute('src')==address
                    page.locator('#previewLogs summary').click()
                    expect(page.locator('#previewLogText')).to_contain_text('/api/notes',timeout=10000)
                    page.get_by_role('button',name='Stop preview',exact=True).click()
                    expect(page.locator('#previewStatus')).to_have_text('Stopped')
                    page.get_by_role('button',name='Start Preview',exact=True).click()
                    expect(page.locator('#previewStatus')).to_have_text('Running',timeout=30000)
                    expect(frame.get_by_role('listitem')).to_contain_text('UI-connected note')
                    page.once('dialog',lambda dialog:dialog.accept())
                    page.get_by_role('button',name='Reset preview data',exact=True).click()
                    expect(page.locator('#previewStatus')).to_have_text('Stopped',timeout=15000)
                    page.get_by_role('button',name='Start Preview',exact=True).click()
                    expect(page.locator('#previewStatus')).to_have_text('Running',timeout=30000)
                    expect(frame.get_by_role('listitem')).to_have_count(0)
                    page.set_viewport_size({'width':390,'height':844})
                    expect(page.get_by_role('button',name='Stop preview',exact=True)).to_be_visible()
                    assert page.locator('#previewPanel').evaluate('node=>node.scrollWidth<=node.clientWidth')
                    page.screenshot(path=str(evidence/'mobile.png'),full_page=True)
                    assert not errors,errors
                finally:browser.close()
            result={'browser':True,'http':True,'docker':False,'live_model':False,'checks':['full-stack detection','start and iframe','real API create/list','new tab','refresh and origin persistence','logs','stop/start persistence','confirmed scoped reset','mobile overflow']}
            (evidence/'results.json').write_text(json.dumps(result,indent=2))
            print('PASS: '+', '.join(result['checks']))
        finally:
            server.terminate();server.wait(timeout=20)
