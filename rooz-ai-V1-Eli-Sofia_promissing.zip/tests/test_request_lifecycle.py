"""Deadline, Stop, shutdown and model timeouts must not impersonate each other."""
import asyncio
import tempfile
import unittest
from rooz.agents import AgentService
from rooz.storage import Store
from tests.support import Model,Message,call,NativeTestRunner

class RequestLifecycle(unittest.IsolatedAsyncioTestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.addCleanup(self.temp.cleanup)
        self.store=Store(self.temp.name);self.chat=self.store.create_chat('Lifecycle')
    def service(self,script):
        model=Model(script);service=AgentService(self.store,NativeTestRunner(),lambda:model,'fixture')
        run=self.store.start_run(self.chat['id'],'eli','Implement and verify')
        return service,run,model
    def answer(self):return self.store.messages(self.chat['id'])[-1]
    async def test_deadline_is_45_minutes_and_preserves_prior_checks_with_accurate_message(self):
        service,run,model=self.service([Message(calls=[call('run_tests',{'command':['python','-c','print("executed")']})]),'wait'])
        self.assertEqual(service.request_timeout,2700);service.request_timeout=.3
        await service.execute(run,asyncio.Event())
        result=self.store.run(run['id']);self.assertEqual((result['status'],result['end_reason']),('failed','request_deadline'))
        self.assertEqual(result['checks'][0]['status'],'passed');self.assertIn('executed',result['checks'][0]['output'])
        self.assertIn('45-minute request deadline',self.answer()['content'])
        self.assertFalse(self.answer()['content'].startswith('Stopped'))
        self.assertEqual(self.answer()['id'],result['checks'][0]['reply_id']);self.assertTrue(model.closed)
    async def test_manual_stop_records_user_stop(self):
        service,run,model=self.service(['wait']);service.start(run);await asyncio.sleep(.02)
        task=service.active[run['id']][1];service.stop(run['id']);await asyncio.wait_for(task,2)
        result=self.store.run(run['id']);self.assertEqual((result['status'],result['end_reason']),('cancelled','user_stop'))
        self.assertTrue(self.answer()['content'].startswith('Stopped.'));self.assertTrue(model.closed)
    async def test_shutdown_records_interruption_not_user_stop(self):
        service,run,model=self.service(['wait']);service.start(run);await asyncio.sleep(.02);await service.shutdown()
        result=self.store.run(run['id']);self.assertEqual((result['status'],result['end_reason']),('interrupted','server_shutdown'))
        self.assertIn('server shut down',self.answer()['content'].lower());self.assertTrue(model.closed)
        self.assertFalse(service.active)
    async def test_shutdown_before_task_starts_is_reconciled(self):
        service,run,_=self.service(['wait']);service.start(run);await service.shutdown()
        result=self.store.run(run['id']);self.assertEqual((result['status'],result['end_reason']),('interrupted','server_shutdown'))
        self.assertFalse(service.active)
    async def test_external_task_cancellation_is_not_a_user_stop(self):
        service,run,_=self.service(['wait']);service.start(run);await asyncio.sleep(.02)
        task=service.active[run['id']][1];task.cancel();await task
        result=self.store.run(run['id']);self.assertEqual(result['end_reason'],'external_cancellation')
        self.assertIn('No user Stop was recorded',self.answer()['content'])
    async def test_model_operation_timeout_is_not_overall_deadline(self):
        service,run,_=self.service([TimeoutError()]);await service.execute(run,asyncio.Event())
        result=self.store.run(run['id']);self.assertEqual(result['end_reason'],'operation_timeout')
        self.assertIn('operation timed out',self.answer()['content'])
        self.assertNotIn('45-minute',self.answer()['content'])
    async def test_ungraceful_restart_has_persisted_cause(self):
        _,run,_=self.service(['wait']);reopened=Store(self.temp.name)
        result=reopened.run(run['id']);self.assertEqual((result['status'],result['end_reason']),('interrupted','server_restart'))
    async def test_first_stop_reason_survives_shutdown(self):
        service,run,_=self.service(['wait']);service.start(run);await asyncio.sleep(.02)
        service.stop(run['id']);await service.shutdown()
        result=self.store.run(run['id']);self.assertEqual(result['end_reason'],'user_stop')
        self.assertTrue(self.answer()['content'].startswith('Stopped.'))

    async def test_deadline_during_handoff_has_one_correct_reply_and_cancelled_handoff(self):
        service,run,_=self.service([Message(calls=[call('call_agent',{'agent':'sofia','message':'Review this UI','reason':'Frontend review'})]),'wait'])
        service.request_timeout=.05;await service.execute(run,asyncio.Event())
        rows=self.store.messages(self.chat['id']);answers=[m for m in rows if m['role']=='assistant']
        self.assertEqual(len(answers),1);self.assertEqual(answers[0]['agent'],'sofia')
        self.assertIn('45-minute request deadline',answers[0]['content'])
        import json
        handoff=next(m for m in rows if m['role']=='handoff')
        self.assertEqual(json.loads(handoff['content'])['status'],'cancelled')
    async def test_stop_immediately_before_shutdown_keeps_user_stop_status(self):
        service,run,_=self.service(['wait']);service.start(run);service.stop(run['id']);await service.shutdown()
        result=self.store.run(run['id']);self.assertEqual((result['status'],result['end_reason']),('cancelled','user_stop'))

    async def test_all_agents_can_continue_past_old_turn_caps(self):
        for agent in ('eli','alex','sofia'):
            with self.subTest(agent=agent):
                model=Model([Message(calls=[call('read_files',{'paths':['existing.txt']})]) for _ in range(75)]+[Message('Finished after 75 tool turns.')])
                service=AgentService(self.store,NativeTestRunner(),lambda:model,'fixture')
                run=self.store.start_run(self.chat['id'],agent,'Inspect existing files')
                await service.execute(run,asyncio.Event())
                self.assertEqual(self.store.run(run['id'])['status'],'completed')
                self.assertEqual(len(model.prompts),76)
                self.assertEqual(self.answer()['content'],'Finished after 75 tool turns.')

    async def test_deadline_still_cancels_after_more_than_64_turns(self):
        script=[Message(calls=[call('read_files',{'paths':['existing.txt']})]) for _ in range(70)]+['wait']
        service,run,model=self.service(script);service.request_timeout=1.0
        await asyncio.wait_for(service.execute(run,asyncio.Event()),3)
        self.assertGreater(len(model.prompts),64)
        self.assertEqual(self.store.run(run['id'])['end_reason'],'request_deadline')
        self.assertIn('45-minute request deadline',self.answer()['content'])

    async def test_stop_still_cancels_after_more_than_64_turns(self):
        script=[Message(calls=[call('read_files',{'paths':['existing.txt']})]) for _ in range(70)]+['wait']
        service,run,model=self.service(script);service.start(run)
        task=service.active[run['id']][1]
        for _ in range(200):
            if len(model.prompts)>70:break
            await asyncio.sleep(.01)
        self.assertGreater(len(model.prompts),70)
        service.stop(run['id']);await asyncio.wait_for(task,2)
        self.assertEqual(self.store.run(run['id'])['end_reason'],'user_stop')
        self.assertTrue(self.answer()['content'].startswith('Stopped.'))
