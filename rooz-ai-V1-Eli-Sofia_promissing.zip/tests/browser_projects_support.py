from playwright.sync_api import expect

def create_project(page,name):
    if not page.locator('#projectDialog').is_visible():
        page.locator('#newChat').click()
    expect(page.locator('#projectDialog')).to_be_visible()
    page.get_by_label('Project name',exact=True).fill(name)
    page.get_by_role('button',name='Create project',exact=True).click()
    expect(page.locator('#projectDialog')).not_to_be_visible(timeout=15000)
