"""Attachment storage, room isolation and actual SDK image-payload regression checks."""
import asyncio,base64,copy,io,json,tempfile,unittest
from pathlib import Path
from unittest.mock import patch
from PIL import Image
import httpx
from openai import AsyncOpenAI
from fastapi.testclient import TestClient
from rooz.storage import Store
from rooz.attachments import Attachments,AttachmentError,MAX_FILE_BYTES,MAX_TEXT_BYTES
from rooz.agents import AgentService
from rooz.api import create_app
from tests.support import Model,Message,call,NativeTestRunner

def picture():
 output=io.BytesIO();Image.new('RGB',(40,30),(230,30,40)).save(output,'PNG');return output.getvalue()
def image_parts(messages):
 return [p for m in messages if isinstance(m.get('content'),list) for p in m['content'] if p.get('type') in ('image_url','input_image')]
def assert_pixels(test,part):
 url=part['image_url'] if isinstance(part['image_url'],str) else part['image_url']['url']
 test.assertTrue(url.startswith('data:image/jpeg;base64,'))
 with Image.open(io.BytesIO(base64.b64decode(url.split(',',1)[1]))) as im:
  test.assertEqual(im.size,(40,30));test.assertGreater(im.getpixel((0,0))[0],200)

class AttachmentStoreTests(unittest.TestCase):
 def setUp(self):
  self.temp=tempfile.TemporaryDirectory();self.addCleanup(self.temp.cleanup);self.store=Store(self.temp.name);self.files=Attachments(self.store);self.chat=self.store.create_chat()
 def test_uploads_do_not_enter_the_executable_workspace_or_change_its_revision(self):
  before=self.store.revision(self.chat['project_id']);saved=self.files.save(self.chat['id'],[('app.py',b'raise RuntimeError("must not execute")')])
  self.assertEqual(self.store.manifest(self.chat['project_id']),[]);self.assertEqual(before,self.store.revision(self.chat['project_id']))
  self.assertEqual(self.files.list(self.chat['id']),[]);self.assertEqual(self.files.list(self.chat['id'],pending=True)[0]['id'],saved[0]['id'])
 def test_original_image_download_and_normalized_view_are_separate(self):
  saved=self.files.save(self.chat['id'],[('SCREENSHOT.PNG',picture())])[0];row=self.files.get(self.chat['id'],saved['id'])
  self.assertEqual(self.files.original_path(row).read_bytes(),picture())
  with Image.open(self.files.image_path(row)) as view:self.assertEqual(view.format,'JPEG');self.assertEqual(view.size,(40,30))
 def test_invalid_batch_is_atomic_and_does_not_overwrite_files(self):
  with self.assertRaises(AttachmentError):self.files.save(self.chat['id'],[('ok.py',b'print(1)'),('bad.png',b'not an image')])
  self.assertEqual(self.files.list(self.chat['id'],pending=True),[]);self.assertEqual(list(self.files.root.iterdir()),[])
 def test_unsafe_names_binary_text_and_unsupported_types_are_rejected(self):
  for name,data in [('../app.py',b'x'),('a\\b.py',b'x'),('bad.py',b'\x00\xff'),('file.exe',b'x'),('.env',b'KEY=private'),('empty.md',b'')]:
   with self.subTest(name=name),self.assertRaises(AttachmentError):self.files.save(self.chat['id'],[(name,data)])
 def test_type_bytes_and_filename_must_agree(self):
  with self.assertRaises(AttachmentError):self.files.save(self.chat['id'],[('picture.jpg',picture())])
 def test_text_size_and_pending_file_count_limits_are_enforced(self):
  with self.assertRaises(AttachmentError):self.files.save(self.chat['id'],[('large.md',b'x'*(MAX_TEXT_BYTES+1))])
  self.files.save(self.chat['id'],[(str(i)+'.txt',b'ok') for i in range(8)])
  with self.assertRaises(AttachmentError):self.files.save(self.chat['id'],[('ninth.txt',b'no')])
  self.assertEqual(len(self.files.list(self.chat['id'],pending=True)),8)
 def test_text_can_be_read_in_windows_without_losing_minified_code(self):
  data=('const value="'+('abc'*12000)+'";').encode();saved=self.files.save(self.chat['id'],[('long.js',data)])[0];row=self.files.get(self.chat['id'],saved['id'])
  chunks=[];offset=0
  while True:
   chunk=self.files.text(row,offset,9000);chunks.append(chunk['text'])
   if chunk['next_offset'] is None:break
   offset=chunk['next_offset']
  self.assertEqual(''.join(chunks),data.decode())
 def test_binding_is_atomic_and_rejects_cross_room_or_reused_ids(self):
  saved=self.files.save(self.chat['id'],[('notes.md',b'# Notes')])[0];other=self.store.create_chat()
  with self.assertRaises(ValueError):self.store.start_run(other['id'],'alex','Read it',[saved['id']])
  self.assertEqual(self.store.messages(other['id']),[])
  run=self.store.start_run(self.chat['id'],'alex','Read it',[saved['id']]);self.store.finish(run['id'],'completed','Done','Read')
  with self.assertRaises(ValueError):self.store.start_run(self.chat['id'],'alex','Reuse',[saved['id']])
  self.assertEqual(len(self.files.list(self.chat['id'])),1)
 def test_pending_removal_and_restart_preserve_sent_attachments(self):
  one,two=self.files.save(self.chat['id'],[('notes.md',b'# Notes'),('shot.png',picture())]);self.files.remove_pending(self.chat['id'],one['id'])
  run=self.store.start_run(self.chat['id'],'sofia','Review',[two['id']]);self.store.finish(run['id'],'completed','Done','Reviewed')
  with self.assertRaises(AttachmentError):self.files.remove_pending(self.chat['id'],two['id'])
  reopened=Attachments(Store(self.temp.name));self.assertEqual(reopened.list(self.chat['id'])[0]['id'],two['id']);self.assertTrue(reopened.original_path(reopened.get(self.chat['id'],two['id'])).is_file())

class AttachmentApiTests(unittest.TestCase):
 def setUp(self):
  self.temp=tempfile.TemporaryDirectory();self.addCleanup(self.temp.cleanup)
  self.app=create_app(self.temp.name,Path(__file__).parents[1]/'static',lambda:Model([Message('Attachment inspected')]),'test-model',NativeTestRunner())
  self.client=TestClient(self.app);self.client.__enter__();self.addCleanup(self.client.__exit__,None,None,None)
  self.chat=self.client.post('/api/chats',json={}).json()
 def upload(self,files):return self.client.post('/api/chats/'+self.chat['id']+'/attachments',files=files)
 def test_multipart_upload_download_and_thumbnail_use_actual_bytes(self):
  response=self.upload([('files',('notes.md',b'# The actual notes','application/octet-stream')),('files',('shot.png',picture(),'text/plain'))])
  self.assertEqual(response.status_code,201);notes,image=response.json()['attachments']
  self.assertEqual(self.client.get(notes['download_url']).content,b'# The actual notes')
  original=self.client.get(image['download_url']);self.assertEqual(original.content,picture());self.assertIn('attachment',original.headers['content-disposition'])
  thumb=self.client.get(image['thumbnail_url']);self.assertEqual(thumb.headers['content-type'],'image/jpeg')
  self.assertEqual(self.client.get('/api/chats/'+self.chat['id']).json()['files'],[])
 def test_image_only_message_is_supported_and_pending_files_move_to_message(self):
  saved=self.upload([('files',('shot.png',picture(),'image/png'))]).json()['attachments'][0]
  response=self.client.post('/api/chats/'+self.chat['id']+'/messages',json={'agent':'SOFIA','attachment_ids':[saved['id']]})
  self.assertEqual(response.status_code,202)
  data=self.client.get('/api/chats/'+self.chat['id']).json();self.assertFalse(data['pending_attachments'])
  self.assertEqual(data['messages'][0]['attachments'][0]['id'],saved['id'])
 def test_cross_room_download_binding_and_pending_deletion_are_scoped(self):
  saved=self.upload([('files',('notes.md',b'Notes','text/plain'))]).json()['attachments'][0];other=self.client.post('/api/chats',json={}).json()
  self.assertEqual(self.client.get('/api/chats/'+other['id']+'/attachments/'+saved['id']+'/download').status_code,404)
  self.assertEqual(self.client.post('/api/chats/'+other['id']+'/messages',json={'content':'Read it','attachment_ids':[saved['id']]}).status_code,409)
  self.assertEqual(self.client.delete('/api/chats/'+self.chat['id']+'/attachments/'+saved['id']).status_code,200)
  self.assertEqual(self.client.get(saved['download_url']).status_code,404)
 def test_oversized_and_invalid_image_requests_fail_with_actionable_errors(self):
  response=self.upload([('files',('shot.png',b'not png','image/png'))]);self.assertEqual(response.status_code,422);self.assertIn('image',response.json()['detail'])
  response=self.upload([('files',('large.txt',b'x'*(MAX_FILE_BYTES+1),'text/plain'))]);self.assertEqual(response.status_code,413)

class AttachmentModelTests(unittest.IsolatedAsyncioTestCase):
 async def asyncSetUp(self):
  self.temp=tempfile.TemporaryDirectory();self.addCleanup(self.temp.cleanup);self.store=Store(self.temp.name);self.files=Attachments(self.store);self.chat=self.store.create_chat()
 def attach(self,files):return self.files.save(self.chat['id'],files)
 async def test_actual_chat_sdk_sends_image_pixels_and_text_excerpts(self):
  saved=self.attach([('shot.png',picture()),('notes.md',b'# EXACT_REFERENCE_TOKEN')]);requests=[]
  async def handler(request):
   self.assertEqual(request.url.path,'/v1/chat/completions');body=json.loads(request.content);requests.append(body)
   images=image_parts(body['messages']);self.assertEqual(len(images),1);assert_pixels(self,images[0]);self.assertIn('EXACT_REFERENCE_TOKEN',json.dumps(body['messages']))
   return httpx.Response(200,json={'id':'fixture','object':'chat.completion','created':1,'model':'gpt-4.1-mini','choices':[{'index':0,'message':{'role':'assistant','content':'Fixture inspected the supplied inputs'},'finish_reason':'stop'}]})
  client=AsyncOpenAI(api_key='fixture-not-real',http_client=httpx.AsyncClient(transport=httpx.MockTransport(handler)))
  run=self.store.start_run(self.chat['id'],'sofia','Review attachments',[r['id'] for r in saved]);runner=NativeTestRunner()
  await AgentService(self.store,runner,lambda:client,'gpt-4.1-mini').execute(run,asyncio.Event())
  self.assertEqual(self.store.run(run['id'])['status'],'completed',self.store.messages(self.chat['id'])[-1]['content']);self.assertEqual(runner.commands,[])
 async def test_actual_responses_sdk_sends_input_image_with_same_pixels(self):
  saved=self.attach([('shot.png',picture())])
  async def handler(request):
   self.assertEqual(request.url.path,'/v1/responses');body=json.loads(request.content)
   images=image_parts(body['input']);self.assertEqual(images[0]['type'],'input_image');assert_pixels(self,images[0]);self.assertEqual(body['reasoning'],{'effort':'low'})
   return httpx.Response(200,json={'id':'fixture','object':'response','created_at':1,'status':'completed','model':'gpt-6.1-sol','output':[{'type':'message','id':'m1','role':'assistant','status':'completed','content':[{'type':'output_text','text':'Fixture image received','annotations':[]}]}]})
  client=AsyncOpenAI(api_key='fixture-not-real',http_client=httpx.AsyncClient(transport=httpx.MockTransport(handler)))
  run=self.store.start_run(self.chat['id'],'alex','Review',[saved[0]['id']])
  await AgentService(self.store,NativeTestRunner(),lambda:client,'gpt-6.1-sol').execute(run,asyncio.Event())
  self.assertEqual(self.store.run(run['id'])['status'],'completed',self.store.messages(self.chat['id'])[-1]['content'])
 async def test_called_teammate_receives_the_same_root_images(self):
  saved=self.attach([('shot.png',picture())]);model=Model([Message(calls=[call('call_agent',{'agent':'SOFIA','message':'Review the attached screen','reason':'UI expertise'})]),Message('Sofia reviewed it'),Message('Alex combined the review')]);captured=[];original=model.create
  async def capture(**kwargs):captured.append(copy.deepcopy(kwargs));return await original(**kwargs)
  model.chat.completions.create=capture
  run=self.store.start_run(self.chat['id'],'alex','Ask Sofia to inspect this image',[saved[0]['id']])
  await AgentService(self.store,NativeTestRunner(),lambda:model,'test-model').execute(run,asyncio.Event())
  self.assertEqual(self.store.run(run['id'])['status'],'completed')
  for request in captured:assert_pixels(self,image_parts(request['messages'])[0])
  self.assertTrue(captured[1]['messages'][0]['content'].startswith('You are Sofia'))
 async def test_old_image_tool_read_supplies_pixels_after_the_tool_result(self):
  saved=self.attach([('old.png',picture())])[0];prior=self.store.start_run(self.chat['id'],'alex','Earlier picture',[saved['id']]);self.store.finish(prior['id'],'completed','Done','Earlier review')
  model=Model([Message(calls=[call('read_attachment',{'attachment_id':saved['id'],'offset':0,'limit':20000})]),Message('Sofia inspected the previous image')]);run=self.store.start_run(self.chat['id'],'sofia','Look at the earlier image')
  await AgentService(self.store,NativeTestRunner(),lambda:model,'test-model').execute(run,asyncio.Event())
  final=model.prompts[-1]['messages'];self.assertTrue(any(m['role']=='tool' for m in final));assert_pixels(self,image_parts(final)[0])
 async def test_pending_and_other_rooms_attachments_are_not_available_to_agents(self):
  pending=self.attach([('pending.png',picture())])[0];other=self.store.create_chat();foreign=self.files.save(other['id'],[('private.md',b'OTHER_ROOM_SECRET')])[0]
  foreign_run=self.store.start_run(other['id'],'eli','Private',[foreign['id']]);self.store.finish(foreign_run['id'],'completed','Done','Private')
  model=Model([Message(calls=[call('list_attachments',{}),call('read_attachment',{'attachment_id':foreign['id'],'offset':0,'limit':20000}),call('read_attachment',{'attachment_id':pending['id'],'offset':0,'limit':20000})]),Message('No accessible sent attachments')]);run=self.store.start_run(self.chat['id'],'alex','Inspect available files')
  await AgentService(self.store,NativeTestRunner(),lambda:model,'test-model').execute(run,asyncio.Event())
  result=model.prompts[-1]['messages'];self.assertFalse(image_parts(result));self.assertNotIn('OTHER_ROOM_SECRET',json.dumps(result))
  self.assertEqual(json.loads(next(m['content'] for m in result if m['role']=='tool'))['attachments'],[])
 async def test_uploading_code_for_review_does_not_execute_or_change_it(self):
  source=b'raise RuntimeError("must not execute uploaded code")';saved=self.attach([('review.py',source)])[0]
  model=Model([Message(calls=[call('read_attachment',{'attachment_id':saved['id'],'offset':0,'limit':20000})]),Message('This code raises an exception; review only.')]);runner=NativeTestRunner();run=self.store.start_run(self.chat['id'],'eli','Review this code, do not run or change it',[saved['id']])
  await AgentService(self.store,runner,lambda:model,'test-model').execute(run,asyncio.Event())
  self.assertEqual(runner.commands,[]);self.assertEqual(self.store.manifest(self.chat['project_id']),[])
  self.assertEqual(self.files.original_path(self.files.get(self.chat['id'],saved['id'])).read_bytes(),source)

if __name__=='__main__':unittest.main()
