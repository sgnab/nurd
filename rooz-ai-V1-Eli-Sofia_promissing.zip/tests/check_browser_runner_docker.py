"""Actual Node Playwright/Chromium check, from a root without package.json."""
import asyncio
import json
import sys
import tempfile
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from rooz.runner import DockerRunner

CONFIG = '''import { defineConfig } from '@playwright/test';
export default defineConfig({testDir:'./frontend',testMatch:'*.spec.ts',workers:1,
outputDir:'/tmp/rooz-node-results',reporter:'list',
use:{browserName:'chromium',launchOptions:{args:['--no-sandbox','--disable-dev-shm-usage']}}});
'''
SPEC = '''import { test, expect } from '@playwright/test';
test('real browser click changes UI state', async ({ page }) => {
 await page.setContent('<button onclick="this.textContent=\\\'Clicked\\\'">Click me</button>');
 await page.getByRole('button',{name:'Click me',exact:true}).click();
 await expect(page.getByRole('button',{name:'Clicked',exact:true})).toBeVisible();
});
'''

def fixture(root):
    (root/'frontend').mkdir(parents=True,exist_ok=True)
    (root/'playwright.config.ts').write_text(CONFIG)
    (root/'frontend/runner.spec.ts').write_text(SPEC)

async def main():
    with tempfile.TemporaryDirectory(prefix='rooz-node-test-') as directory:
        root=Path(directory);fixture(root)
        result=await DockerRunner().run(root,['npx','--no-install','playwright','test','frontend/runner.spec.ts','--workers=1'],asyncio.Event())
        print(json.dumps(result,indent=2))
        return 0 if result['status']=='passed' else 1

if __name__=='__main__':raise SystemExit(asyncio.run(main()))
