"""Regression: image inspect fails but the same image executes successfully."""
import asyncio,ast,json,os,sys,tempfile,unittest
from pathlib import Path
from unittest.mock import patch
from rooz.docker_environment import DockerError,docker_command,image_capability
from rooz.runner import DockerRunner
from rooz.preview import DockerPreview

def marker(args):return ast.literal_eval(args[-1][6:-1])

class DockerEnvironmentTests(unittest.IsolatedAsyncioTestCase):
 async def test_real_subprocess_contract_recognizes_runnable_image_despite_inspect_failure(self):
  with tempfile.TemporaryDirectory() as directory:
   root=Path(directory);log=root/'calls.jsonl';docker=root/'docker'
   docker.write_text('#!'+sys.executable+'\n'+
    'import sys,json,ast\nfrom pathlib import Path\na=sys.argv[1:]\n'+
    'with Path('+repr(str(log))+').open("a") as f:f.write(json.dumps(a)+"\\n")\n'+
    'if a[:2]==["image","inspect"]:print("No such image",file=sys.stderr);sys.exit(1)\n'+
    'if a[0]=="info":print("28.1.1")\n'+
    'elif a[0]=="run":print(ast.literal_eval(a[-1][6:-1]))\n')
   docker.chmod(0o755)
   with patch.dict(os.environ,{'PATH':str(root)+os.pathsep+os.environ.get('PATH','')}):
    self.assertEqual((await docker_command('image','inspect','rooz-ai-runner:stage1',check=False))[0],1)
    self.assertTrue((await DockerRunner().capability())['ready'])
    self.assertTrue((await DockerPreview().capability())['ready'])
   calls=[json.loads(line) for line in log.read_text().splitlines()]
   self.assertEqual(sum(a[0]=='run' for a in calls),2);self.assertFalse(any(a[:2]==['image','inspect'] for a in calls[1:]))
 async def test_probe_is_isolated_and_uses_only_fixed_python_without_pulling(self):
  calls=[]
  async def command(*args,**kwargs):
   calls.append(args)
   return (0,marker(args)+'\n') if args[0]=='run' else (0,'28.1.1')
  result=await image_capability('custom-image:tag',command);self.assertTrue(result['ready']);self.assertEqual(result['checked_by'],'container-execution')
  args=calls[-1]
  for flag in ['--rm','--pull=never','--network','none','--read-only','--cap-drop','ALL','no-new-privileges','--entrypoint','python','custom-image:tag']:self.assertIn(flag,args)
  self.assertNotIn('-v',args);self.assertNotIn('-e',args);self.assertNotIn('seccomp=unconfined',args)
 async def test_real_missing_image_preserves_docker_error_and_build_instruction(self):
  async def command(*args,**kwargs):return (125,'Error response from daemon: No such image: absent:tag') if args[0]=='run' else (0,'28')
  result=await image_capability('absent:tag',command);self.assertFalse(result['ready']);self.assertIn('No such image',result['reason']);self.assertIn('docker build -t absent:tag',result['reason'])
 async def test_daemon_failure_does_not_get_misreported_as_missing_image(self):
  calls=[]
  async def command(*args,**kwargs):calls.append(args);raise DockerError('Cannot connect to the Docker daemon')
  result=await image_capability('image',command);self.assertFalse(result['ready']);self.assertIn('daemon',result['reason']);self.assertNotIn('docker build',result['reason']);self.assertEqual(len(calls),1)
 async def test_execution_failure_and_missing_marker_never_report_ready(self):
  for code,output in [(126,'permission denied'),(1,'Python failed'),(0,'Unrelated output')]:
   async def command(*args,**kwargs):return (code,output) if args[0]=='run' else (0,'28')
   result=await image_capability('image',command);self.assertFalse(result['ready']);self.assertIn(output,result['reason']);self.assertNotIn('docker build',result['reason'])
 async def test_probe_timeout_removes_container_and_reports_the_actual_phase(self):
  calls=[]
  async def command(*args,**kwargs):
   calls.append(args)
   if args[0]=='run':raise TimeoutError()
   return 0,''
  result=await image_capability('image',command);self.assertFalse(result['ready']);self.assertIn('execution probe timed out',result['reason'])
  self.assertEqual(calls[-1][:2],('rm','-f'));self.assertEqual(calls[-1][-1],calls[1][calls[1].index('--name')+1])
 async def test_cancelled_probe_cleans_up_and_propagates_cancellation(self):
  entered=asyncio.Event();calls=[]
  async def command(*args,**kwargs):
   calls.append(args)
   if args[0]=='run':entered.set();await asyncio.Event().wait()
   return 0,''
  task=asyncio.create_task(image_capability('image',command));await entered.wait();task.cancel()
  with self.assertRaises(asyncio.CancelledError):await task
  self.assertEqual(calls[-1][:2],('rm','-f'))
 async def test_concurrent_probes_use_distinct_container_names_and_tokens(self):
  runs=[]
  async def command(*args,**kwargs):
   if args[0]=='run':runs.append(args);await asyncio.sleep(0);return 0,marker(args)
   return 0,'28'
  results=await asyncio.gather(image_capability('image',command),image_capability('image',command))
  self.assertTrue(all(r['ready'] for r in results));self.assertNotEqual(runs[0][runs[0].index('--name')+1],runs[1][runs[1].index('--name')+1]);self.assertNotEqual(marker(runs[0]),marker(runs[1]))

if __name__=='__main__':unittest.main()
