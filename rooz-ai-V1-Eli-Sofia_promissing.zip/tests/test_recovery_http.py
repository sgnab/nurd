"""Real local HTTP, SQLite and subprocesses; controlled model, no provider calls."""
import asyncio
import json
import socket
import tempfile
import threading
import time
import unittest
from pathlib import Path
from types import SimpleNamespace
import httpx
import uvicorn
from rooz.api import create_app
from tests.support import Message,Model,NativeTestRunner,call

class RecoveryModel(Model):
    async def create(self,**kwargs):
        if any(m['role']=='user' and m.get('content')=='Wait for Stop' for m in kwargs['messages']):
            await asyncio.sleep(1000)
        rows=[m for m in kwargs['messages'] if m['role']=='tool']
        if not rows:
            result=Message(calls=[call('run_tests',{'command':['python','-c',"from pathlib import Path; assert Path('built.txt').read_text()=='Requested UI'"]})])
        elif len(rows)==1:
            failed=json.loads(rows[0]['content'])
            result=Message(calls=[call('rerun_check',{'check_id':failed['check_id'],
                'command':['python','-c',"from pathlib import Path; Path('built.txt').write_text('Requested UI'); assert Path('built.txt').read_text()=='Requested UI'"],
                'reason':'Prepare the disposable build first and retain the same rendered-content assertion'})])
        else:result=Message('Corrected command verified without repeating the obsolete probe.')
        return SimpleNamespace(choices=[SimpleNamespace(message=result)])

class RealHTTPRecovery(unittest.TestCase):
    def test_correction_and_stop_through_real_http(self):
        with tempfile.TemporaryDirectory() as directory:
            app=create_app(directory,Path(__file__).parents[1]/'static',lambda:RecoveryModel(),'fixture',NativeTestRunner())
            sock=socket.socket();sock.bind(('127.0.0.1',0));port=sock.getsockname()[1]
            server=uvicorn.Server(uvicorn.Config(app,log_level='error'))
            thread=threading.Thread(target=server.run,kwargs={'sockets':[sock]},daemon=True);thread.start()
            try:
                with httpx.Client(base_url='http://127.0.0.1:'+str(port),timeout=3,trust_env=False) as client:
                    deadline=time.monotonic()+5
                    while not server.started:
                        if time.monotonic()>deadline:raise AssertionError('HTTP server failed to start')
                        time.sleep(.01)
                    chat=client.post('/api/projects',json={'title':'Recovery HTTP fixture'}).json()
                    run=client.post('/api/chats/'+chat['id']+'/messages',json={'agent':'eli','content':'Verify the requested UI'}).json()
                    result=self.wait_result(client,run['id'])
                    self.assertEqual(result['status'],'completed')
                    first,second=result['checks'];self.assertEqual([first['status'],second['status']],['failed','passed'])
                    self.assertEqual(first['superseded_by'],second['execution_id'])
                    refreshed=client.get('/api/chats/'+chat['id']).json()
                    self.assertEqual(refreshed['runs'][0]['checks'],result['checks'])
                    self.assertIn('obsolete probe',refreshed['messages'][-1]['content'])
                    run=client.post('/api/chats/'+chat['id']+'/messages',json={'agent':'eli','content':'Wait for Stop'}).json()
                    response=client.post('/api/runs/'+run['id']+'/stop');self.assertEqual(response.status_code,200)
                    result=self.wait_result(client,run['id'])
                    self.assertEqual((result['status'],result['end_reason']),('cancelled','user_stop'))
            finally:
                server.should_exit=True;thread.join(5);sock.close()
                self.assertFalse(thread.is_alive(),'HTTP server must be cleaned up')
    def wait_result(self,client,run_id):
        deadline=time.monotonic()+5
        while time.monotonic()<deadline:
            result=client.get('/api/runs/'+run_id).json()
            if result['status'] in ('completed','failed','cancelled','interrupted'):return result
            time.sleep(.02)
        self.fail('Request did not settle through HTTP')
