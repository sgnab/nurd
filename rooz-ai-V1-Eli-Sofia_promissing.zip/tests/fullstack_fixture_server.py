"""HTTP/UI fixture with a controlled real application; native execution is test-only."""
import os
from pathlib import Path
from rooz.api import create_app
from tests.support import Model,NativeTestRunner
from tests.fullstack_support import NativeFullstackPreview,write_app

backend=NativeFullstackPreview()
app=create_app(os.environ['ROOZ_FIXTURE_DATA'],Path(__file__).parents[1]/'static',lambda:Model(),'fixture',NativeTestRunner(),backend)
chat=app.state.store.create_chat('Full-stack fixture')
write_app(app.state.store.workspace(chat['project_id']))
if os.environ.get('ROOZ_FIXTURE_PLAIN_HTML')=='1':
    root=app.state.store.workspace(chat['project_id'])
    (root/'frontend/package.json').unlink();(root/'frontend/build.cjs').unlink()

if __name__=='__main__':
    import uvicorn
    uvicorn.run(app,host='127.0.0.1',port=int(os.environ['ROOZ_FIXTURE_PORT']),log_level='warning')
