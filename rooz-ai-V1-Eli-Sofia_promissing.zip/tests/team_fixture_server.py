"""Stage 1.5 browser fixture: scripted agents, real HTTP/storage and controlled test execution."""
import asyncio,os
from pathlib import Path
from types import SimpleNamespace
from rooz.api import create_app
from tests.fixture_server import BrowserModel
from tests.support import Message,call,NativeTestRunner

class TeamModel(BrowserModel):
 async def create(self,**kwargs):
  system=kwargs['messages'][0]['content'];speaker=next(a for a in ('alex','sofia','eli') if system.startswith('You are '+a.title()))
  user=next(m['content'] for m in reversed(kwargs['messages']) if m['role']=='user');tools=[m for m in kwargs['messages'] if m['role']=='tool']
  value=None
  if 'stopflow' in user:
   if speaker=='alex' and not tools:value=Message(calls=[call('call_agent',{'agent':'sOFia','message':'stopflow: work until stopped','reason':'Frontend help'})])
   elif speaker=='sofia':await asyncio.sleep(1000)
  elif 'teamflow' in user:
   if speaker=='alex':
    value=Message('ALEX_RESULT: combined answer') if tools else Message(calls=[call('call_agent',{'agent':'SOFIA','message':'teamflow: prepare the UI with Eli’s help','reason':'Frontend implementation'})])
   elif speaker=='sofia':
    value=Message('SOFIA_RESULT: UI uses Eli’s logic') if tools else Message(calls=[call('call_agent',{'agent':'eLI','message':'teamflow: implement and test a small function','reason':'Backend implementation'})])
   elif not tools:
    value=Message(calls=[call('write_files',{'files':[{'path':'logic.py','content':'def double(n): return n*2\n'},{'path':'test_logic.py','content':'import unittest\nfrom logic import double\nclass Tests(unittest.TestCase):\n def test_double(self): self.assertEqual(double(3),6)\n'}]})])
   elif len(tools)==1:value=Message(calls=[call('run_tests',{'command':['python','-m','unittest','discover','-v']})])
   else:value=Message('ELI_RESULT: saved and tested logic')
  if value is not None:return SimpleNamespace(choices=[SimpleNamespace(message=value)])
  return await super().create(**kwargs)

app=create_app(os.environ['ROOZ_FIXTURE_DATA'],Path(__file__).parents[1]/'static',lambda:TeamModel(),'scripted-test-model',NativeTestRunner())
if __name__=='__main__':
 import uvicorn
 uvicorn.run(app,host='127.0.0.1',port=int(os.environ['ROOZ_FIXTURE_PORT']),log_level='warning')
