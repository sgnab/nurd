"""Sofia-only orchestration fixtures; not live-model/browser success claims."""
import ast,asyncio,hashlib,io,json,tempfile,unittest
from pathlib import Path
from PIL import Image
from rooz import sofia
from rooz.agents import AgentService
from rooz.storage import Store
from tests.support import Model,Message,call,NativeTestRunner
ROOT=Path(__file__).parents[1]

def picture():
 data=io.BytesIO();Image.new('RGB',(48,32),(40,100,80)).save(data,'PNG');return data.getvalue()
class PictureRunner:
 """Controlled image-bearing result for host delivery/revision tests."""
 def __init__(self,states=('passed',)):self.states=list(states);self.commands=[]
 async def run(self,workspace,command,stop):
  self.commands.append(command)
  if stop.is_set():raise asyncio.CancelledError()
  state=self.states.pop(0) if self.states else 'passed'
  if state=='raise_timeout':raise TimeoutError()
  result={'status':'passed' if state=='no_images' else state,'command':command,'exit_code':0 if state in ('passed','no_images') else 1,'output':'Controlled verification fixture: '+state}
  if state=='passed':result['_screenshots']=[{'filename':'desktop.png','data':picture()}]
  return result

class EliIsolation(unittest.TestCase):
 def test_shared_module_is_identical_except_sofia_dispatch(self):
  baseline=json.loads((ROOT/'tests/sofia_eli_baseline.json').read_text());tree=ast.parse((ROOT/'rooz/agents.py').read_text())
  cls=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='AgentService')
  method=next(n for n in cls.body if isinstance(n,ast.AsyncFunctionDef) and n.name=='_respond');branch=method.body.pop(0)
  self.assertIsInstance(branch,ast.If);self.assertEqual(ast.unparse(branch.test),"agent == 'sofia'")
  self.assertEqual(ast.unparse(branch.body[0]),'from .sofia_flow import respond')
  self.assertIn('return await respond(self, run, agent, stop, client, checks, session, depth, assignment, reply_id)',ast.unparse(branch))
  self.assertEqual(hashlib.sha256(ast.dump(tree,include_attributes=False).encode()).hexdigest(),baseline['shared_agents_ast_sha256'])
 def test_eli_and_shared_services_are_byte_identical(self):
  for name,expected in json.loads((ROOT/'tests/sofia_eli_baseline.json').read_text())['protected_files'].items():
   with self.subTest(file=name):self.assertEqual(hashlib.sha256((ROOT/name).read_bytes()).hexdigest(),expected)

class SofiaContext(unittest.TestCase):
 def test_own_guides_and_known_runtime(self):
  self.assertEqual(set(sofia.GUIDES),{'frontend','testing','debugging','visual'})
  for name in sofia.GUIDES:self.assertIn('instructions',sofia.read_skill(name))
  for name in ('backend','../../eli.py'):
   with self.assertRaises(ValueError):sofia.read_skill(name)
  with tempfile.TemporaryDirectory() as folder:
   root=Path(folder);(root/'DESIGN.md').write_text('a'*13000);context=sofia.context(root)
   self.assertTrue(context['project_documents']['DESIGN.md']['truncated']);self.assertIn('/ms-playwright',context['instructions']);self.assertIn('NOT preinstalled',context['instructions'])
 def test_starter_atomic_and_preserves_existing_project(self):
  with tempfile.TemporaryDirectory() as folder:
   root=Path(folder);rows=sofia.files(root);files={r['path']:r['content'] for r in rows}
   self.assertLessEqual(len(rows),20);self.assertIn('frontend/src/services/items.ts',files)
   self.assertIn('No application/domain data API',files['backend/main.py'])
   self.assertIn('frontend acceptance',files['tests/verify.py'].lower());self.assertNotIn('Check backend',files['tests/browser_check.py']);self.assertIn('page.reload()',files['tests/browser_check.py'])
   self.assertIn('saved === null',files['frontend/src/services/items.ts']);self.assertNotIn('tests/test_api.py',files)
   (root/'keep.ts').write_text('keep')
   with self.assertRaises(ValueError):sofia.files(root)
   self.assertEqual((root/'keep.ts').read_text(),'keep')
 def test_js_utility_is_not_a_full_ui(self):
  with tempfile.TemporaryDirectory() as folder:
   root=Path(folder);(root/'util.js').write_text('export const add=(a,b)=>a+b;');self.assertFalse(sofia.has_ui(root));(root/'index.html').write_text('<h1>App</h1>');self.assertTrue(sofia.has_ui(root))

class SofiaFlow(unittest.IsolatedAsyncioTestCase):
 async def execute(self,script,files=None,runner=None,timeout=3):
  temp=tempfile.TemporaryDirectory();self.addCleanup(temp.cleanup);store=Store(temp.name);chat=store.create_chat('Sofia fixture');root=store.workspace(chat['project_id'])
  for name,text in (files or {}).items():
   path=root/name;path.parent.mkdir(parents=True,exist_ok=True);path.write_text(text)
  run=store.start_run(chat['id'],'sofia','Implement requested frontend');model=Model(script);service=AgentService(store,runner or NativeTestRunner(),lambda:model,'fixture');service.request_timeout=timeout
  await service.execute(run,asyncio.Event());return store,chat,run,model
 async def test_own_tools_context_without_eli_tools(self):
  store,chat,run,model=await self.execute([Message(calls=[call('read_skill',{'name':'visual'})]),Message('Review complete.')],{'DESIGN.md':'Preserve client routes'})
  self.assertEqual(store.run(run['id'])['status'],'completed');names={t['function']['name'] for t in model.prompts[0]['tools']}
  self.assertTrue({'scaffold_frontend','verify_ui','view_screenshot','read_skill','rerun_check','report_execution_blocker'}<=names);self.assertFalse({'scaffold_app','verify_app'}&names)
  self.assertIn('Sofia development context',model.prompts[0]['messages'][0]['content']);self.assertIn('Preserve client routes',model.prompts[0]['messages'][0]['content']);self.assertNotIn('Eli development context',model.prompts[0]['messages'][0]['content'])
 async def test_scaffold_preserved_when_runtime_unavailable(self):
  runner=NativeTestRunner(unavailable=True)
  store,chat,run,model=await self.execute([Message(calls=[call('scaffold_frontend',{})]),Message('Starter saved.'),Message('Runtime unavailable; not verified.')],runner=runner)
  result=store.run(run['id']);self.assertEqual(result['status'],'failed');self.assertEqual(result['checks'][0]['kind'],'frontend acceptance');self.assertEqual(result['checks'][0]['status'],'unavailable')
  self.assertTrue((store.workspace(chat['project_id'])/'frontend/src/services/items.ts').is_file());self.assertEqual(len(store.artifacts(chat['project_id'])),20);self.assertEqual(runner.commands,[['python','tests/verify.py']])
 async def test_repair_and_actual_image_delivery_before_return(self):
  runner=PictureRunner(('failed','passed'));script=[Message(calls=[call('run_tests',{'command':['python','tests/verify.py']})]),Message('Confirm to proceed.'),Message(calls=[call('read_skill',{'name':'debugging'})]),Message(calls=[call('read_files',{'paths':['index.html']})]),Message(calls=[call('write_files',{'files':[{'path':'index.html','content':'<h1>Repaired UI</h1>'}]})]),Message(calls=[call('verify_ui',{})]),Message('Implemented and reviewed returned fixture pixels.')]
  store,chat,run,model=await self.execute(script,{'index.html':'<h1>Old UI</h1>','tests/verify.py':'# fixture only'},runner)
  result=store.run(run['id']);self.assertEqual(result['status'],'completed');self.assertEqual([c['status'] for c in result['checks']],['failed','passed']);self.assertEqual(result['checks'][0]['superseded_by'],result['checks'][1]['execution_id'])
  self.assertIn('Continue now; do not ask for confirmation',json.dumps(model.prompts[-1]['messages']));images=[p for m in model.prompts[-1]['messages'] if isinstance(m.get('content'),list) for p in m['content'] if p.get('type')=='image_url'];self.assertEqual(len(images),1)
  self.assertEqual(result['checks'][-1]['revision'],store.revision(chat['project_id']))
 async def test_build_without_pixels_returns_to_visual_review(self):
  runner=PictureRunner(('no_images','passed'));script=[Message(calls=[call('write_files',{'files':[{'path':'index.html','content':'<h1>New screen</h1>'}]})]),Message('Done.'),Message('Build passed.'),Message(calls=[call('verify_ui',{})]),Message('Now reviewed image.')]
  store,chat,run,model=await self.execute(script,runner=runner);self.assertEqual(store.run(run['id'])['status'],'completed');self.assertEqual(runner.commands,[['python','tests/verify.py'],['python','tests/verify.py']]);self.assertIn('no browser screenshots',json.dumps(model.prompts[-1]['messages']))
 async def test_read_before_edit_enforced(self):
  store,chat,run,model=await self.execute([Message(calls=[call('write_files',{'files':[{'path':'util.py','content':'value=2'}]})]),Message('Not changed.')],{'util.py':'value=1'})
  self.assertIn('Read the current file',json.dumps(model.prompts[-1]['messages']));self.assertEqual((store.workspace(chat['project_id'])/'util.py').read_text(),'value=1')
 async def test_transient_model_timeout_recovers_same_request_and_preserves_source(self):
  store,chat,run,model=await self.execute([TimeoutError(),Message('Recovered without regenerating files.')],{'keep.txt':'saved'})
  result=store.run(run['id']);self.assertEqual(result['status'],'completed');self.assertIsNone(result['end_reason'])
  self.assertEqual(len(model.prompts),2);self.assertEqual((store.workspace(chat['project_id'])/'keep.txt').read_text(),'saved')
 async def test_runner_timeout_can_be_repaired_and_rerun(self):
  runner=PictureRunner(('raise_timeout','passed'));store,chat,run,model=await self.execute([Message(calls=[call('run_tests',{'command':['python','check.py']})]),Message('Repair needed.'),Message(calls=[call('run_tests',{'command':['python','check.py']})]),Message('Rerun returned fixture results.')],runner=runner)
  checks=store.run(run['id'])['checks'];self.assertEqual([c['status'] for c in checks],['failed','passed']);self.assertIn('Sofia verification setup or runner operation timed out',checks[0]['output'])
 async def test_stop_and_deadline_keep_existing_meaning(self):
  with tempfile.TemporaryDirectory() as folder:
   store=Store(folder);chat=store.create_chat();run=store.start_run(chat['id'],'sofia','Wait');model=Model(['wait']);service=AgentService(store,NativeTestRunner(),lambda:model,'fixture');self.assertEqual(service.request_timeout,2700)
   service.start(run);task=service.active[run['id']][1];await asyncio.sleep(.02);service.stop(run['id']);await asyncio.wait_for(task,1);self.assertEqual(store.run(run['id'])['end_reason'],'user_stop');self.assertEqual(store.run(run['id'])['status'],'cancelled')
  store,chat,run,model=await self.execute(['wait'],timeout=.03);self.assertEqual(store.run(run['id'])['end_reason'],'request_deadline')
 async def test_more_than_64_turns_allowed(self):
  script=[Message(calls=[call('read_skill',{'name':'frontend'})]) for _ in range(70)]+[Message('Finished after 70 guide calls.')];store,chat,run,model=await self.execute(script,timeout=5);self.assertEqual(store.run(run['id'])['status'],'completed');self.assertEqual(len(model.prompts),71)

class StarterServiceAndAdapter(unittest.TestCase):
 def test_actual_typescript_mock_service(self):
  import shutil,subprocess
  if not shutil.which('node'):self.skipTest('Node 22+ required for native TypeScript stripping')
  help_text=subprocess.run(['node','--help'],capture_output=True,text=True).stdout
  if '--experimental-strip-types' not in help_text:self.skipTest('Node 22+ required for native TypeScript stripping')
  result=subprocess.run(['node','--experimental-strip-types','tests/check_sofia_mock_service.cjs'],cwd=ROOT,capture_output=True,text=True,timeout=10)
  self.assertEqual(result.returncode,0,result.stdout+result.stderr)
 def test_preview_adapter_serves_assets_spa_and_health_without_fake_business_api(self):
  import importlib.util
  from fastapi.testclient import TestClient
  from rooz.app_profile import profile
  with tempfile.TemporaryDirectory() as folder:
   root=Path(folder)
   for row in sofia.files(root):
    path=root/row['path'];path.parent.mkdir(parents=True,exist_ok=True);path.write_text(row['content'])
   self.assertEqual(profile(root)['frontend_type'],'vite')
   dist=root/'frontend/dist';dist.mkdir();(dist/'index.html').write_text('<h1>Controlled built-page fixture</h1>');(dist/'app.js').write_text('/* controlled asset fixture */')
   spec=importlib.util.spec_from_file_location('sofia_preview_fixture',root/'backend/main.py');module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
   with TestClient(module.app) as client:
    self.assertEqual(client.get('/api/health').json()['mode'],'frontend-mock-preview')
    self.assertEqual(client.get('/clients').status_code,200)
    self.assertEqual(client.get('/app.js').text,'/* controlled asset fixture */')
    for path in ('/api/clients','/.env','/missing.js'):
     self.assertEqual(client.get(path).status_code,404)

class SofiaProviderProtocols(unittest.IsolatedAsyncioTestCase):
 async def test_real_sdk_formats_keep_sofia_tools_and_reasoning_private(self):
  import httpx
  from openai import AsyncOpenAI
  for model in ('gpt-6-luna','deepseek-flash'):
   with self.subTest(model=model),tempfile.TemporaryDirectory() as folder:
    requests=[]
    async def handler(request):
     body=json.loads(request.content);requests.append(body);responses=model=='gpt-6-luna'
     self.assertEqual(body['model'],model)
     tools=body['tools'];names={t['name'] if responses else t['function']['name'] for t in tools}
     self.assertIn('verify_ui',names);self.assertNotIn('verify_app',names)
     if responses:
      self.assertEqual(body['reasoning'],{'effort':'medium'})
      for tool in tools:self.assertTrue(tool['strict'])
      output=[{'type':'reasoning','id':'reason','summary':[],'encrypted_content':'PRIVATE_SOFIA_REASONING'},{'type':'function_call','id':'fn','call_id':'call1','name':'read_skill','arguments':'{"name":"frontend"}','status':'completed'}] if len(requests)==1 else [{'type':'message','id':'msg','role':'assistant','status':'completed','content':[{'type':'output_text','text':'Sofia guidance read.','annotations':[]}]}]
      if len(requests)>1:
       self.assertTrue(any(i.get('encrypted_content')=='PRIVATE_SOFIA_REASONING' for i in body['input']))
       result=next(i for i in body['input'] if i.get('type')=='function_call_output');self.assertEqual(result['call_id'],'call1');self.assertIn('React',result['output'])
      payload={'id':'response','object':'response','created_at':1,'status':'completed','model':model,'output':output}
     else:
      self.assertEqual(body['thinking'],{'type':'enabled'});self.assertEqual(body['max_tokens'],32768)
      message={'role':'assistant','content':None if len(requests)==1 else 'Sofia guidance read.','reasoning_content':'PRIVATE_SOFIA_REASONING'}
      if len(requests)==1:message['tool_calls']=[{'id':'call1','type':'function','function':{'name':'read_skill','arguments':'{"name":"frontend"}'}}]
      else:
       self.assertTrue(any(m.get('reasoning_content')=='PRIVATE_SOFIA_REASONING' for m in body['messages'] if m.get('role')=='assistant'));self.assertIn('React',body['messages'][-1]['content'])
      payload={'id':'chat','object':'chat.completion','created':1,'model':model,'choices':[{'index':0,'finish_reason':'tool_calls' if len(requests)==1 else 'stop','message':message}]}
     return httpx.Response(200,json=payload)
    client=AsyncOpenAI(api_key='fixture-not-live',max_retries=0,http_client=httpx.AsyncClient(transport=httpx.MockTransport(handler)))
    store=Store(folder);chat=store.create_chat();run=store.start_run(chat['id'],'sofia','Read frontend guide',model=model)
    await AgentService(store,NativeTestRunner(),lambda:client,model).execute(run,asyncio.Event())
    self.assertEqual(store.run(run['id'])['status'],'completed',store.messages(chat['id'])[-1]['content']);self.assertEqual(len(requests),2)
    self.assertNotIn('PRIVATE_SOFIA_REASONING',json.dumps(store.messages(chat['id'])))
 async def test_transient_sdk_timeout_retries_same_model_without_replaying_tools(self):
  import httpx
  from openai import AsyncOpenAI
  requests=[]
  async def handler(request):
   requests.append(json.loads(request.content))
   if len(requests)==1:raise httpx.ReadTimeout('Controlled SDK timeout')
   return httpx.Response(200,json={'id':'recovered','object':'chat.completion','created':1,'model':'deepseek-flash','choices':[{'index':0,'finish_reason':'stop','message':{'role':'assistant','content':'Recovered.','reasoning_content':''}}]})
  with tempfile.TemporaryDirectory() as folder:
   client=AsyncOpenAI(api_key='fixture-not-live',max_retries=0,http_client=httpx.AsyncClient(transport=httpx.MockTransport(handler)))
   store=Store(folder);chat=store.create_chat();run=store.start_run(chat['id'],'sofia','Read guide',model='deepseek-flash')
   service=AgentService(store,NativeTestRunner(),lambda:client,'deepseek-flash');service.request_timeout=3
   await service.execute(run,asyncio.Event())
   self.assertEqual(store.run(run['id'])['status'],'completed');self.assertEqual(len(requests),2)
   self.assertEqual([r['model'] for r in requests],['deepseek-flash']*2)
   self.assertEqual(store.run(run['id'])['checks'],[])
 async def test_eli_parent_keeps_original_tools_when_calling_sofia(self):
  with tempfile.TemporaryDirectory() as folder:
   store=Store(folder);chat=store.create_chat();run=store.start_run(chat['id'],'eli','Ask Sofia for a UI opinion')
   model=Model([Message(calls=[call('call_agent',{'agent':'Sofia','message':'Review the UI direction','reason':'User requested frontend review'})]),Message('Sofia UI opinion.'),Message('Eli incorporated the review.')])
   await AgentService(store,NativeTestRunner(),lambda:model,'fixture').execute(run,asyncio.Event())
   parent={t['function']['name'] for t in model.prompts[0]['tools']};child={t['function']['name'] for t in model.prompts[1]['tools']}
   self.assertIn('verify_app',parent);self.assertNotIn('verify_ui',parent);self.assertIn('verify_ui',child);self.assertNotIn('verify_app',child)
   self.assertEqual(store.run(run['id'])['status'],'completed');self.assertEqual(store.run(run['id'])['agent'],'eli')

class SofiaScopeAndRetry(unittest.IsolatedAsyncioTestCase):
 async def test_document_only_change_does_not_force_frontend_reverification(self):
  with tempfile.TemporaryDirectory() as folder:
   store=Store(folder);chat=store.create_chat();root=store.workspace(chat['project_id']);(root/'index.html').write_text('<h1>Existing UI</h1>')
   run=store.start_run(chat['id'],'sofia','Document the UI');runner=PictureRunner()
   model=Model([Message(calls=[call('write_files',{'files':[{'path':'README.md','content':'UI documentation only.'}]})]),Message('Documentation saved.')])
   await AgentService(store,runner,lambda:model,'fixture').execute(run,asyncio.Event())
   self.assertEqual(store.run(run['id'])['status'],'completed');self.assertEqual(runner.commands,[])
 async def test_stop_and_deadline_interrupt_timeout_retry_backoff(self):
  class TimeoutModel(Model):
   async def create(self,**kwargs):self.prompts.append(kwargs);raise TimeoutError()
  for stop_requested in (True,False):
   with self.subTest(stop=stop_requested),tempfile.TemporaryDirectory() as folder:
    store=Store(folder);chat=store.create_chat();run=store.start_run(chat['id'],'sofia','Continue saved work');model=TimeoutModel();service=AgentService(store,PictureRunner(),lambda:model,'fixture')
    if not stop_requested:service.request_timeout=.05
    service.start(run);task=service.active[run['id']][1];await asyncio.sleep(.02)
    self.assertIn('retrying the same model',store.run(run['id'])['stage'])
    if stop_requested:service.stop(run['id'])
    await asyncio.wait_for(task,1)
    self.assertEqual(store.run(run['id'])['end_reason'],'user_stop' if stop_requested else 'request_deadline');self.assertTrue(model.closed)
