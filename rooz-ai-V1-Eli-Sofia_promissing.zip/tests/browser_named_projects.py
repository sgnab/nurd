"""Real browser/HTTP/storage naming checks. No live model or Docker claim."""
import json,os,socket,subprocess,sys,tempfile,time,urllib.request
from pathlib import Path
from playwright.sync_api import sync_playwright,expect
from tests.browser_projects_support import create_project

root=Path(__file__).parents[1]
evidence=Path(os.getenv('ROOZ_TEST_OUTPUT') or tempfile.mkdtemp(prefix='rooz-project-names-'));evidence.mkdir(parents=True,exist_ok=True)
with socket.socket() as sock:sock.bind(('127.0.0.1',0));port=sock.getsockname()[1]
with tempfile.TemporaryDirectory() as directory:
    env={**os.environ,'ROOZ_FIXTURE_DATA':directory,'ROOZ_FIXTURE_PORT':str(port)}
    with (evidence/'server.log').open('w') as log:
        server=subprocess.Popen([sys.executable,str(root/'tests/fixture_server.py')],env=env,stdout=log,stderr=subprocess.STDOUT)
        try:
            base='http://127.0.0.1:'+str(port)
            for _ in range(100):
                try:urllib.request.urlopen(base+'/api/chats',timeout=1);break
                except OSError:time.sleep(.1)
            else:raise RuntimeError('Fixture did not start')
            with sync_playwright() as playwright:
                browser=playwright.chromium.launch(executable_path=os.getenv('ROOZ_BROWSER_EXECUTABLE') or None,args=['--no-sandbox','--disable-dev-shm-usage'])
                try:
                    page=browser.new_page(viewport={'width':1440,'height':1000},accept_downloads=True)
                    errors=[];page.on('pageerror',lambda error:errors.append(str(error)));page.goto(base)
                    expect(page.get_by_role('dialog',name='New project')).to_be_visible()
                    assert page.request.get(base+'/api/chats').json()['chats']==[]
                    page.get_by_role('button',name='Cancel',exact=True).click()
                    assert page.request.get(base+'/api/chats').json()['chats']==[]
                    expect(page.get_by_role('button',name='Send message',exact=True)).to_be_disabled()
                    page.get_by_role('button',name='New project',exact=True).click()
                    page.get_by_label('Project name',exact=True).fill('   ')
                    page.get_by_role('button',name='Create project',exact=True).click()
                    expect(page.locator('#projectNameError')).to_have_text('Enter a project name.')
                    create_project(page,'Notes workspace')
                    rows=page.request.get(base+'/api/chats').json()['chats'];first=rows[0]
                    assert first['title']==first['project_title']=='Notes workspace'
                    expect(page.locator('#chatTitle')).to_contain_text('Notes workspace')
                    page.locator('#agentSelect').select_option('sofia')
                    page.locator('#prompt').fill('write tested code');page.locator('#send').click()
                    expect(page.get_by_text('A small, tested implementation',exact=True)).to_be_visible(timeout=15000)
                    page.locator('#chatTitle').click()
                    expect(page.get_by_role('dialog',name='Rename project')).to_be_visible()
                    page.get_by_label('Project name',exact=True).fill('Notes dashboard')
                    page.get_by_role('button',name='Save name',exact=True).click()
                    expect(page.locator('#projectDialog')).not_to_be_visible()
                    expect(page.locator('#chatTitle')).to_contain_text('Notes dashboard')
                    rows=page.request.get(base+'/api/chats').json()['chats']
                    assert rows[0]['id']==first['id'] and rows[0]['project_id']==first['project_id']
                    assert rows[0]['title']==rows[0]['project_title']=='Notes dashboard'
                    page.locator('#filesButton').click()
                    with page.expect_download() as downloaded:
                        page.get_by_role('link',name='Download project ZIP',exact=True).click()
                    assert downloaded.value.suggested_filename=='Notes dashboard.zip'
                    page.locator('#closeDrawer').click()
                    create_project(page,'Second project')
                    assert page.request.get(base+'/api/chats').json()['chats'][0]['project_id']!=first['project_id']
                    page.get_by_role('button',name='Notes dashboard',exact=True).click()
                    expect(page.get_by_text('A small, tested implementation',exact=True)).to_be_visible()
                    page.reload();expect(page.locator('#chatTitle')).to_contain_text('Notes dashboard')
                    page.set_viewport_size({'width':390,'height':844})
                    page.get_by_label('Open navigation').click()
                    page.get_by_role('button',name='New project',exact=True).click()
                    expect(page.get_by_role('dialog',name='New project')).to_be_visible()
                    assert page.locator('#projectDialog').evaluate('node=>node.scrollWidth<=node.clientWidth')
                    page.screenshot(path=str(evidence/'mobile.png'),full_page=True)
                    page.get_by_role('button',name='Cancel',exact=True).click()
                    assert len(page.request.get(base+'/api/chats').json()['chats'])==2
                    assert not errors,errors
                finally:browser.close()
            checks=['initial name request','cancel creates nothing','blank-name rejection','matching project/chat names','rename keeps IDs/files/history','named ZIP download','project isolation','reload persistence','mobile naming dialog']
            (evidence/'results.json').write_text(json.dumps({'checks':checks,'real_browser':True,'real_http':True,'docker':False,'live_model':False},indent=2))
            print('PASS: '+', '.join(checks))
        finally:server.terminate();server.wait(timeout=20)
