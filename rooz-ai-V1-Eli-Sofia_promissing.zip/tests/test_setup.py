"""Setup control-flow tests with explicit Python/Docker adapters, no real image builds."""
import os
import shutil
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

class SetupTests(unittest.TestCase):
    def execute_setup(self, overrides=None):
        self.temp=tempfile.TemporaryDirectory();self.addCleanup(self.temp.cleanup)
        self.root=Path(self.temp.name)
        shutil.copy2(Path(__file__).parents[1]/'setup.sh',self.root/'setup.sh')
        (self.root/'requirements.txt').write_text('')
        (self.root/'.venv/bin').mkdir(parents=True)
        python=self.root/'.venv/bin/python'
        python.write_text('''#!/bin/sh
if [ "$1" = "-m" ] && [ "$2" = "pip" ]; then
  echo pip >> "$SETUP_LOG"; exit 0
fi
if [ "$1" = "tests/check_stage18_docker.py" ]; then
  echo verify >> "$SETUP_LOG"; exit "${VERIFY_EXIT:-0}"
fi
if [ "$1" = "tests/check_stage19_docker.py" ]; then
  echo verify-preview >> "$SETUP_LOG"; exit "${PREVIEW_VERIFY_EXIT:-0}"
fi
if [ "$1" = "tests/check_browser_runner_docker.py" ]; then
  echo verify-node >> "$SETUP_LOG"; exit "${NODE_VERIFY_EXIT:-0}"
fi
exec "$REAL_PYTHON" "$@"
''');python.chmod(0o755)
        (self.root/'bin').mkdir()
        docker=self.root/'bin/docker'
        docker.write_text('''#!/bin/sh
echo "docker $*" >> "$SETUP_LOG"
if [ "$1" = "info" ]; then exit "${INFO_EXIT:-0}"; fi
if [ "$1" = "build" ]; then exit "${BUILD_EXIT:-0}"; fi
exit 1
''');docker.chmod(0o755)
        (self.root/'.env').write_text('KEEP_EXISTING_CONFIGURATION=1\n')
        env={**os.environ,'REAL_PYTHON':sys.executable,'SETUP_LOG':str(self.root/'actions'),
             'PATH':str(self.root/'bin')+os.pathsep+os.environ['PATH']}
        env.pop('ROOZ_PYTHON',None)
        env.update(overrides or {})
        result=subprocess.run(['bash','setup.sh'],cwd=self.root,env=env,capture_output=True,text=True,timeout=30)
        actions=(self.root/'actions').read_text().splitlines() if (self.root/'actions').exists() else []
        return result,actions

    def test_setup_builds_then_verifies_and_preserves_env(self):
        result,actions=self.execute_setup()
        self.assertEqual(result.returncode,0,result.stdout+result.stderr)
        self.assertEqual(actions,['docker info','pip','docker build -t rooz-ai-runner:stage1 -f sandbox/Dockerfile .','verify','verify-preview','verify-node'])
        self.assertIn('Setup and runner verification passed',result.stdout)
        self.assertEqual((self.root/'.env').read_text(),'KEEP_EXISTING_CONFIGURATION=1\n')

    def test_failed_build_does_not_claim_success_or_verify(self):
        result,actions=self.execute_setup({'BUILD_EXIT':'7'})
        self.assertEqual(result.returncode,7)
        self.assertNotIn('verify',actions)
        self.assertNotIn('verification passed',result.stdout)

    def test_failed_runner_verification_keeps_setup_failed(self):
        result,actions=self.execute_setup({'VERIFY_EXIT':'1'})
        self.assertEqual(result.returncode,1)
        self.assertEqual(actions[-1],'verify')
        self.assertNotIn('verification passed',result.stdout)

    def test_unavailable_docker_stops_before_dependency_install(self):
        result,actions=self.execute_setup({'INFO_EXIT':'1'})
        self.assertEqual(result.returncode,1)
        self.assertEqual(actions,['docker info'])
        self.assertIn('Docker is not ready',result.stderr)

    def test_fullstack_preview_verification_failure_keeps_setup_failed(self):
        result,actions=self.execute_setup({'PREVIEW_VERIFY_EXIT':'1'})
        self.assertEqual(result.returncode,1)
        self.assertEqual(actions[-1],'verify-preview')
        self.assertNotIn('verification passed',result.stdout)

    def test_node_browser_verification_failure_keeps_setup_failed(self):
        result,actions=self.execute_setup({'NODE_VERIFY_EXIT':'1'})
        self.assertEqual(result.returncode,1)
        self.assertEqual(actions[-1],'verify-node')
        self.assertNotIn('verification passed',result.stdout)
