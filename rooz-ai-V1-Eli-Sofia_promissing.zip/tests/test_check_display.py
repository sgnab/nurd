import shutil
import subprocess
import unittest
from pathlib import Path

class CheckDisplay(unittest.TestCase):
    @unittest.skipUnless(shutil.which('node'),'Node is required for the check-card renderer regression')
    def test_real_renderer_groups_corrected_checks_and_preserves_history(self):
        result=subprocess.run(['node','tests/check_display.cjs'],cwd=Path(__file__).parents[1],capture_output=True,text=True,timeout=15)
        self.assertEqual(result.returncode,0,result.stdout+result.stderr)
