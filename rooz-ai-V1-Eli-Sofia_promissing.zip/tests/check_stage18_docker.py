"""Manual local acceptance: actual production DockerRunner, no OpenAI key."""
import asyncio
import json
import sys
import tempfile
from pathlib import Path

sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from rooz.runner import DockerRunner
from rooz.scaffold import files

async def main():
    with tempfile.TemporaryDirectory(prefix='rooz-stage18-') as directory:
        workspace=Path(directory)
        for item in files(workspace):
            target=workspace/item['path'];target.parent.mkdir(parents=True,exist_ok=True)
            target.write_text(item['content'])
        result=await DockerRunner(timeout=180).run(workspace,['python','tests/verify.py'],asyncio.Event())
        print(json.dumps(result,indent=2))
        return 0 if result['status']=='passed' else 1

if __name__=='__main__':
    raise SystemExit(asyncio.run(main()))
