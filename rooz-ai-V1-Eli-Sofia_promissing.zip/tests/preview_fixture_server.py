"""Browser fixture. Fixed server runs natively only on controlled static assets."""
import os
from pathlib import Path
from types import SimpleNamespace
from fastapi import Request
from rooz.api import create_app
from tests.support import Model,Message,call,NativeTestRunner
from tests.preview_support import NativePreview

HTML='<!doctype html><html><head><meta name="viewport" content="width=device-width,initial-scale=1"><link rel="stylesheet" href="style.css"></head><body><h1>Counter</h1><button id="add">Increase</button><button id="reset">Reset</button><output id="count">0</output><p id="fixtureData"></p><script type="module" src="app.js"></script></body></html>'
JS='import {step} from "./math.js";let n=0;const show=()=>document.querySelector("#count").textContent=n;document.querySelector("#add").onclick=()=>{n+=step;show()};document.querySelector("#reset").onclick=()=>{n=0;show()};fetch("data.json").then(r=>r.json()).then(d=>document.querySelector("#fixtureData").textContent=d.message);'
FILES=[{'path':'index.html','content':HTML},{'path':'app.js','content':JS},{'path':'math.js','content':'export const step=1;'},{'path':'data.json','content':'{"message":"Static JSON loaded"}'},{'path':'style.css','content':'body{font-family:system-ui;padding:24px;color:rgb(20,60,30)}button{padding:12px;margin:8px}output{display:block;font-size:32px}'}]

class PreviewModel(Model):
 async def create(self,**kwargs):
  tools=[m for m in kwargs['messages'] if m['role']=='tool']
  value=Message('Counter saved. Open Live Preview to try it.') if tools else Message(calls=[call('write_files',{'files':FILES})])
  return SimpleNamespace(choices=[SimpleNamespace(message=value)])

backend=NativePreview()
app=create_app(os.environ['ROOZ_FIXTURE_DATA'],Path(__file__).parents[1]/'static',lambda:PreviewModel(),'scripted-test-model',NativeTestRunner(),backend)
@app.post('/fixture/update/{chat}')
async def update(chat:str):
 store=app.state.store;root=store.workspace(store.chat(chat)['project_id']);(root/'index.html').write_text(HTML.replace('Counter','Updated counter'));return {'ok':True}
@app.post('/fixture/ready/{ready}')
async def ready(ready:str):backend.ready=ready=='yes';return {'ok':True}
@app.post('/fixture/react/{chat}')
async def react(chat:str):
 store=app.state.store;(store.workspace(store.chat(chat)['project_id'])/'react.html').write_text('<script type="module" src="/src/main.jsx"></script>');return {'ok':True}
if __name__=='__main__':
 import uvicorn
 uvicorn.run(app,host='127.0.0.1',port=int(os.environ['ROOZ_FIXTURE_PORT']),log_level='warning')
