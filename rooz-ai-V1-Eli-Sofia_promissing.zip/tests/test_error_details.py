import os,unittest,httpx
from unittest.mock import patch
from openai import BadRequestError,AuthenticationError
from rooz.agents import request_error
class ErrorDetailsTests(unittest.TestCase):
 def make(self,body,status=400,kind=BadRequestError):
  return kind('Provider request rejected',response=httpx.Response(status,request=httpx.Request('POST','https://api.openai.com/v1/chat/completions')),body=body)
 def test_actual_provider_reason_code_and_parameter_are_visible(self):
  text=request_error(self.make({'message':'Unsupported parameter: max_completion_tokens','code':'unsupported_parameter','param':'max_completion_tokens'}),'configured-model')
  for value in ('HTTP 400','Unsupported parameter','max_completion_tokens','configured-model','unsupported_parameter'):self.assertIn(value,text)
 def test_nested_error_and_saved_key_are_redacted(self):
  key='example-key-value-that-must-stay-private'
  with patch.dict(os.environ,{'OPENAI_API_KEY':key}):
   text=request_error(self.make({'error':{'message':'Rejected '+key+' Bearer abcdefghijklmnop sk-proj-abcdefghijklmnop','code':'invalid'}}),'test')
  for value in (key,'abcdefghijklmnop','sk-proj-'):self.assertNotIn(value,text)
  self.assertIn('[REDACTED]',text)
 def test_headers_and_nonallowlisted_fields_are_not_exposed(self):
  text=request_error(self.make({'message':'Invalid model','raw_payload':'private-document','headers':{'Authorization':'very-private'}}),'test')
  self.assertNotIn('private-document',text);self.assertNotIn('very-private',text)
 def test_authentication_failure_is_distinguished_from_bad_request(self):
  text=request_error(self.make({'message':'Invalid API key'},401,AuthenticationError),'test')
  self.assertIn('HTTP 401',text);self.assertIn('OPENAI_API_KEY',text)

class ErrorPersistenceTests(unittest.IsolatedAsyncioTestCase):
 async def test_failed_request_persists_actionable_error_in_chat(self):
  import asyncio,tempfile
  from rooz.storage import Store
  from rooz.agents import AgentService
  from tests.support import Model,NativeTestRunner
  exc=BadRequestError('Rejected',response=httpx.Response(400,request=httpx.Request('POST','https://api.openai.com/v1/chat/completions')),body={'message':'This model does not support this endpoint','param':'model'})
  with tempfile.TemporaryDirectory() as d:
   store=Store(d);chat=store.create_chat();run=store.start_run(chat['id'],'alex','Hello')
   service=AgentService(store,NativeTestRunner(),lambda:Model([exc]),'selected-model')
   await service.execute(run,asyncio.Event())
   self.assertEqual(store.run(run['id'])['status'],'failed')
   content=store.messages(chat['id'])[-1]['content']
   self.assertIn('does not support this endpoint',content);self.assertIn('selected-model',content);self.assertIn('HTTP 400',content)
