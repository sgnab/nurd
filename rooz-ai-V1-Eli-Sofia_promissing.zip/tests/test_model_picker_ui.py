import shutil,subprocess,unittest
from pathlib import Path
from html.parser import HTMLParser

class PickerUI(unittest.TestCase):
    @unittest.skipUnless(shutil.which('node'),'Node required for production UI-function regression')
    def test_picker_send_and_run_lock(self):
        result=subprocess.run(['node','tests/check_model_picker.cjs'],cwd=Path(__file__).parents[1],capture_output=True,text=True,timeout=15)
        self.assertEqual(result.returncode,0,result.stdout+result.stderr)
    def test_selector_has_accessible_label_and_unique_id(self):
        class Parser(HTMLParser):
            def __init__(self):super().__init__();self.selects=[];self.labels=[]
            def handle_starttag(self,tag,attrs):
                attrs=dict(attrs)
                if tag=='select':self.selects.append(attrs)
                if tag=='label':self.labels.append(attrs)
        parser=Parser();parser.feed((Path(__file__).parents[1]/'static/index.html').read_text())
        self.assertEqual(len([s for s in parser.selects if s.get('id')=='modelSelect']),1)
        self.assertTrue(any(label.get('for')=='modelSelect' for label in parser.labels))
