"""Deterministic browser-test server. No real model or provider usage."""
import asyncio,os
from pathlib import Path
from types import SimpleNamespace
from rooz.api import create_app
from tests.support import Model,Message,call,NativeTestRunner

CODE='def total(values):\n    return sum(values)\n'
TEST='import unittest\nfrom total import total\nclass TotalTests(unittest.TestCase):\n def test_total(self): self.assertEqual(total([2,3]),5)\n'
class BrowserModel(Model):
 async def create(self,**kwargs):
  user=next(m['content'] for m in reversed(kwargs['messages']) if m['role']=='user')
  if 'wait for stop' in user.lower():await asyncio.sleep(1000)
  tool_rows=[m for m in kwargs['messages'] if m['role']=='tool']
  if 'mixed checks' in user.lower():
   if not tool_rows:value=Message(calls=[call('run_tests',{'command':['python','-c','raise AssertionError("expected failed check")']})])
   elif len(tool_rows)==1:value=Message(calls=[call('run_tests',{'command':['python','-c','print("a different check passed")']})])
   else:value=Message('Mixed checks recorded.')
   return SimpleNamespace(choices=[SimpleNamespace(message=value)])
  if 'write tested code' in user.lower():
   if not tool_rows:value=Message(calls=[call('write_files',{'files':[{'path':'total.py','content':CODE},{'path':'test_total.py','content':TEST}]})])
   elif len(tool_rows)==1:value=Message(calls=[call('run_tests',{'command':['python','-m','unittest','discover','-v']})])
   else:value=Message('## A small, tested implementation\n\nSaved both files and ran the test.\n\n```python\n'+CODE+'```\n\n<script>window.ROOZ_XSS=true</script>')
   return SimpleNamespace(choices=[SimpleNamespace(message=value)])
  return await super().create(**kwargs)

app=create_app(os.environ['ROOZ_FIXTURE_DATA'],Path(__file__).parents[1]/'static',lambda:BrowserModel(),'scripted-test-model',NativeTestRunner())
if __name__=='__main__':
 import uvicorn
 uvicorn.run(app,host='127.0.0.1',port=int(os.environ['ROOZ_FIXTURE_PORT']),log_level='warning')
