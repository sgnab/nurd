"""Controlled fixture app and native runtime adapter; never a production fallback."""
import asyncio
import json
import socket
import sys
from pathlib import Path
from tests.preview_support import NativePreview

BACKEND = '''import os, sqlite3
from pathlib import Path
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
app=FastAPI()
path=Path(os.environ['DATABASE_PATH'])
def db():
 c=sqlite3.connect(path)
 c.execute('CREATE TABLE IF NOT EXISTS notes(id INTEGER PRIMARY KEY, title TEXT NOT NULL)')
 return c
class Note(BaseModel): title: str
def title(note):
 value=note.title.strip()
 if not value: raise HTTPException(422,'Title cannot be blank')
 return value
@app.get('/api/notes')
def listing():
 with db() as c: return [{'id':r[0],'title':r[1]} for r in c.execute('SELECT id,title FROM notes ORDER BY id')]
@app.post('/api/notes',status_code=201)
def add(note:Note):
 value=title(note)
 with db() as c:
  cur=c.execute('INSERT INTO notes(title) VALUES(?)',(value,))
  return {'id':cur.lastrowid,'title':value}
@app.put('/api/notes/{id}')
def edit(id:int,note:Note):
 value=title(note)
 with db() as c:
  if not c.execute('UPDATE notes SET title=? WHERE id=?',(value,id)).rowcount: raise HTTPException(404,'Note not found')
 return {'id':id,'title':value}
@app.delete('/api/notes/{id}',status_code=204)
def remove(id:int):
 with db() as c:
  if not c.execute('DELETE FROM notes WHERE id=?',(id,)).rowcount: raise HTTPException(404,'Note not found')
'''

HTML = '''<!doctype html><html><body><h1>Notes preview</h1>
<form id="form"><label>Title<input id="title"/></label><button>Add note</button></form>
<p role="alert" id="error"></p><ul id="notes"></ul>
<script>
let editing=null;
async function load(){const rows=await (await fetch('/api/notes')).json();notes.replaceChildren();
for(const row of rows){const li=document.createElement('li');li.dataset.id=row.id;
const text=document.createElement('span');text.textContent=row.title;li.append(text);
for(const action of ['Edit','Delete']){const b=document.createElement('button');b.textContent=action;
b.onclick=async()=>{if(action==='Edit'){editing=row.id;title.value=row.title;form.querySelector('button').textContent='Save note';}
else{await fetch('/api/notes/'+row.id,{method:'DELETE'});await load();}};li.append(b);}notes.append(li);}}
form.onsubmit=async(e)=>{e.preventDefault();const r=await fetch('/api/notes'+(editing?'/'+editing:''),
{method:editing?'PUT':'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({title:title.value})});
error.textContent=r.ok?'':(await r.json()).detail;
if(r.ok){editing=null;title.value='';form.querySelector('button').textContent='Add note';await load();}};
load();</script></body></html>'''


def write_app(root):
    (root/'backend').mkdir(parents=True,exist_ok=True)
    (root/'frontend').mkdir(parents=True,exist_ok=True)
    (root/'backend/main.py').write_text(BACKEND)
    (root/'frontend/package.json').write_text(json.dumps({'scripts':{'build':'node build.cjs'}}))
    (root/'frontend/build.cjs').write_text("const fs=require('fs');fs.mkdirSync('dist',{recursive:true});fs.copyFileSync('index.html','dist/index.html');")
    (root/'frontend/index.html').write_text(HTML)


class NativeFullstackPreview(NativePreview):
    def __init__(self,runtime=None):
        super().__init__();self.runtime=runtime
    async def launch_fullstack(self,name,snapshot,settings,data,session,owner,port=None,stop=None):
        if port is None:
            with socket.socket() as sock:
                sock.bind(('127.0.0.1',0));port=sock.getsockname()[1]
        runtime=self.runtime or Path(self.temp.name)/'runtime';runtime.mkdir(exist_ok=True)
        if self.runtime is None:
            (runtime/'package.json').write_text('{}');(runtime/'node_modules').mkdir(exist_ok=True)
        logfile=Path(self.temp.name)/name;output=logfile.open('wb')
        script=Path(__file__).parents[1]/'rooz/fullstack_server.py'
        process=await asyncio.create_subprocess_exec(sys.executable,'-u',str(script),'--source',str(snapshot),
            '--work',str(Path(self.temp.name)/('work-'+session)),'--data',str(data),'--session',session,
            '--profile',json.dumps(settings),'--port',str(port),'--host','127.0.0.1','--runtime',str(runtime),
            stdout=output,stderr=asyncio.subprocess.STDOUT)
        self.processes[name]=(process,logfile,output);self.launches.append((name,snapshot,'@fullstack',session))
        return 'http://127.0.0.1:'+str(port)+'/'
