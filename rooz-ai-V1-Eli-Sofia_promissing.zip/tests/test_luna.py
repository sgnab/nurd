"""GPT-6 Luna routing with real SDK serialization and controlled local execution."""
import asyncio,base64,io,json,tempfile,unittest
from pathlib import Path
import httpx
from openai import AsyncOpenAI
from PIL import Image
from rooz.agents import AgentService
from rooz.storage import Store
from tests.support import NativeTestRunner


class LunaTests(unittest.IsolatedAsyncioTestCase):
    def test_startup_defaults_to_luna_and_preserves_explicit_model_precedence(self):
        import os,runpy
        from unittest.mock import patch
        app_path=Path(__file__).parents[1]/'app.py'
        for environment,expected in [({},'gpt-6-luna'),({'OPENAI_MODEL':'gpt-4.1-mini'},'gpt-4.1-mini'),
                                     ({'OPENAI_MODEL':'gpt-4.1-mini','CODING_MODEL':'gpt-6-luna'},'gpt-6-luna')]:
            with self.subTest(environment=environment),patch.dict(os.environ,environment,clear=True),\
                 patch('dotenv.load_dotenv'),patch('rooz.api.create_app') as factory:
                runpy.run_path(str(app_path))
                self.assertEqual(factory.call_args.args[3],expected)

    async def test_luna_tools_repair_and_screenshots_use_responses_with_preserved_state(self):
        requests=[]
        check='''import os
from pathlib import Path
from PIL import Image
from calc import add
Image.new('RGB',(40,30),(42,91,130)).save(Path(os.environ['ROOZ_SCREENSHOT_DIR'])/'desktop.png')
assert add(2,3)==5
print('Functional check passed')
'''
        actions=[('write_files',{'files':[{'path':'calc.py','content':'def add(a,b): return a-b\n'},
                                       {'path':'check.py','content':check}]}),
                 ('run_tests',{'command':['python','check.py']}),'Confirm to repair.',
                 ('read_files',{'paths':['calc.py']}),
                 ('write_files',{'files':[{'path':'calc.py','content':'def add(a,b): return a+b\n'}]}),
                 ('run_tests',{'command':['python','check.py']}),'Saved and verified with Luna.']
        async def handler(request):
            self.assertEqual(request.url.path,'/v1/responses')
            body=json.loads(request.content);requests.append(body);index=len(requests)-1
            self.assertEqual(body['model'],'gpt-6-luna')
            self.assertEqual(body['reasoning'],{'effort':'medium'})
            self.assertEqual(body['max_output_tokens'],32768)
            self.assertFalse(body['store']);self.assertIn('reasoning.encrypted_content',body['include'])
            if index>=2:
                images=[p for m in body['input'] if isinstance(m.get('content'),list) for p in m['content'] if p.get('type')=='input_image']
                self.assertEqual(len(images),1)
                image=Image.open(io.BytesIO(base64.b64decode(images[0]['image_url'].split(',',1)[1])))
                self.assertEqual(image.size,(40,30))
                self.assertTrue(any(i.get('encrypted_content')=='luna-reasoning-fixture' for i in body['input']))
            action=actions[index]
            if isinstance(action,tuple):
                name,args=action
                output=[{'type':'function_call','id':'f'+str(index),'call_id':'c'+str(index),
                         'name':name,'arguments':json.dumps(args),'status':'completed'}]
                if index==0:output.insert(0,{'type':'reasoning','id':'reason1','summary':[],'encrypted_content':'luna-reasoning-fixture'})
            else:output=[{'type':'message','id':'m'+str(index),'role':'assistant','status':'completed',
                          'content':[{'type':'output_text','text':action,'annotations':[]}]}]
            return httpx.Response(200,json={'id':'r'+str(index),'object':'response','created_at':1,
                                           'status':'completed','model':'gpt-6-luna','output':output})
        with tempfile.TemporaryDirectory() as directory:
            store=Store(directory);chat=store.create_chat();run=store.start_run(chat['id'],'eli','Implement and test addition')
            client=AsyncOpenAI(api_key='fixture-not-real',max_retries=0,http_client=httpx.AsyncClient(transport=httpx.MockTransport(handler)))
            await AgentService(store,NativeTestRunner(),lambda:client,'gpt-6-luna').execute(run,asyncio.Event())
            result=store.run(run['id'])
            self.assertEqual(result['status'],'completed',store.messages(chat['id'])[-1]['content'])
            self.assertEqual([c['status'] for c in result['checks']],['failed','passed'])
            self.assertEqual(store.messages(chat['id'])[-1]['content'],'Saved and verified with Luna.')
            self.assertEqual(len(requests),7)
            results={i['call_id']:json.loads(i['output']) for i in requests[-1]['input'] if i.get('type')=='function_call_output'}
            self.assertEqual(results['c1']['status'],'failed');self.assertEqual(results['c5']['status'],'passed')

    async def test_luna_corrected_check_tool_uses_real_responses_serialization(self):
        requests=[]
        original=['python','-c','assert False, "missing build setup"']
        corrected=['python','-c','value="requested UI"; assert value=="requested UI"']
        async def handler(request):
            body=json.loads(request.content);requests.append(body);index=len(requests)-1
            self.assertTrue(any(t.get('name')=='rerun_check' and t.get('strict') for t in body['tools']))
            if index==0:name,args='run_tests',{'command':original}
            elif index==1:
                failed=json.loads(next(i['output'] for i in body['input'] if i.get('type')=='function_call_output'))
                name,args='rerun_check',{'check_id':failed['check_id'],'command':corrected,
                    'reason':'Correct missing setup while retaining the requested UI assertion'}
            else:name=None
            if name:
                output=[{'type':'function_call','id':'f'+str(index),'call_id':'c'+str(index),
                         'name':name,'arguments':json.dumps(args),'status':'completed'}]
            else:
                output=[{'type':'message','id':'final','role':'assistant','status':'completed',
                         'content':[{'type':'output_text','text':'Corrected check verified.','annotations':[]}]}]
            return httpx.Response(200,json={'id':'r'+str(index),'object':'response','created_at':1,
                                           'status':'completed','model':'gpt-6-luna','output':output})
        with tempfile.TemporaryDirectory() as directory:
            store=Store(directory);chat=store.create_chat();run=store.start_run(chat['id'],'eli','Verify the requested UI')
            client=AsyncOpenAI(api_key='fixture-not-real',max_retries=0,http_client=httpx.AsyncClient(transport=httpx.MockTransport(handler)))
            await AgentService(store,NativeTestRunner(),lambda:client,'gpt-6-luna').execute(run,asyncio.Event())
            result=store.run(run['id']);self.assertEqual(result['status'],'completed')
            first,second=result['checks'];self.assertEqual([first['status'],second['status']],['failed','passed'])
            self.assertEqual(first['check_id'],second['check_id'])
            self.assertEqual(first['superseded_by'],second['execution_id'])
            self.assertEqual(len(requests),3)

    async def test_luna_access_error_is_visible_without_silent_model_substitution(self):
        requested=[]
        async def handler(request):
            requested.append(json.loads(request.content)['model'])
            return httpx.Response(404,json={'error':{'message':'Model gpt-6-luna is unavailable to this fixture account.',
                                                   'type':'invalid_request_error','code':'model_not_found'}})
        with tempfile.TemporaryDirectory() as directory:
            store=Store(directory);chat=store.create_chat();run=store.start_run(chat['id'],'eli','Say hello')
            client=AsyncOpenAI(api_key='fixture-not-real',max_retries=0,http_client=httpx.AsyncClient(transport=httpx.MockTransport(handler)))
            await AgentService(store,NativeTestRunner(),lambda:client,'gpt-6-luna').execute(run,asyncio.Event())
            self.assertEqual(store.run(run['id'])['status'],'failed')
            self.assertEqual(requested,['gpt-6-luna'])
            self.assertIn('model_not_found',store.messages(chat['id'])[-1]['content'])

    async def test_luna_stop_cancels_pending_response(self):
        from types import SimpleNamespace
        from unittest.mock import AsyncMock
        async def create(**kwargs):await asyncio.sleep(1000)
        with tempfile.TemporaryDirectory() as directory:
            store=Store(directory);chat=store.create_chat();run=store.start_run(chat['id'],'eli','Wait')
            client=SimpleNamespace(responses=SimpleNamespace(create=create),close=AsyncMock())
            service=AgentService(store,NativeTestRunner(),lambda:client,'gpt-6-luna');service.start(run)
            await asyncio.sleep(.02);task=service.active[run['id']][1];service.stop(run['id'])
            await asyncio.wait_for(task,2)
            self.assertEqual(store.run(run['id'])['status'],'cancelled')
