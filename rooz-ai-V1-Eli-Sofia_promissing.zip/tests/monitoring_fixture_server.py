"""Browser-only fixture: real host HTTP/SQLite, no provider calls or command execution."""
import os
from pathlib import Path
from rooz.api import create_app
from rooz.security import NoExecutionRunner
from tests.support import Model
app=create_app(os.environ['ROOZ_FIXTURE_DATA'],Path(__file__).parents[1]/'static',
               lambda:Model(['wait']),'scripted-test-model',NoExecutionRunner())
if __name__=='__main__':
 import uvicorn
 uvicorn.run(app,host='127.0.0.1',port=int(os.environ['ROOZ_FIXTURE_PORT']),log_level='warning')
