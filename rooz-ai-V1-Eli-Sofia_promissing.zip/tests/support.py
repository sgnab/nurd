"""Test adapters only: scripted model and native subprocesses, never production fallbacks."""
import asyncio,json,shutil,sys,tempfile,os
from pathlib import Path
from types import SimpleNamespace

class Message:
 def __init__(self,content='',calls=None):self.content=content;self.tool_calls=calls or []
 def model_dump(self,**kwargs):return {'role':'assistant','content':self.content,'tool_calls':[{'id':c.id,'type':'function','function':{'name':c.function.name,'arguments':c.function.arguments}} for c in self.tool_calls]}
def call(name,args):return SimpleNamespace(id=name,function=SimpleNamespace(name=name,arguments=json.dumps(args)))
class Model:
 def __init__(self,script=None):
  self.script=list(script or []);self.prompts=[];self.closed=False;self.chat=SimpleNamespace(completions=SimpleNamespace(create=self.create))
 async def create(self,**kwargs):
  self.prompts.append(kwargs)
  if self.script:
   value=self.script.pop(0)
   if value=='wait':await asyncio.sleep(1000)
   if isinstance(value,Exception):raise value
  else:
   prior=next((m['content'] for m in reversed(kwargs['messages']) if m['role']=='user'),'')
   value=Message('## Ready to build\n\n'+prior+'\n\n```python\nprint("Hello, Rooz")\n```\n\n<script>window.ROOZ_XSS=true</script>')
  return SimpleNamespace(choices=[SimpleNamespace(message=value)])
 async def close(self):self.closed=True
class NativeTestRunner:
 """Executes only controlled test fixtures. Production always uses DockerRunner."""
 def __init__(self,unavailable=False):self.commands=[];self.unavailable=unavailable
 async def capability(self):return {'ready':not self.unavailable,'reason':'Test fixture, not Docker'}
 async def run(self,workspace,command,stop):
  self.commands.append(command)
  if self.unavailable:return {'status':'unavailable','exit_code':None,'output':'Fixture runner unavailable','command':command}
  if stop.is_set():raise asyncio.CancelledError()
  with tempfile.TemporaryDirectory() as d:
   shutil.copytree(workspace,Path(d)/'project')
   capture=Path(d)/'project'/'.rooz-screenshots'
   if capture.is_symlink():capture.unlink()
   elif capture.exists():shutil.rmtree(capture)
   capture.mkdir()
   actual=[sys.executable if command[0] in ('python','python3') else command[0],*command[1:]]
   if actual[-1]=='/opt/rooz/check_workspace.py':return {'status':'unavailable','exit_code':None,'output':'Automatic container-only smoke check is not provided by this native test adapter','command':command}
   process=await asyncio.create_subprocess_exec(*actual,cwd=Path(d)/'project',env={**os.environ,'ROOZ_SCREENSHOT_DIR':str(capture)},stdout=asyncio.subprocess.PIPE,stderr=asyncio.subprocess.STDOUT)
   output,_=await process.communicate()
   from rooz.visual import collect_screenshots
   return {'status':'passed' if process.returncode==0 else 'failed','exit_code':process.returncode,'command':command,'output':output.decode(),'_screenshots':collect_screenshots(Path(d)/'project')}
