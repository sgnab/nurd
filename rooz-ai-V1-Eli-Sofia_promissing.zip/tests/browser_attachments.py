"""Actual browser/upload/download/storage checks; scripted model, no real provider call."""
import base64,io,json,os,socket,subprocess,sys,tempfile,time,urllib.request
from pathlib import Path
from PIL import Image
from playwright.sync_api import sync_playwright,expect
from tests.browser_projects_support import create_project
root=Path(__file__).parents[1];evidence=Path(os.getenv('ROOZ_TEST_OUTPUT') or tempfile.mkdtemp(prefix='rooz-attachments-'));evidence.mkdir(parents=True,exist_ok=True)
img=io.BytesIO();Image.new('RGB',(100,65),(230,30,40)).save(img,'PNG');png=img.getvalue()
with socket.socket() as sock:sock.bind(('127.0.0.1',0));port=sock.getsockname()[1]
with tempfile.TemporaryDirectory() as directory:
 env=os.environ.copy();env.update(ROOZ_FIXTURE_DATA=directory,ROOZ_FIXTURE_PORT=str(port))
 log=(evidence/'server.log').open('w');server=subprocess.Popen([sys.executable,str(root/'tests/attachment_fixture_server.py')],env=env,stdout=log,stderr=subprocess.STDOUT)
 try:
  base='http://127.0.0.1:'+str(port)
  for _ in range(100):
   try:urllib.request.urlopen(base+'/api/chats',timeout=1);break
   except OSError:time.sleep(.1)
  else:raise RuntimeError('Fixture did not start')
  passed=[]
  with sync_playwright() as p:
   browser=p.chromium.launch(executable_path=os.getenv('ROOZ_BROWSER_EXECUTABLE') or None,headless=True,args=['--no-sandbox','--disable-dev-shm-usage','--disable-gpu'])
   context=browser.new_context(viewport={'width':1440,'height':1050},accept_downloads=True);page=context.new_page();errors=[];page.on('pageerror',lambda e:errors.append(str(e)));page.goto(base);create_project(page,"Initial project")
   expect(page.get_by_label('Attach files',exact=True)).to_be_enabled()
   with page.expect_file_chooser() as chooser:page.get_by_label('Attach files',exact=True).click()
   chooser.value.set_files([{'name':'notes.md','mimeType':'text/markdown','buffer':b'# TEXT_TOKEN\nReview this reference.'},{'name':'example.py','mimeType':'text/plain','buffer':b'print("reference only")'},{'name':'screen.png','mimeType':'image/png','buffer':png}])
   expect(page.locator('#attachmentDrafts .attachment-card')).to_have_count(3,timeout=15000);expect(page.locator('#attachmentDrafts img')).to_be_visible();passed.append('Multi-file picker uploads code, Markdown and image; thumbnail appears')
   page.get_by_role('button',name='Remove example.py',exact=True).click();expect(page.locator('#attachmentDrafts .attachment-card')).to_have_count(2);passed.append('Unsent attachment can be removed independently')
   page.reload();expect(page.locator('#attachmentDrafts .attachment-card')).to_have_count(2);passed.append('Pending attachments survive refresh')
   page.locator('#prompt').fill('@sOfIa inspect fixtures');page.locator('#send').click()
   expect(page.get_by_text('ATTACHMENT_REVIEW_READY: image payload received; TEXT_TOKEN present.',exact=True)).to_be_visible(timeout=15000)
   expect(page.locator('.message-meta strong').last).to_have_text('Sofia');expect(page.locator('.message-attachments .attachment-card')).to_have_count(2)
   expect(page.locator('#attachmentDrafts')).to_be_hidden();expect(page.locator('#fileCount')).to_have_text('0');passed.append('Selected agent receives actual image/text input; uploads remain outside project code')
   with page.expect_download() as info:page.locator('.message-attachments a').filter(has_text='notes.md').click()
   info.value.save_as(evidence/'notes.md');assert (evidence/'notes.md').read_bytes()==b'# TEXT_TOKEN\nReview this reference.'
   with page.expect_download() as info:page.locator('.message-attachments a').filter(has_text='screen.png').click()
   info.value.save_as(evidence/'screen.png');assert (evidence/'screen.png').read_bytes()==png;passed.append('Code/text and original image downloads preserve exact bytes')
   page.reload();expect(page.locator('.message-attachments img')).to_be_visible();expect(page.get_by_text('ATTACHMENT_REVIEW_READY: image payload received; TEXT_TOKEN present.',exact=True)).to_be_visible();passed.append('Sent references and replies persist after refresh')
   create_project(page,'Another project');expect(page.locator('.message-attachments')).to_have_count(0);expect(page.locator('#attachmentDrafts')).to_be_hidden();passed.append('New room has no previous room’s attachments')
   # Paste an actual image File into the composer.
   page.locator('#prompt').evaluate("""(node,b64)=>{const bytes=Uint8Array.from(atob(b64),c=>c.charCodeAt(0));const dt=new DataTransfer();dt.items.add(new File([bytes],'pasted.png',{type:'image/png'}));node.dispatchEvent(new ClipboardEvent('paste',{clipboardData:dt,bubbles:true,cancelable:true}));}""",base64.b64encode(png).decode())
   expect(page.locator('#attachmentDrafts img')).to_be_visible();passed.append('Pasted screenshot is uploaded as an attachment')
   page.locator('#send').click();expect(page.get_by_text('ATTACHMENT_REVIEW_READY: image payload received.',exact=True)).to_be_visible(timeout=15000);passed.append('Image-only message sends without typed text')
   # Drop a text file and reject an unsupported file without losing the valid draft.
   page.locator('#prompt').evaluate("""node=>{const dt=new DataTransfer();dt.items.add(new File(['# TEXT_TOKEN'], 'dropped.md',{type:'text/markdown'}));node.dispatchEvent(new DragEvent('drop',{dataTransfer:dt,bubbles:true,cancelable:true}));}""")
   expect(page.locator('#attachmentDrafts .attachment-card')).to_have_count(1)
   page.locator('#attachmentInput').set_input_files({'name':'bad.exe','mimeType':'application/octet-stream','buffer':b'not supported'})
   expect(page.locator('#error')).to_be_visible();expect(page.locator('#error')).to_contain_text('supported');expect(page.locator('#attachmentDrafts .attachment-card')).to_have_count(1);passed.append('Drop works; invalid file produces an error and preserves existing draft')
   page.get_by_role('button',name='Remove dropped.md',exact=True).click();expect(page.locator('#attachmentDrafts')).to_be_hidden()
   page.locator('#attachmentInput').set_input_files({'name':'peer.png','mimeType':'image/png','buffer':png});expect(page.locator('#attachmentDrafts img')).to_be_visible()
   page.locator('#prompt').fill('@Alex attachment handoff');page.locator('#send').click()
   expect(page.get_by_text('ALEX_IMAGE_RESULT: Sofia inspected the shared attachment',exact=True)).to_be_visible(timeout=15000)
   expect(page.get_by_text('SOFIA_IMAGE_RECEIVED: actual pixel payload present',exact=True)).to_be_visible();expect(page.locator('.handoff-status.completed')).to_have_count(1);passed.append('Called teammate receives same root image through the shared room')
   page.set_viewport_size({'width':390,'height':844});page.wait_for_timeout(200)
   assert page.evaluate('document.documentElement.scrollWidth<=innerWidth');expect(page.get_by_label('Attach files',exact=True)).to_be_visible();page.screenshot(path=str(evidence/'mobile.png'),full_page=True);passed.append('Mobile attachment composer and file cards fit the screen')
   # Hold real old-room GET responses while navigating away during Send.
   page.set_viewport_size({'width':1440,'height':1050})
   page.evaluate("""()=>{const original=window.fetch,old=state.chat;window.__held=[];window.__restoreFetch=()=>window.fetch=original;
    window.fetch=async function(path,options){const response=await original.call(this,path,options);
     if(path==='/api/chats/'+old&&(!options?.method||options.method==='GET'))await new Promise(resolve=>window.__held.push(resolve));return response;};}""")
   page.locator('#prompt').fill('@Eli hello');page.locator('#send').click()
   page.wait_for_function('window.__held.length>0&&document.querySelector("#prompt").value===""')
   create_project(page,'Another project');expect(page.locator('.message')).to_have_count(0)
   page.evaluate('()=>{window.__restoreFetch();window.__held.forEach(resolve=>resolve());}')
   page.wait_for_function('!state.sending');expect(page.locator('.message')).to_have_count(0)
   assert page.evaluate('state.data.chat.id===state.chat');passed.append('Late Send responses cannot replace the newly opened room')
   assert not errors,errors;browser.close()
  (evidence/'results.json').write_text(json.dumps({'real_chromium':True,'real_openai':False,'actual_multimodal_payload_inspected_by_fixture':True,'passed':passed},indent=2));print('\n'.join('PASS '+x for x in passed))
 finally:server.terminate();server.wait(timeout=10);log.close()
