"""Optional real-browser check. Uses only controlled fixtures, never real model calls.
Run with the development dependencies and Playwright Chromium installed.
"""
import json,os,socket,subprocess,sys,tempfile,time,urllib.request
from pathlib import Path
from playwright.sync_api import sync_playwright,expect
root=Path(__file__).parents[1]
with socket.socket() as sock:
 sock.bind(('127.0.0.1',0));port=sock.getsockname()[1]
with tempfile.TemporaryDirectory(prefix='rooz-monitoring-browser-') as folder:
 env={**os.environ,'ROOZ_FIXTURE_DATA':folder,'ROOZ_FIXTURE_PORT':str(port),'OPENAI_API_KEY':'FAKE_FOR_UI_TEST_ONLY'}
 with open(Path(folder)/'server.log','w') as log:
  server=subprocess.Popen([sys.executable,'-m','tests.monitoring_fixture_server'],cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
  try:
   base='http://127.0.0.1:'+str(port)
   for _ in range(100):
    try:urllib.request.urlopen(base+'/api/monitoring',timeout=1);break
    except OSError:time.sleep(.1)
   else:raise RuntimeError('Fixture server did not start')
   with sync_playwright() as playwright:
    browser=playwright.chromium.launch(executable_path=os.getenv('ROOZ_BROWSER_EXECUTABLE') or None,headless=True,args=['--no-sandbox'])
    page=browser.new_page(viewport={'width':1440,'height':1000},accept_downloads=True)
    errors=[];page.on('pageerror',lambda error:errors.append(str(error)))
    page.goto(base+'/monitoring')
    expect(page.get_by_role('heading',name='Security test dashboard')).to_be_visible()
    expect(page.locator('#runFast')).to_be_enabled(timeout=15000)
    expect(page.locator('.report .cases .badge.passed')).to_have_count(7)
    with page.expect_download() as download:
     page.get_by_role('button',name='Download report').first.click()
    document=json.loads(Path(download.value.path()).read_text())
    assert document['mode']=='fast' and all(c['status']=='passed' for c in document['cases'])
    page.get_by_label('I approve these bounded paid API calls',exact=False).check()
    # The provider is a waiting scripted fixture in this test; this spends no API credit.
    page.get_by_role('button',name='Run agent tests',exact=True).click()
    expect(page.get_by_role('button',name='Stop test',exact=True)).to_be_visible(timeout=10000)
    page.get_by_role('button',name='Stop test',exact=True).click()
    expect(page.locator('.report').first.locator('summary .badge')).to_have_text('cancelled',timeout=10000)
    expect(page.locator('.report').first.locator('.cases .badge.inconclusive')).to_have_count(5)
    chat=page.request.post(base+'/api/projects',data={'title':'Browser activity fixture'}).json()
    run=page.request.post(base+'/api/chats/'+chat['id']+'/messages',data={'agent':'eli','content':'Wait for Stop'}).json()
    page.get_by_role('button',name='Agent activity',exact=True).click()
    expect(page.get_by_text('Waiting for model response',exact=False)).to_be_visible(timeout=10000)
    page.get_by_role('button',name='Stop agent',exact=True).click()
    for _ in range(100):
     result=page.request.get(base+'/api/runs/'+run['id']).json()
     if result['status']=='cancelled':break
     page.wait_for_timeout(50)
    else:raise AssertionError('Normal agent did not stop')
    page.get_by_role('button',name='Security tests',exact=True).click()
    for width,height in ((1440,1000),(390,844)):
     page.set_viewport_size({'width':width,'height':height})
     assert page.evaluate('document.documentElement.scrollWidth <= innerWidth'), 'Horizontal overflow'
    assert not errors,errors
    browser.close()
    print('PASS actual browser/HTTP: automatic free checks, JSON download, live-suite Stop, inconclusive cases, agent activity/Stop, desktop/mobile overflow. Fixture model only; no live-provider claim.')
  finally:
   server.terminate()
   try:server.wait(timeout=5)
   except subprocess.TimeoutExpired:server.kill();server.wait()
