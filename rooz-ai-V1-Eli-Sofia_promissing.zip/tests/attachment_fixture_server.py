"""Browser fixtures only: verifies model payload delivery, not real visual understanding."""
import asyncio,os
from pathlib import Path
from types import SimpleNamespace
from rooz.api import create_app
from tests.team_fixture_server import TeamModel
from tests.support import Message,call,NativeTestRunner

def text_content(value):
 if isinstance(value,str):return value
 return '\n'.join(p.get('text','') for p in value if isinstance(p,dict))
class AttachmentModel(TeamModel):
 async def create(self,**kwargs):
  system=kwargs['messages'][0]['content'];speaker=next(a for a in ('alex','sofia','eli') if system.startswith('You are '+a.title()))
  user=text_content(next(m['content'] for m in reversed(kwargs['messages']) if m['role']=='user'))
  all_text='\n'.join(text_content(m['content']) for m in kwargs['messages'])
  pixels=[p for m in kwargs['messages'] if isinstance(m.get('content'),list) for p in m['content'] if p.get('type')=='image_url' and p.get('image_url',{}).get('url','').startswith('data:image/jpeg;base64,')]
  tools=[m for m in kwargs['messages'] if m['role']=='tool']
  if 'attachment wait' in all_text:await asyncio.sleep(1000)
  if 'attachment handoff' in all_text:
   if speaker=='alex' and not tools:value=Message(calls=[call('call_agent',{'agent':'SOFIA','message':'attachment handoff: inspect this request’s screenshot','reason':'UI inspection'})])
   elif speaker=='sofia':
    assert pixels,'Peer did not receive image pixels';value=Message('SOFIA_IMAGE_RECEIVED: actual pixel payload present')
   else:value=Message('ALEX_IMAGE_RESULT: Sofia inspected the shared attachment')
  elif pixels:
   value=Message('ATTACHMENT_REVIEW_READY: image payload received'+('; TEXT_TOKEN present' if 'TEXT_TOKEN' in all_text else '')+'.')
  else:return await super().create(**kwargs)
  return SimpleNamespace(choices=[SimpleNamespace(message=value)])

app=create_app(os.environ['ROOZ_FIXTURE_DATA'],Path(__file__).parents[1]/'static',lambda:AttachmentModel(),'scripted-test-model',NativeTestRunner())
if __name__=='__main__':
 import uvicorn
 uvicorn.run(app,host='127.0.0.1',port=int(os.environ['ROOZ_FIXTURE_PORT']),log_level='warning')
