"""Host orchestration tests use scripted models; they are not live Eli evaluations."""
import asyncio
import importlib.util
import json
import tempfile
import unittest
from pathlib import Path
from rooz import eli, scaffold
from rooz.agents import AgentService
from rooz.storage import Store
from tests.support import Model, Message, call, NativeTestRunner


class ContextTests(unittest.TestCase):
    def test_documents_are_current_bounded_and_missing_is_explicit(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            (root/'DESIGN.md').write_text('a'*13000)
            first = eli.context(root)
            self.assertTrue(first['project_documents']['DESIGN.md']['truncated'])
            self.assertEqual(first['project_documents']['PLAN.md']['status'], 'not present')
            (root/'DESIGN.md').write_text('Updated contract')
            self.assertEqual(eli.context(root)['project_documents']['DESIGN.md']['content'], 'Updated contract')

    def test_only_declared_trusted_guides_are_readable(self):
        for name in eli.GUIDES:
            self.assertIn('instructions', eli.read_skill(name))
        with self.assertRaises(ValueError): eli.read_skill('../../app.py')

    def test_starter_is_bounded_and_preserves_existing_projects(self):
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory)
            files=scaffold.files(root)
            # Store writes at most twenty files in a single atomic batch.
            self.assertLessEqual(len(files),20)
            paths={item['path'] for item in files}
            self.assertIn('frontend/src/App.tsx',paths)
            self.assertIn('backend/main.py',paths)
            self.assertIn('tests/browser_check.py',paths)
            self.assertFalse(any('node_modules/' in path for path in paths))
            (root/'existing.py').write_text('keep me')
            with self.assertRaises(ValueError): scaffold.files(root)
            self.assertEqual((root/'existing.py').read_text(),'keep me')

    def test_frontend_dependencies_are_supplied_only_in_disposable_workspace(self):
        spec=importlib.util.spec_from_file_location('sandbox_execute',Path(__file__).parents[1]/'sandbox/execute.py')
        module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory);runtime=root/'runtime';runtime.mkdir()
            (runtime/'package.json').write_text(json.dumps({'dependencies':{'react':'18.3.1'}}))
            (runtime/'node_modules').mkdir()
            (runtime/'node_modules'/'react').mkdir()
            (runtime/'node_modules'/'react'/'index.js').write_text('module.exports = {}')
            workspace=root/'work';frontend=workspace/'frontend';frontend.mkdir(parents=True)
            (frontend/'package.json').write_text(json.dumps({'dependencies':{'react':'18.3.1'}}))
            module.prepare(workspace,runtime)
            self.assertFalse((frontend/'node_modules').is_symlink())
            self.assertEqual((frontend/'node_modules'/'react').resolve(),runtime/'node_modules'/'react')
            cache=frontend/'node_modules'/'.vite-temp'
            cache.mkdir();(cache/'config.mjs').write_text('export default {}')
            self.assertFalse((runtime/'node_modules'/'.vite-temp').exists())

    def test_test_runner_is_resolvable_from_root_without_package_json(self):
        spec=importlib.util.spec_from_file_location('sandbox_execute_node',Path(__file__).parents[1]/'sandbox/execute.py')
        module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory);runtime=root/'runtime';runtime.mkdir()
            (runtime/'package.json').write_text('{}')
            (runtime/'node_modules/@playwright/test').mkdir(parents=True)
            workspace=root/'work';workspace.mkdir()
            module.prepare(workspace,runtime)
            self.assertTrue((workspace/'node_modules/@playwright/test').is_dir())
            self.assertFalse((workspace/'package.json').exists())


class EliFlowTests(unittest.IsolatedAsyncioTestCase):
    async def run_script(self, script, existing=None, agent='eli', runner=None):
        temp=tempfile.TemporaryDirectory();self.addCleanup(temp.cleanup)
        store=Store(temp.name);chat=store.create_chat();root=store.workspace(chat['project_id'])
        for path,text in (existing or {}).items():
            target=root/path;target.parent.mkdir(parents=True,exist_ok=True);target.write_text(text)
        run=store.start_run(chat['id'],agent,'Implement the requested feature')
        model=Model(script)
        await AgentService(store,runner or NativeTestRunner(),lambda:model,'fixture').execute(run,asyncio.Event())
        return store,chat,run,model

    async def test_eli_gets_context_and_can_load_skill(self):
        store,chat,run,model=await self.run_script([
            Message(calls=[call('read_skill',{'name':'frontend'})]),Message('Reviewed the frontend guidance.')
        ],{'DESIGN.md':'Existing React app; preserve the routes'})
        system=model.prompts[0]['messages'][0]['content']
        self.assertIn('Existing React app',system)
        self.assertIn('full-stack',system)
        self.assertIn('real content',model.prompts[-1]['messages'][-1]['content'])
        self.assertEqual(store.run(run['id'])['status'],'completed')

    async def test_existing_file_requires_inspection_then_can_be_repaired_and_tested(self):
        script=[
            Message(calls=[call('write_files',{'files':[{'path':'calc.py','content':'value=2\n'}]})]),
            Message(calls=[call('read_files',{'paths':['calc.py']})]),
            Message(calls=[call('write_files',{'files':[{'path':'calc.py','content':'value=2\n'}]})]),
            Message(calls=[call('run_tests',{'command':['python','-c','from calc import value; assert value == 2']})]),
            Message('The changed value was checked.')]
        store,chat,run,model=await self.run_script(script,{'calc.py':'value=1\n'})
        self.assertIn('Read the current file',json.dumps(model.prompts[-1]['messages']))
        self.assertEqual(store.run(run['id'])['checks'][-1]['status'],'passed')
        self.assertEqual(store.workspace(chat['project_id']).joinpath('calc.py').read_text(),'value=2\n')

    async def test_failed_check_returns_to_eli_for_repair(self):
        command=['python','test_feature.py']
        script=[Message(calls=[call('run_tests',{'command':command})]),
                Message('I found a problem.'),
                Message(calls=[call('read_skill',{'name':'debugging'})]),
                Message(calls=[call('read_files',{'paths':['feature.py']})]),
                Message(calls=[call('write_files',{'files':[{'path':'feature.py','content':'value=4\n'}]})]),
                Message(calls=[call('run_tests',{'command':command})]),
                Message('The affected check now passes.')]
        store,chat,run,model=await self.run_script(script,{'feature.py':'value=2\n','test_feature.py':'from feature import value\nassert value == 4\n'})
        self.assertIn('failed check',json.dumps(model.prompts[-1]['messages']))
        self.assertEqual([c['status'] for c in store.run(run['id'])['checks']],['failed','passed'])

    async def test_other_agents_do_not_receive_eli_only_tools(self):
        store,chat,run,model=await self.run_script([Message('Hello')],agent='alex')
        self.assertNotIn('read_skill',[tool['function']['name'] for tool in model.prompts[0]['tools']])

    async def test_scaffold_is_saved_as_downloadable_artifacts(self):
        store,chat,run,model=await self.run_script([
            Message(calls=[call('scaffold_app',{})]),Message('Starter saved; application behavior remains unverified.'),
            Message('Starter saved; runner unavailable, no successful acceptance claimed.')],runner=NativeTestRunner(unavailable=True))
        self.assertTrue((store.workspace(chat['project_id'])/'frontend/package.json').is_file())
        self.assertGreater(len(store.artifacts(chat['project_id'])),10)
        self.assertEqual(store.run(run['id'])['status'],'failed')
        self.assertEqual(store.run(run['id'])['checks'][-1]['status'],'unavailable')
        self.assertEqual(store.run(run['id'])['checks'][0]['kind'],'full-stack acceptance')
