import asyncio
import shutil
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
from fastapi.testclient import TestClient
from rooz.api import create_app
from rooz.storage import Store
from rooz.fullstack_server import stage_source
from tests.support import Model,NativeTestRunner
from tests.preview_support import NativePreview


class PreviewCopyTests(unittest.TestCase):
    def test_copy_does_not_modify_mount_metadata(self):
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory);source=root/'source';source.mkdir()
            (source/'main.py').write_text('application code')
            mount=root/'work';mount.mkdir()
            original=shutil.copystat
            def reject_mount(src,dst,**kwargs):
                if Path(dst).resolve()==mount.resolve():
                    raise PermissionError(1,'Operation not permitted',str(dst))
                return original(src,dst,**kwargs)
            with patch('shutil.copystat',side_effect=reject_mount):
                with self.assertRaises(shutil.Error):shutil.copytree(source,mount,dirs_exist_ok=True)
                staged=stage_source(source,mount)
            self.assertEqual(staged,mount/'project')
            self.assertEqual((staged/'main.py').read_text(),'application code')
            self.assertEqual((source/'main.py').read_text(),'application code')

    def test_source_cannot_be_its_own_work_directory(self):
        with tempfile.TemporaryDirectory() as directory:
            with self.assertRaises(RuntimeError):stage_source(directory,directory)


class ProjectNamesTests(unittest.TestCase):
    def test_rename_preserves_files_history_identity_and_shared_project_name(self):
        with tempfile.TemporaryDirectory() as directory:
            store=Store(directory);chat=store.create_chat(' Notes ')
            root=store.workspace(chat['project_id']);(root/'saved.py').write_text('keep')
            store.append_message(chat['id'],'user',None,'Saved discussion',None)
            sibling=store.create_chat('ignored separate label',project_id=chat['project_id'])
            self.assertEqual(sibling['title'],'Notes')
            store.rename(chat['id'],'Notes dashboard')
            self.assertEqual(store.project(chat['project_id'])['title'],'Notes dashboard')
            self.assertEqual(store.chat(sibling['id'])['title'],'Notes dashboard')
            self.assertEqual(store.workspace(chat['project_id']),root)
            self.assertEqual((root/'saved.py').read_text(),'keep')
            self.assertEqual(store.messages(chat['id'])[0]['content'],'Saved discussion')
            reopened=Store(directory)
            self.assertEqual(reopened.chat(chat['id'])['title'],'Notes dashboard')

    def test_single_chat_legacy_title_is_adopted_without_recreating_project(self):
        with tempfile.TemporaryDirectory() as directory:
            store=Store(directory);chat=store.create_chat('New conversation')
            with store.db() as connection:connection.execute('UPDATE chats SET title=? WHERE id=?',('My original notes',chat['id']))
            store=Store(directory)
            self.assertEqual(store.project(chat['project_id'])['title'],'My original notes')
            self.assertEqual(store.chat(chat['id'])['project_id'],chat['project_id'])

    def test_first_message_does_not_replace_chosen_project_name(self):
        with tempfile.TemporaryDirectory() as directory:
            store=Store(directory);chat=store.create_chat('My notes')
            store.start_run(chat['id'],'eli','Build a useful app')
            self.assertEqual(store.chat(chat['id'])['title'],'My notes')
            self.assertEqual(store.project(chat['project_id'])['title'],'My notes')

    def test_named_creation_api_requires_name_and_zip_uses_it(self):
        with tempfile.TemporaryDirectory() as directory:
            backend=NativePreview()
            app=create_app(directory,Path(__file__).parents[1]/'static',lambda:Model(),'fixture',NativeTestRunner(),backend)
            with TestClient(app) as client:
                for body in ({},{'title':'   '},{'title':''}):
                    self.assertEqual(client.post('/api/projects',json=body).status_code,422)
                self.assertEqual(client.get('/api/chats').json()['chats'],[])
                response=client.post('/api/projects',json={'title':' Notes tracker '})
                self.assertEqual(response.status_code,201)
                chat=response.json();self.assertEqual(chat['title'],'Notes tracker')
                project=app.state.store.project(chat['project_id'])
                self.assertEqual(project['title'],chat['title'])
                archive=client.get('/api/projects/'+chat['project_id']+'/download')
                self.assertIn('Notes%20tracker.zip',archive.headers['content-disposition'])
            backend.temp.cleanup()
