"""Port readiness and actual image delivery regressions; no Docker/live-provider claims."""
import asyncio,base64,io,json,tempfile,unittest
from pathlib import Path
from unittest.mock import AsyncMock,patch
from types import SimpleNamespace
from PIL import Image
from rooz.preview import DockerPreview,PreviewError
from rooz.visual import collect_screenshots,VisualEvidence
from rooz.storage import Store
from rooz.agents import AgentService
from tests.support import Model,Message,call,NativeTestRunner


def png():
    out=io.BytesIO();Image.new('RGB',(40,30),(42,91,130)).save(out,'PNG');return out.getvalue()


class PortReadinessTests(unittest.IsolatedAsyncioTestCase):
    async def test_transient_empty_mapping_becomes_ready_without_another_container(self):
        docker=DockerPreview();docker.command=AsyncMock(side_effect=[(0,'{"8080/tcp":null}'),
            (0,'{"Status":"running"}'),(0,'{}'),(0,'{"Status":"running"}'),
            (0,'{"8080/tcp":[{"HostIp":"127.0.0.1","HostPort":"32123"}]}')])
        self.assertEqual(await docker.wait_port('fixture'),'http://127.0.0.1:32123/')
        self.assertEqual(len(docker.command.call_args_list),5)
        self.assertTrue(all(c.args[0]=='inspect' for c in docker.command.call_args_list))

    async def test_exited_container_reports_exit_instead_of_missing_port(self):
        docker=DockerPreview();docker.command=AsyncMock(side_effect=[(0,'{}'),(0,'{"Status":"exited","ExitCode":1}')])
        with self.assertRaisesRegex(PreviewError,'exited.*exit 1'):await docker.wait_port('fixture')

    async def test_non_loopback_mapping_is_never_accepted(self):
        docker=DockerPreview();docker.command=AsyncMock(return_value=(0,'{"8080/tcp":[{"HostIp":"0.0.0.0","HostPort":"32123"}]}'))
        with self.assertRaisesRegex(PreviewError,'refusing a non-loopback'):await docker.wait_port('fixture')

    async def test_timeout_is_actionable_and_cancel_interrupts_wait(self):
        docker=DockerPreview();docker.port_timeout=0
        docker.command=AsyncMock(side_effect=[(0,'{}'),(0,'{"Status":"running"}')])
        with self.assertRaisesRegex(PreviewError,'did not publish port 8080'):await docker.wait_port('fixture')
        stop=asyncio.Event();stop.set()
        with self.assertRaises(asyncio.CancelledError):await docker.wait_port('fixture',stop)

    async def test_stop_during_retry_does_not_start_another_inspection(self):
        docker=DockerPreview();stop=asyncio.Event()
        async def command(*args,**kwargs):
            if '.State' in args[2]:stop.set();return (0,'{"Status":"running"}')
            return (0,'{}')
        docker.command=AsyncMock(side_effect=command)
        with self.assertRaises(asyncio.CancelledError):await docker.wait_port('fixture',stop)
        self.assertEqual(docker.command.await_count,2)


class VisualStorageTests(unittest.TestCase):
    def test_collection_is_bounded_and_does_not_follow_links(self):
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory);folder=root/'.rooz-screenshots';folder.mkdir()
            outside=root/'outside.png';outside.write_bytes(png())
            (folder/'00-link.png').symlink_to(outside)
            (folder/'nested').mkdir();(folder/'nested'/'not-exported.png').write_bytes(png())
            for i in range(8):(folder/(str(i)+'.png')).write_bytes(png())
            found=collect_screenshots(root)
            self.assertEqual(len(found),4);self.assertNotIn('00-link.png',[r['filename'] for r in found])
            self.assertFalse(any('/' in r['filename'] for r in found))

    def test_project_isolation_invalid_image_rejection_and_both_image_message_formats(self):
        with tempfile.TemporaryDirectory() as directory:
            store=Store(directory);chat=store.create_chat();other=store.create_chat()
            run=store.start_run(chat['id'],'eli','Check UI');visual=VisualEvidence(store)
            rows,warnings=visual.save(chat['project_id'],run['id'],'revision1',[
                {'filename':'desktop.png','data':png()},{'filename':'invalid.png','data':b'not an image'}])
            self.assertEqual(len(rows),1);self.assertEqual(len(warnings),1)
            for responses in (False,True):
                parts=visual.parts(chat['project_id'],[rows[0]['id']],responses=responses)
                url=parts[1]['image_url'] if responses else parts[1]['image_url']['url']
                image=Image.open(io.BytesIO(base64.b64decode(url.split(',',1)[1])))
                self.assertEqual(image.size,(40,30));self.assertIn('revision1',parts[0]['text'])
            with self.assertRaises(ValueError):visual.parts(other['project_id'],[rows[0]['id']],responses=False)
            with self.assertRaises(ValueError):visual.parts(chat['project_id'],['../../escape'],responses=False)
            with self.assertRaises(ValueError):visual.save(other['project_id'],run['id'],'x',[])


class VisualAgentTests(unittest.IsolatedAsyncioTestCase):
    async def test_production_runner_exports_failed_test_screenshot_before_cleanup(self):
        from rooz.runner import DockerRunner
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory);(root/'test.py').write_text('controlled fixture')
            staged_paths=[]
            async def spawn(*args,**kwargs):
                self.assertIn('ROOZ_SCREENSHOT_DIR=/work/.rooz-screenshots',args)
                volume=args[args.index('-v')+1];staged=Path(volume.rsplit(':/work:rw',1)[0]);staged_paths.append(staged)
                (staged/'.rooz-screenshots'/'failed-form.png').write_bytes(png())
                return SimpleNamespace(returncode=1,stdout=SimpleNamespace(read=AsyncMock(side_effect=[b'assertion failed',b''])))
            runner=DockerRunner();runner.capability=AsyncMock(return_value={'ready':True})
            with patch('rooz.runner.asyncio.create_subprocess_exec',side_effect=spawn):
                result=await runner.run(root,['python','test.py'],asyncio.Event())
            self.assertEqual(result['status'],'failed')
            self.assertEqual(result['_screenshots'][0]['data'],png())
            self.assertFalse(staged_paths[0].exists())

    async def test_actual_responses_sdk_receives_image_pixels(self):
        import httpx
        from openai import AsyncOpenAI
        class ScreenshotRunner:
            async def run(self,root,command,stop):
                return {'status':'passed','command':command,'output':'Controlled image fixture',
                        '_screenshots':[{'filename':'desktop.png','data':png()}]}
        requests=[]
        async def handler(request):
            body=json.loads(request.content);requests.append(body)
            if len(requests)==1:
                output=[{'type':'function_call','id':'f1','call_id':'c1','name':'run_tests',
                         'arguments':json.dumps({'command':['python','browser.py']}),'status':'completed'}]
            else:
                images=[p for m in body['input'] if isinstance(m.get('content'),list) for p in m['content'] if p.get('type')=='input_image']
                self.assertEqual(len(images),1)
                pixels=Image.open(io.BytesIO(base64.b64decode(images[0]['image_url'].split(',',1)[1])))
                self.assertEqual(pixels.size,(40,30))
                self.assertEqual(body['input'][-1]['content'][0]['type'],'input_text')
                output=[{'type':'message','id':'m1','role':'assistant','status':'completed',
                         'content':[{'type':'output_text','text':'Image received.','annotations':[]}]}]
            return httpx.Response(200,json={'id':'r'+str(len(requests)),'object':'response','created_at':1,
                                           'status':'completed','model':'gpt-6.1-sol','output':output})
        with tempfile.TemporaryDirectory() as directory:
            store=Store(directory);chat=store.create_chat();run=store.start_run(chat['id'],'eli','Inspect the UI')
            client=AsyncOpenAI(api_key='fixture-not-real',http_client=httpx.AsyncClient(transport=httpx.MockTransport(handler)))
            await AgentService(store,ScreenshotRunner(),lambda:client,'gpt-6.1-sol').execute(run,asyncio.Event())
            self.assertEqual(store.run(run['id'])['status'],'completed',store.messages(chat['id'])[-1]['content'])
            self.assertEqual(len(requests),2)

    async def test_test_runner_exports_images_before_disposable_copy_is_deleted(self):
        with tempfile.TemporaryDirectory() as directory:
            store=Store(directory);chat=store.create_chat();root=store.workspace(chat['project_id'])
            (root/'capture.py').write_text('import os\nfrom pathlib import Path\nfrom PIL import Image\np=Path(os.environ["ROOZ_SCREENSHOT_DIR"])/"desktop.png"\nImage.new("RGB",(40,30),(42,91,130)).save(p)\n')
            script=[Message(calls=[call('run_tests',{'command':['python','capture.py']})]),Message('Image inspected.')]
            model=Model(script);run=store.start_run(chat['id'],'eli','Review the interface')
            await AgentService(store,NativeTestRunner(),lambda:model,'fixture').execute(run,asyncio.Event())
            check=store.run(run['id'])['checks'][0]
            self.assertEqual(check['screenshots'][0]['revision'],store.revision(chat['project_id']))
            self.assertNotIn('_screenshots',check);self.assertNotIn('base64',json.dumps(check))
            self.assertEqual(model.prompts[-1]['messages'][-1]['content'][1]['type'],'image_url')
            self.assertFalse((root/'.rooz-screenshots').exists())

    async def test_successful_ui_build_cannot_skip_visual_evidence(self):
        class VisualRunner:
            def __init__(self):self.calls=0
            async def run(self,root,command,stop):
                self.calls+=1
                return {'status':'passed','command':command,'output':'Fixture acceptance',
                        '_screenshots':[{'filename':'desktop.png','data':png()}] if self.calls>1 else []}
        with tempfile.TemporaryDirectory() as directory:
            store=Store(directory);chat=store.create_chat();root=store.workspace(chat['project_id'])
            (root/'backend').mkdir();(root/'backend/main.py').write_text('app=None')
            (root/'frontend').mkdir();(root/'frontend/index.html').write_text('<h1>Old</h1>')
            script=[Message(calls=[call('read_files',{'paths':['frontend/index.html']})]),
                    Message(calls=[call('write_files',{'files':[{'path':'frontend/index.html','content':'<h1>New</h1>'}]})]),
                    Message('Ready without screenshots.'),Message('Build passed, deliver it.'),
                    Message(calls=[call('verify_app',{})]),Message('Rendered screenshot inspected.')]
            run=store.start_run(chat['id'],'eli','Improve the UI');model=Model(script);runner=VisualRunner()
            await AgentService(store,runner,lambda:model,'fixture').execute(run,asyncio.Event())
            self.assertEqual(runner.calls,2)
            self.assertEqual(store.run(run['id'])['status'],'completed')
            self.assertEqual(store.messages(chat['id'])[-1]['content'],'Rendered screenshot inspected.')
            self.assertIn('Host visual review',json.dumps(model.prompts[-1]['messages']))
