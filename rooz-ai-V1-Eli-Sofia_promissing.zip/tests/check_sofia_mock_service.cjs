// Execute the actual TypeScript mock service after Node's native type stripping.
const assert=require('node:assert/strict'),path=require('node:path'),{pathToFileURL}=require('node:url');
const memory=new Map();global.localStorage={getItem:k=>memory.has(k)?memory.get(k):null,setItem:(k,v)=>memory.set(k,String(v))};
(async()=>{
 const {items}=await import(pathToFileURL(path.resolve('rooz/templates/sofia/frontend/src/services/items.ts')).href);
 const first=await items.list();assert.equal(first.length,1);assert.equal(first[0].title,'Review the design');
 await assert.rejects(()=>items.create('  '),/Enter a title/);
 const created=await items.create('  Launch  ');assert.equal(created.title,'Launch');
 await items.update(created.id,{title:'Ready',done:true});const updated=(await items.list()).find(r=>r.id===created.id);assert.equal(updated.title,'Ready');assert.equal(updated.done,true);
 await assert.rejects(()=>items.update('absent',{done:true}),/no longer exists/);
 for(const row of await items.list())await items.remove(row.id);
 assert.deepEqual(await items.list(),[]);assert.deepEqual(await items.list(),[]); // No reseeding an intentionally empty collection.
 memory.set('sofia.frontend-starter.items','invalid-json');await assert.rejects(()=>items.list());assert.equal(memory.get('sofia.frontend-starter.items'),'invalid-json');
 memory.set('sofia.frontend-starter.items','[{"id":1}]');await assert.rejects(()=>items.list(),/could not be read/);
 console.log('PASS actual mock service: seed once, validation, create/edit/toggle/delete, empty persistence and corrupt-data preservation. Not browser/backend verification.');
})().catch(e=>{console.error(e);process.exitCode=1;});
