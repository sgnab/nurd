// Exercise the real card renderer with a minimal text-node adapter (not a browser).
const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict');
class Element {
 constructor(tag,cls='',text=''){this.tag=tag;this.className=cls;this.textContent=text;this.children=[];}
 append(...children){this.children.push(...children);}
 get text(){return this.textContent+this.children.map(c=>c.text).join(' ');}
}
const source=fs.readFileSync('static/app.js','utf8');
const renderer=source.slice(source.indexOf('function showChecks('),source.indexOf('function welcome('));
const context={state:{data:{revision:'current'}},el:(tag,cls,text)=>new Element(tag,cls,text)};
vm.createContext(context);vm.runInContext(renderer,context);
const base={reply_id:'reply',revision:'current',kind:'requested checks',command:['python','old_probe.py'],output:'Original assertion failed',status:'failed',check_id:'logical-1',execution_id:'execution-1'};
const render=checks=>context.showChecks({checks},{id:'reply',agent:'eli'});
const corrected={...base,command:['python','corrected_probe.py'],output:'Original behavior verified',status:'passed',execution_id:'execution-2',replacement_reason:'Build before navigation and retain behavior assertions'};
const card=render([{...base,superseded_by:'execution-2'},corrected]);
assert.equal(card.children[0].children[0].text,'Checks passed');assert.equal(card.className,'check-card');
assert.match(card.text,/failed \(resolved by a passing rerun\)/);assert.match(card.text,/Original assertion failed/);
assert.match(card.text,/Build before navigation/);assert.match(card.text,/old_probe.py/);assert.match(card.text,/corrected_probe.py/);
assert.equal(render([base,{...corrected,check_id:'unrelated'}]).children[0].children[0].text,'Checks failed');
assert.equal(render([base,{...corrected,status:'failed'}]).children[0].children[0].text,'Checks failed');
assert.equal(render([{...base,check_id:undefined},{...base,check_id:undefined,status:'passed'}]).children[0].children[0].text,'Checks passed');
assert.equal(render([{...base,revision:'older'}]).children[0].children[0].text,'Earlier code revision');
assert.equal(render([{...base,reply_id:'another'}]),null);
console.log('PASS corrected result, preserved history, unrelated pass, failed rerun, legacy results, stale revision and reply isolation');
