import asyncio,copy,json,sqlite3,tempfile,unittest
from pathlib import Path
from types import SimpleNamespace
from fastapi.testclient import TestClient
from rooz.team import agent_id,recipients,TeamSession,transcript
from rooz.storage import Store
from rooz.agents import AgentService
from rooz.api import create_app
from tests.support import Model,Message,call,NativeTestRunner

class AddressTests(unittest.TestCase):
 def test_names_and_tool_targets_are_case_insensitive(self):
  for agent in ('alex','sofia','eli'):
   for variant in (agent,agent.upper(),agent.title(),' @'+agent.upper()+' '):self.assertEqual(agent_id(variant),agent)
   for text in ('@'+agent.upper()+' please help','Hey '+agent.title(),'hello @'+agent.upper(),'Hi '+agent.upper()+', help',agent.title()+': help'):
    self.assertEqual(recipients(text,'alex'),[agent])
 def test_multiple_explicit_mentions_execute_once_in_order(self):
  self.assertEqual(recipients('@SOFIA please work with @eLi; @sofia can explain.'),['sofia','eli'])
 def test_ordinary_mentions_and_code_do_not_call_anyone(self):
  for text in ('Is Sofia here?','Does Eli know Python?','```python\n@sofia\n```','`@ELI` is an example','> @SOFIA quoted text','```\n@ELI'):
   self.assertEqual(recipients(text,'alex'),['alex'])
 def test_invalid_targets_are_explicit_errors(self):
  for name in ('quinn','sofia please',None,''):
   with self.assertRaises(ValueError):agent_id(name)

class PolicyTests(unittest.TestCase):
 def test_duplicate_request_and_active_cycle_are_rejected(self):
  s=TeamSession();target,key=s.begin('alex','SOFIA','Implement a form',1)
  with self.assertRaises(ValueError):s.begin('alex','sofia','Another form',2)
  s.end('alex',target,key,'Form ready')
  with self.assertRaisesRegex(ValueError,'already made'):s.begin('alex','sofia','IMPLEMENT A FORM',1)
 def test_self_call_does_not_spend_handoff_budget(self):
  s=TeamSession()
  with self.assertRaises(ValueError):s.begin('eli','ELI','A question',1)
  self.assertEqual(s.count,0)
 def test_teammate_can_ask_waiting_caller_a_question(self):
  s=TeamSession();s.begin('alex','sofia','Build form',1);s.begin('sofia','alex','Which fields?',2)
  self.assertEqual(s.count,2)
  with self.assertRaises(ValueError):s.begin('alex','sofia','Please repeat the task',3)

class TeamFlowTests(unittest.IsolatedAsyncioTestCase):
 async def asyncSetUp(self):
  self.temp=tempfile.TemporaryDirectory();self.addCleanup(self.temp.cleanup);self.store=Store(self.temp.name);self.chat=self.store.create_chat()
 async def test_nested_calls_share_files_checks_and_return_answers(self):
  code='def add(a,b): return a+b\n';test='import unittest\nfrom calc import add\nclass Tests(unittest.TestCase):\n def test_add(self): self.assertEqual(add(2,3),5)\n'
  model=Model([
   Message(calls=[call('call_agent',{'agent':'SOFIA','message':'Build a small addition UI','reason':'Frontend work'})]),
   Message(calls=[call('call_agent',{'agent':' @eLi ','message':'Implement tested addition logic','reason':'Need backend logic'})]),
   Message(calls=[call('write_files',{'files':[{'path':'calc.py','content':code},{'path':'test_calc.py','content':test}]})]),
   Message(calls=[call('run_tests',{'command':['python','-m','unittest','discover','-v']})]),Message('Eli: backend ready'),
   Message(calls=[call('read_files',{'paths':['calc.py']})]),Message('Sofia: frontend plan uses Eli’s backend'),Message('Alex: combined answer ready')])
  logs=[];original=model.create
  async def capture(**kwargs):logs.append(copy.deepcopy(kwargs));return await original(**kwargs)
  model.chat.completions.create=capture
  service=AgentService(self.store,NativeTestRunner(),lambda:model,'test-model');run=self.store.start_run(self.chat['id'],'alex','Build a simple addition tool')
  await service.execute(run,asyncio.Event())
  self.assertEqual(self.store.run(run['id'])['status'],'completed')
  messages=self.store.messages(self.chat['id']);answers=[m for m in messages if m['role']=='assistant']
  self.assertEqual([m['agent'] for m in answers],['eli','sofia','alex'])
  handoffs=[json.loads(m['content']) for m in messages if m['role']=='handoff']
  self.assertEqual([h['target'] for h in handoffs],['sofia','eli']);self.assertTrue(all(h['status']=='completed' for h in handoffs))
  self.assertIn('Build a simple addition tool',json.dumps(logs[1]['messages']))
  result=json.loads(logs[-1]['messages'][-1]['content']);self.assertEqual(result['agent'],'sofia')
  self.assertIn('calc.py',{f['path'] for f in result['files']})
  self.assertIn('Eli: backend ready',json.dumps(logs[-2]['messages']))
  artifacts=self.store.artifacts(self.chat['project_id']);self.assertTrue(all(a['agent']=='eli' and a['reply_id']==answers[0]['id'] for a in artifacts))
  check=self.store.run(run['id'])['checks'][0];self.assertEqual(check['status'],'passed');self.assertEqual(check['agent'],'eli');self.assertEqual(check['reply_id'],answers[0]['id'])
  self.assertTrue(model.closed)
 async def test_shared_history_keeps_speaker_identity_and_read_room_can_page_older_messages(self):
  prior=self.store.start_run(self.chat['id'],'alex','Earlier product question');self.store.finish(prior['id'],'completed','Done','I am Alex and here is my product answer.')
  for i in range(35):self.store.append_message(self.chat['id'],'user',None,'Older context '+str(i),prior['id'])
  model=Model([Message(calls=[call('read_room',{'before_message_id':'','limit':50})]),Message('Sofia sees the shared room')]);run=self.store.start_run(self.chat['id'],'sofia','Continue')
  await AgentService(self.store,NativeTestRunner(),lambda:model,'test').execute(run,asyncio.Event())
  result=json.loads(model.prompts[-1]['messages'][-1]['content'])
  self.assertTrue(any(m['content']=='I am Alex and here is my product answer.' for m in result['messages']))
  self.assertIn('Sofia',model.prompts[0]['messages'][0]['content'])
  page=self.store.read_room(self.chat['id'],limit=10);older=self.store.read_room(self.chat['id'],page['before_message_id'],10)
  self.assertTrue(page['has_more']);self.assertFalse({m['id'] for m in page['messages']}&{m['id'] for m in older['messages']})
  other=self.store.create_chat();other_run=self.store.start_run(other['id'],'eli','Private other room')
  with self.assertRaises(ValueError):self.store.read_room(self.chat['id'],self.store.messages(other['id'])[0]['id'],10)
 async def test_stop_cancels_entire_nested_call_and_releases_project(self):
  model=Model([Message(calls=[call('call_agent',{'agent':'sOfIa','message':'Work until stopped','reason':'UI help'})]),'wait'])
  service=AgentService(self.store,NativeTestRunner(),lambda:model,'test');run=self.store.start_run(self.chat['id'],'alex','Ask Sofia');service.start(run)
  task=service.active[run['id']][1]
  for _ in range(100):
   if len(model.prompts)>=2:break
   await asyncio.sleep(.01)
  self.assertEqual(self.store.run(run['id'])['agent'],'sofia')
  service.stop(run['id']);await asyncio.wait_for(task,2)
  self.assertEqual(self.store.run(run['id'])['status'],'cancelled')
  event=next(m for m in self.store.messages(self.chat['id']) if m['role']=='handoff');self.assertEqual(json.loads(event['content'])['status'],'cancelled')
  self.assertNotIn(run['id'],service.active)
  self.store.start_run(self.chat['id'],'eli','A new request can start')
 async def test_duplicate_tool_request_gets_feedback_without_another_peer_response(self):
  ask={'agent':'SOFIA','message':'Answer this UI question','reason':'UI expertise'}
  model=Model([Message(calls=[call('call_agent',ask)]),Message('Sofia answered'),Message(calls=[call('call_agent',ask)]),Message('Alex uses the existing answer')])
  run=self.store.start_run(self.chat['id'],'alex','Ask Sofia')
  await AgentService(self.store,NativeTestRunner(),lambda:model,'test').execute(run,asyncio.Event())
  messages=self.store.messages(self.chat['id']);self.assertEqual(sum(m['role']=='handoff' for m in messages),1)
  self.assertIn('already made',model.prompts[-1]['messages'][-1]['content']);self.assertEqual(self.store.run(run['id'])['status'],'completed')
 async def test_all_explicitly_addressed_agents_respond_sequentially(self):
  model=Model([Message('Sofia first'),Message('Eli second')]);run=self.store.start_run(self.chat['id'],'sofia','@SOFIA @eli both answer')
  await AgentService(self.store,NativeTestRunner(),lambda:model,'test').execute(run,asyncio.Event(),['sofia','eli'])
  answers=[m for m in self.store.messages(self.chat['id']) if m['role']=='assistant'];self.assertEqual([m['agent'] for m in answers],['sofia','eli'])
  self.assertIn('[Sofia replied] Sofia first',json.dumps(model.prompts[-1]['messages']))
 async def test_callee_can_ask_waiting_caller_and_both_resume(self):
  model=Model([Message(calls=[call('call_agent',{'agent':'SOFIA','message':'Design a settings form','reason':'UI design'})]),
               Message(calls=[call('call_agent',{'agent':'ALeX','message':'Which fields are required?','reason':'Product clarification'})]),
               Message('Alex clarification: name and timezone'),Message('Sofia completed the form design'),Message('Alex final combined reply')])
  run=self.store.start_run(self.chat['id'],'alex','Design settings')
  await AgentService(self.store,NativeTestRunner(),lambda:model,'test').execute(run,asyncio.Event())
  self.assertEqual(self.store.run(run['id'])['status'],'completed')
  messages=self.store.messages(self.chat['id'])
  self.assertEqual([m['agent'] for m in messages if m['role']=='assistant'],['alex','sofia','alex'])
  self.assertTrue(all(json.loads(m['content'])['status']=='completed' for m in messages if m['role']=='handoff'))
 async def test_failed_helper_is_visible_and_caller_can_explain(self):
  model=Model([Message(calls=[call('call_agent',{'agent':'eli','message':'Check API','reason':'API knowledge'})]),ValueError('Fixture helper failure'),Message('Alex: Eli could not finish the API check')])
  run=self.store.start_run(self.chat['id'],'alex','Check API')
  await AgentService(self.store,NativeTestRunner(),lambda:model,'test').execute(run,asyncio.Event())
  messages=self.store.messages(self.chat['id']);self.assertEqual(self.store.run(run['id'])['status'],'completed')
  self.assertTrue(any(m['agent']=='eli' and 'Fixture helper failure' in m['content'] for m in messages))
  self.assertEqual(json.loads(next(m for m in messages if m['role']=='handoff')['content'])['status'],'failed')

class TeamApiTests(unittest.TestCase):
 def test_api_routes_mixed_case_calls_and_dropdown_values(self):
  with tempfile.TemporaryDirectory() as d:
   app=create_app(d,Path(__file__).parents[1]/'static',lambda:Model(),'test',NativeTestRunner())
   with TestClient(app) as client:
    for text,selected,expected in [('Hey sOfIa','alex','sofia'),('@ELI help','alex','eli'),('Hello','SOFIA','sofia'),('Is Sofia here?','alex','alex')]:
     chat=client.post('/api/chats',json={}).json()
     response=client.post('/api/chats/'+chat['id']+'/messages',json={'agent':selected,'content':text})
     self.assertEqual(response.status_code,202);self.assertEqual(response.json()['agent'],expected)

class RestartTests(unittest.TestCase):
 def test_restart_does_not_leave_handoffs_working_forever(self):
  with tempfile.TemporaryDirectory() as d:
   store=Store(d);chat=store.create_chat();run=store.start_run(chat['id'],'alex','Ask Sofia')
   store.set_speaker(run['id'],'sofia')
   event=store.append_message(chat['id'],'handoff','alex',json.dumps({'target':'sofia','message':'Build a form','status':'working'}),run['id'])
   reopened=Store(d)
   self.assertEqual(reopened.run(run['id'])['status'],'interrupted')
   saved=next(m for m in reopened.messages(chat['id']) if m['id']==event)
   self.assertEqual(json.loads(saved['content'])['status'],'interrupted')
   reopened.start_run(chat['id'],'eli','Continue')

class MigrationTests(unittest.TestCase):
 def test_existing_stage1_database_is_preserved(self):
  with tempfile.TemporaryDirectory() as d:
   database=Path(d)/'rooz.sqlite3'
   with sqlite3.connect(database) as c:
    c.executescript('''CREATE TABLE projects(id TEXT PRIMARY KEY,title TEXT,created TEXT);
    CREATE TABLE chats(id TEXT PRIMARY KEY,project_id TEXT,title TEXT,created TEXT,updated TEXT);
    CREATE TABLE messages(id TEXT PRIMARY KEY,chat_id TEXT,role TEXT,agent TEXT,content TEXT,run_id TEXT,created TEXT);
    CREATE TABLE runs(id TEXT PRIMARY KEY,chat_id TEXT,project_id TEXT,agent TEXT,status TEXT,stage TEXT,checks TEXT,created TEXT,updated TEXT);
    CREATE TABLE artifacts(id TEXT PRIMARY KEY,project_id TEXT,run_id TEXT,path TEXT,content TEXT,created TEXT);
    INSERT INTO projects VALUES('project','Existing project','now');
    INSERT INTO chats VALUES('chat','project','Existing chat','now','now');
    INSERT INTO messages VALUES('message','chat','assistant','alex','Saved conversation','run','now');
    INSERT INTO runs VALUES('run','chat','project','alex','completed','Ready','[]','now','now');
    INSERT INTO artifacts VALUES('artifact','project','run','hello.py','print(1)','now');''')
   store=Store(d);Store(d)
   self.assertEqual(store.messages('chat')[0]['content'],'Saved conversation')
   self.assertEqual(store.artifact('artifact')['content'],'print(1)');self.assertEqual(store.run('run')['root_agent'],'alex')
   self.assertEqual(len(store.messages('chat')),1)
   backup=Path(d)/'backups/before-stage15.sqlite3';self.assertTrue(backup.is_file())
   with sqlite3.connect(backup) as c:self.assertEqual(len(c.execute('PRAGMA table_info(artifacts)').fetchall()),6)

if __name__=='__main__':unittest.main()
