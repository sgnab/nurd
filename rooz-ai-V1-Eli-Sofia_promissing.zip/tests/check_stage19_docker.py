"""Disposable real Docker preview acceptance. No provider keys or existing room data."""
import asyncio
import json
import sys
import tempfile
from pathlib import Path
import httpx

sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from rooz.storage import Store
from rooz.preview import PreviewService
from rooz.scaffold import files
from tests.fullstack_support import BACKEND,HTML

async def main():
    with tempfile.TemporaryDirectory(prefix='rooz-stage19-') as directory:
        store=Store(directory);chat=store.create_chat();root=store.workspace(chat['project_id'])
        for item in files(root):
            target=root/item['path'];target.parent.mkdir(parents=True,exist_ok=True);target.write_text(item['content'])
        fixtures=Path(__file__).parent/'fixtures'
        (root/'backend/main.py').write_text(BACKEND)
        (root/'frontend/src/App.tsx').write_text((fixtures/'notes-app.tsx').read_text())
        (root/'tests/browser-functional.py').write_text((fixtures/'notes-browser.py').read_text())
        service=PreviewService(store)
        try:
            started=await service.start(chat['id'])
            if started['status']!='running':raise RuntimeError(json.dumps(started,indent=2))
            name=service.states[chat['id']]['name']
            _,output=await service.backend.command('exec',name,'python','/source/tests/browser-functional.py','http://127.0.0.1:8080/',timeout=90)
            print(output,flush=True)
            refreshed=await service.start(chat['id'],refresh=True)
            if refreshed['status']!='running':raise RuntimeError(json.dumps(refreshed,indent=2))
            await service.stop(chat['id'])
            started=await service.start(chat['id'])
            if started['status']!='running':raise RuntimeError(json.dumps(started,indent=2))
            async with httpx.AsyncClient(trust_env=False) as client:
                rows=(await client.get(started['url']+'api/notes')).json()
                assert any(row['title']=='Persist across restart' for row in rows),rows
            await service.reset_data(chat['id'])
            assert not service.data_path(chat['id']).exists()
            (root/'frontend/package.json').unlink()
            (root/'frontend/index.html').write_text(HTML)
            plain=await service.start(chat['id'])
            if plain['status']!='running':raise RuntimeError(json.dumps(plain,indent=2))
            async with httpx.AsyncClient(trust_env=False) as client:
                response=await client.post(plain['url']+'api/notes',json={'title':'HTML plus API'})
                assert response.status_code==201,response.text
                rows=(await client.get(plain['url']+'api/notes')).json()
                assert rows[0]['title']=='HTML plus API',rows
            print('PASS: Docker React + plain HTML/API preview, real browser CRUD, Refresh, Stop/Start persistence and scoped data reset',flush=True)
            return 0
        finally:await service.shutdown()

if __name__=='__main__':
    try:raise SystemExit(asyncio.run(main()))
    except Exception as error:
        print('Stage 1.9 Docker verification failed: '+str(error),file=sys.stderr)
        raise SystemExit(1)
