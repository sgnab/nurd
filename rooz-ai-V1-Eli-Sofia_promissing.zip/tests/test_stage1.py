import asyncio,json,tempfile,unittest
from pathlib import Path
from unittest.mock import patch
from fastapi.testclient import TestClient
from rooz.storage import Store,safe_path
from rooz.runner import DockerRunner
from rooz.agents import AgentService
from rooz.api import create_app
from tests.support import Model,Message,call,NativeTestRunner
STATIC=Path(__file__).parents[1]/'static'

class StorageTests(unittest.TestCase):
 def setUp(self):
  self.temp=tempfile.TemporaryDirectory();self.addCleanup(self.temp.cleanup);self.store=Store(self.temp.name);self.chat=self.store.create_chat()
 def test_conversation_persists_after_reopening(self):
  run=self.store.start_run(self.chat['id'],'sofia','Create a form');self.store.finish(run['id'],'completed','Done','The form is ready.')
  reopened=Store(self.temp.name)
  self.assertEqual([m['content'] for m in reopened.messages(self.chat['id'])],['Create a form','The form is ready.'])
  self.assertEqual(reopened.runs(self.chat['id'])[0]['status'],'completed')
 def test_new_chat_can_share_project_and_other_projects_stay_isolated(self):
  sibling=self.store.create_chat(project_id=self.chat['project_id']);other=self.store.create_chat()
  self.assertEqual(sibling['project_id'],self.chat['project_id']);self.assertNotEqual(other['project_id'],sibling['project_id'])
 def test_concurrent_requests_are_serialized_per_project(self):
  sibling=self.store.create_chat(project_id=self.chat['project_id']);self.store.start_run(self.chat['id'],'alex','First')
  with self.assertRaises(ValueError):self.store.start_run(sibling['id'],'eli','Second')
 def test_restart_marks_interrupted_and_preserves_files(self):
  run=self.store.start_run(self.chat['id'],'eli','Build');self.store.write_files(run,[{'path':'hello.py','content':'print(1)'}])
  reopened=Store(self.temp.name)
  self.assertEqual(reopened.run(run['id'])['status'],'interrupted')
  self.assertIn('server restarted',reopened.messages(self.chat['id'])[-1]['content'].lower())
  self.assertEqual((reopened.workspace(self.chat['project_id'])/'hello.py').read_text(),'print(1)')
 def test_file_versions_are_immutable_and_transaction_validates_all_paths(self):
  run=self.store.start_run(self.chat['id'],'eli','Build');first=self.store.write_files(run,[{'path':'hello.py','content':'print(1)'}])[0]
  self.store.write_files(run,[{'path':'hello.py','content':'print(2)'}])
  self.assertEqual(self.store.artifact(first['id'])['content'],'print(1)')
  with self.assertRaises(ValueError):self.store.write_files(run,[{'path':'hello.py','content':'broken'},{'path':'../../app.py','content':'escape'}])
  self.assertEqual((self.store.workspace(self.chat['project_id'])/'hello.py').read_text(),'print(2)')
 def test_paths_cannot_access_secrets_or_escape_workspace(self):
  root=self.store.workspace(self.chat['project_id'])
  for name in ('../../secret','/tmp/secret','.env','src/.env.local','../projects','x\\y','.'):
   with self.assertRaises(ValueError):safe_path(root,name)
 def test_revisions_change_when_code_changes(self):
  run=self.store.start_run(self.chat['id'],'eli','Build');before=self.store.revision(self.chat['project_id'])
  self.store.write_files(run,[{'path':'a.py','content':'value=1'}]);self.assertNotEqual(before,self.store.revision(self.chat['project_id']))

class AgentTests(unittest.IsolatedAsyncioTestCase):
 async def asyncSetUp(self):
  self.temp=tempfile.TemporaryDirectory();self.addCleanup(self.temp.cleanup);self.store=Store(self.temp.name);self.chat=self.store.create_chat()
 async def execute(self,model,runner=None,agent='eli',request_timeout=None):
  service=AgentService(self.store,runner or NativeTestRunner(),lambda:model,'test-model');run=self.store.start_run(self.chat['id'],agent,'Please implement and test it')
  if request_timeout is not None:service.request_timeout=request_timeout
  await service.execute(run,asyncio.Event());return self.store.run(run['id'])
 async def test_real_python_tests_execute_before_code_is_returned(self):
  code='def add(a,b): return a+b\n';test='import unittest\nfrom calc import add\nclass Tests(unittest.TestCase):\n def test_add(self): self.assertEqual(add(2,3),5)\n'
  model=Model([Message(calls=[call('write_files',{'files':[{'path':'calc.py','content':code},{'path':'test_calc.py','content':test}]})]),Message(calls=[call('run_tests',{'command':['python','-m','unittest','discover','-v']})]),Message('Here is the tested code.\n```python\n'+code+'```')])
  run=await self.execute(model)
  self.assertEqual(run['status'],'completed');self.assertEqual(run['checks'][0]['status'],'passed');self.assertIn('Ran 1 test',run['checks'][0]['output']);self.assertTrue(model.closed)
 async def test_same_runner_executes_node_tests_for_frontend_agent(self):
  test="const test=require('node:test');const assert=require('node:assert/strict');test('add task',()=>{const rows=[];rows.push('Read');assert.equal(rows[0],'Read')});"
  model=Model([Message(calls=[call('write_files',{'files':[{'path':'task.test.cjs','content':test}]})]),Message(calls=[call('run_tests',{'command':['node','--test','task.test.cjs']})]),Message('Done')])
  run=await self.execute(model,agent='sofia');self.assertEqual(run['checks'][0]['status'],'passed')
 async def test_failed_check_is_retained_even_when_agent_returns_code(self):
  model=Model([Message(calls=[call('run_tests',{'command':['python','-c','raise AssertionError("expected failure")']})]),Message('This needs another correction.'),'wait'])
  run=await self.execute(model,request_timeout=.3);self.assertEqual(run['status'],'failed');self.assertEqual(run['checks'][0]['status'],'failed');self.assertIn('expected failure',run['checks'][0]['output'])
  self.assertEqual(run['end_reason'],'request_deadline')
  self.assertIn('45-minute request deadline',self.store.messages(self.chat['id'])[-1]['content'])
 async def test_code_without_model_checks_triggers_automatic_smoke_attempt(self):
  model=Model([Message(calls=[call('write_files',{'files':[{'path':'hello.py','content':'print(1)'}]})]),Message('Code ready.')]);runner=NativeTestRunner(unavailable=True)
  run=await self.execute(model,runner);self.assertEqual(runner.commands,[['python','/opt/rooz/check_workspace.py']]);self.assertEqual(run['checks'][0]['status'],'unavailable')
 async def test_stop_cancels_pending_model_and_preserves_chat(self):
  model=Model(['wait']);service=AgentService(self.store,NativeTestRunner(),lambda:model,'test');run=self.store.start_run(self.chat['id'],'alex','Wait')
  service.start(run);await asyncio.sleep(.03);service.stop(run['id']);await asyncio.wait_for(service.active[run['id']][1],2)
  self.assertEqual(self.store.run(run['id'])['status'],'cancelled');self.assertTrue(model.closed)
 async def test_missing_key_gives_actionable_result_without_fake_response(self):
  run=await self.execute(None);self.assertEqual(run['status'],'failed');self.assertIn('OPENAI_API_KEY',self.store.messages(self.chat['id'])[-1]['content'])
 async def test_real_openai_sdk_tool_roundtrip_with_mock_http_transport(self):
  import httpx
  from openai import AsyncOpenAI
  requests=[]
  async def handler(request):
   body=json.loads(request.content);requests.append(body)
   message={'role':'assistant','content':'SDK serialization confirmed.'}
   if len(requests)==1:message={'role':'assistant','content':None,'tool_calls':[{'id':'save-sdk','type':'function','function':{'name':'write_files','arguments':json.dumps({'files':[{'path':'sdk.txt','content':'SDK fixture'}]})}}]}
   return httpx.Response(200,json={'id':'fixture','object':'chat.completion','created':1,'model':'test-model','choices':[{'index':0,'message':message,'finish_reason':'tool_calls' if len(requests)==1 else 'stop'}]})
  client=AsyncOpenAI(api_key='fixture-key-not-real',http_client=httpx.AsyncClient(transport=httpx.MockTransport(handler)))
  run=await self.execute(client,NativeTestRunner(unavailable=True))
  self.assertEqual(run['status'],'failed')
  self.assertIn('Verification unavailable',self.store.messages(self.chat['id'])[-1]['content'])
  self.assertEqual(requests[1]['messages'][-1]['role'],'tool')
  self.assertEqual(self.store.artifacts(self.chat['project_id'])[0]['path'],'sdk.txt')
 async def test_invalid_tool_request_can_be_corrected(self):
  model=Model([Message(calls=[call('write_files',{'files':[{'path':'../escape.py','content':'oops'}]})]),Message('I need a valid project filename.')])
  run=await self.execute(model);self.assertEqual(run['status'],'completed');self.assertEqual(self.store.artifacts(self.chat['project_id']),[])

class ApiTests(unittest.TestCase):
 def setUp(self):
  self.temp=tempfile.TemporaryDirectory();self.addCleanup(self.temp.cleanup)
  app=create_app(self.temp.name,STATIC,lambda:Model(),'test-model',NativeTestRunner());self.app=app
  self.client=TestClient(app);self.client.__enter__();self.addCleanup(self.client.__exit__,None,None,None)
 def test_chat_endpoints_and_missing_ids(self):
  chat=self.client.post('/api/chats',json={}).json();self.assertEqual(self.client.get('/api/chats/'+chat['id']).status_code,200)
  self.assertEqual(self.client.get('/api/chats/absent').status_code,404)
  self.assertEqual(self.client.post('/api/chats/'+chat['id']+'/messages',json={'agent':'quinn','content':'Hi'}).status_code,422)
  self.assertEqual(self.client.post('/api/chats/'+chat['id']+'/messages',json={'agent':'alex','content':'  '}).status_code,422)
 def test_settings_never_return_key_and_cross_origin_writes_are_rejected(self):
  with patch.dict('os.environ',{'OPENAI_API_KEY':'test-secret-never-returned'}):
   config=self.client.get('/api/config');self.assertNotIn('test-secret-never-returned',config.text)
  self.assertEqual(self.client.post('/api/chats',json={},headers={'Origin':'https://other.example'}).status_code,403)
 def test_artifact_download_matches_exact_saved_version_and_project_zip(self):
  store=self.app.state.store;chat=store.create_chat();run=store.start_run(chat['id'],'eli','Build')
  artifact=store.write_files(run,[{'path':'hello.py','content':'print("Rooz")\n'}])[0]
  response=self.client.get('/api/artifacts/'+artifact['id']+'/download');self.assertEqual(response.text,'print("Rooz")\n');self.assertIn('attachment',response.headers['content-disposition'])
  import zipfile,io
  archive=self.client.get('/api/projects/'+chat['project_id']+'/download')
  with zipfile.ZipFile(io.BytesIO(archive.content)) as z:self.assertEqual(z.namelist(),['hello.py'])

class RunnerTests(unittest.IsolatedAsyncioTestCase):
 async def test_no_docker_never_falls_back_to_host_execution(self):
  with tempfile.TemporaryDirectory() as d,patch('rooz.runner.shutil.which',return_value=None):
   result=await DockerRunner().run(Path(d),['python','-c','print(1)'],asyncio.Event())
  self.assertEqual(result['status'],'unavailable');self.assertIsNone(result['exit_code'])
 async def test_unknown_command_is_rejected(self):
  with tempfile.TemporaryDirectory() as d:
   with self.assertRaises(ValueError):await DockerRunner().run(Path(d),['sh','-c','whoami'],asyncio.Event())

if __name__=='__main__':unittest.main()
