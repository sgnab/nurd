import shutil,subprocess,unittest
from pathlib import Path

class DashboardUI(unittest.TestCase):
 def test_actual_dashboard_script_behavior(self):
  if not shutil.which('node'):self.skipTest('Node required for dashboard DOM adapter')
  root=Path(__file__).parents[1]
  result=subprocess.run(['node','tests/check_monitoring_ui.cjs'],cwd=root,capture_output=True,text=True,timeout=15)
  self.assertEqual(result.returncode,0,result.stdout+result.stderr)
 def test_dashboard_form_has_labels_and_no_inline_handlers(self):
  text=(Path(__file__).parents[1]/'static'/'monitoring.html').read_text()
  for identifier in ('securityAgent','securityModel','maxCalls','outputTokens','paidConsent'):
   self.assertIn('id="'+identifier+'"',text)
  self.assertNotIn('onclick=',text)
  self.assertIn('role="alert"',text)
  self.assertIn('aria-pressed="true"',text)
