"""Real SDK serialization with a strict mock HTTP transport, never live provider proof."""
import asyncio,json,tempfile,unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import AsyncMock
import httpx
from openai import AsyncOpenAI
from rooz.agents import AgentService
from rooz.storage import Store
from tests.support import Model,Message,call,NativeTestRunner

class ModelToolTests(unittest.IsolatedAsyncioTestCase):
 async def test_sol_uses_responses_and_preserves_reasoning_and_call_ids(self):
  requests=[]
  def function(item_id,call_id,name,args):return {'type':'function_call','id':item_id,'call_id':call_id,'name':name,'arguments':json.dumps(args),'status':'completed'}
  code='def add(a,b): return a+b\n';test='import unittest\nfrom calc import add\nclass Tests(unittest.TestCase):\n def test_add(self): self.assertEqual(add(2,3),5)\n'
  async def handler(request):
   self.assertEqual(request.url.path,'/v1/responses')
   body=json.loads(request.content);requests.append(body)
   self.assertEqual(body['reasoning'],{'effort':'low'});self.assertNotIn('reasoning_effort',body)
   self.assertFalse(body['store']);self.assertIn('reasoning.encrypted_content',body['include'])
   for tool in body['tools']:
    self.assertEqual(tool['type'],'function');self.assertIn('name',tool);self.assertNotIn('function',tool);self.assertTrue(tool['strict'])
   round=len(requests)
   if round==1:
    output=[{'type':'reasoning','id':'rs_1','summary':[],'encrypted_content':'opaque-encrypted-fixture'},function('fc_item_1','call_1','write_files',{'files':[{'path':'calc.py','content':code},{'path':'test_calc.py','content':test}]})]
   elif round==2:
    self.assertTrue(any(i.get('encrypted_content')=='opaque-encrypted-fixture' for i in body['input']))
    self.assertTrue(any(i.get('id')=='fc_item_1' for i in body['input']))
    result=next(i for i in body['input'] if i.get('type')=='function_call_output')
    self.assertEqual(result['call_id'],'call_1');self.assertEqual(len(json.loads(result['output'])['saved']),2)
    output=[function('fc_item_2','read_call','read_files',{'paths':['calc.py']}),function('fc_item_3','test_call','run_tests',{'command':['python','-m','unittest','discover','-v']})]
   else:
    results={i['call_id']:json.loads(i['output']) for i in body['input'] if i.get('type')=='function_call_output'}
    self.assertEqual(results['read_call']['calc.py'],code);self.assertEqual(results['test_call']['status'],'passed')
    output=[{'type':'message','id':'msg_final','role':'assistant','status':'completed','content':[{'type':'output_text','text':'Saved and tested.','annotations':[]}]}]
   return httpx.Response(200,json={'id':'resp_'+str(round),'object':'response','created_at':1,'status':'completed','model':'gpt-6.1-sol','output':output})
  with tempfile.TemporaryDirectory() as d:
   store=Store(d);chat=store.create_chat();run=store.start_run(chat['id'],'alex','Implement and test addition')
   client=AsyncOpenAI(api_key='fixture-key-not-real',http_client=httpx.AsyncClient(transport=httpx.MockTransport(handler)))
   await AgentService(store,NativeTestRunner(),lambda:client,'gpt-6.1-sol').execute(run,asyncio.Event())
   self.assertEqual(store.run(run['id'])['status'],'completed',store.messages(chat['id'])[-1]['content'])
   self.assertEqual(store.messages(chat['id'])[-1]['content'],'Saved and tested.')
   self.assertEqual(store.run(run['id'])['checks'][0]['status'],'passed');self.assertEqual(len(requests),3)
 async def test_responses_handoff_keeps_callers_reasoning_and_returns_peer_answer(self):
  requests=[]
  async def handler(request):
   self.assertEqual(request.url.path,'/v1/responses');body=json.loads(request.content);requests.append(body)
   self.assertEqual(body['reasoning'],{'effort':'low'})
   self.assertTrue(any(t['name']=='call_agent' and t['strict'] for t in body['tools']))
   speaker=body['input'][0]['content'];results=[i for i in body['input'] if i.get('type')=='function_call_output']
   if speaker.startswith('You are Alex') and not results:
    output=[{'type':'reasoning','id':'reason_root','summary':[],'encrypted_content':'parent-reasoning-fixture'},
     {'type':'function_call','id':'fc_parent','call_id':'call_sofia','name':'call_agent','arguments':json.dumps({'agent':'SOFIA','message':'Please answer this UI question','reason':'Frontend knowledge'}),'status':'completed'}]
   elif speaker.startswith('You are Sofia'):
    self.assertFalse(results);self.assertIn('Alex is calling you',body['input'][-1]['content'])
    output=[{'type':'message','id':'sofia_reply','role':'assistant','status':'completed','content':[{'type':'output_text','text':'Sofia UI answer','annotations':[]}]}]
   else:
    self.assertTrue(speaker.startswith('You are Alex'));self.assertEqual(results[-1]['call_id'],'call_sofia')
    self.assertEqual(json.loads(results[-1]['output'])['answer'],'Sofia UI answer')
    self.assertTrue(any(i.get('encrypted_content')=='parent-reasoning-fixture' for i in body['input']))
    output=[{'type':'message','id':'alex_reply','role':'assistant','status':'completed','content':[{'type':'output_text','text':'Alex incorporated Sofia’s answer','annotations':[]}]}]
   return httpx.Response(200,json={'id':'response_'+str(len(requests)),'object':'response','created_at':1,'status':'completed','model':'gpt-6.1-sol','output':output})
  with tempfile.TemporaryDirectory() as d:
   store=Store(d);chat=store.create_chat();run=store.start_run(chat['id'],'alex','Ask Sofia about the UI')
   client=AsyncOpenAI(api_key='fixture-not-real',http_client=httpx.AsyncClient(transport=httpx.MockTransport(handler)))
   await AgentService(store,NativeTestRunner(),lambda:client,'gpt-6.1-sol').execute(run,asyncio.Event())
   self.assertEqual(store.run(run['id'])['status'],'completed',store.messages(chat['id'])[-1]['content'])
   self.assertEqual([m['agent'] for m in store.messages(chat['id']) if m['role']=='assistant'],['sofia','alex'])
   self.assertEqual(len(requests),3)
 async def test_other_models_keep_existing_chat_tools_without_reasoning_parameter(self):
  with tempfile.TemporaryDirectory() as d:
   store=Store(d);chat=store.create_chat();run=store.start_run(chat['id'],'eli','Write a file')
   model=Model([Message(calls=[call('write_files',{'files':[{'path':'example.txt','content':'saved'}]})]),Message('Ready')])
   await AgentService(store,NativeTestRunner(unavailable=True),lambda:model,'gpt-4.1-mini').execute(run,asyncio.Event())
   self.assertEqual(store.run(run['id'])['status'],'failed')
   self.assertIn('Verification unavailable',store.messages(chat['id'])[-1]['content'])
   for request in model.prompts:self.assertNotIn('reasoning_effort',request)
 async def test_stop_cancels_pending_responses_request(self):
  with tempfile.TemporaryDirectory() as d:
   store=Store(d);chat=store.create_chat();run=store.start_run(chat['id'],'alex','Wait')
   async def create(**kwargs):await asyncio.sleep(1000)
   client=SimpleNamespace(responses=SimpleNamespace(create=create),close=AsyncMock())
   service=AgentService(store,NativeTestRunner(),lambda:client,'gpt-6.1-sol');service.start(run)
   await asyncio.sleep(.02);service.stop(run['id']);await asyncio.wait_for(service.active[run['id']][1],2)
   self.assertEqual(store.run(run['id'])['status'],'cancelled');client.close.assert_awaited_once()
 async def test_incomplete_response_cannot_execute_partial_tool_calls(self):
  with tempfile.TemporaryDirectory() as d:
   store=Store(d);chat=store.create_chat();run=store.start_run(chat['id'],'alex','Implement')
   client=SimpleNamespace(responses=SimpleNamespace(create=AsyncMock(return_value=SimpleNamespace(status='incomplete',incomplete_details=SimpleNamespace(reason='max_output_tokens')))),close=AsyncMock())
   await AgentService(store,NativeTestRunner(),lambda:client,'gpt-6.1-sol').execute(run,asyncio.Event())
   self.assertEqual(store.run(run['id'])['status'],'failed');self.assertFalse(store.artifacts(chat['project_id']))
   self.assertIn('max_output_tokens',store.messages(chat['id'])[-1]['content'])
