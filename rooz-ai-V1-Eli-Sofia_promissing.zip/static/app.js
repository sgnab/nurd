'use strict';
const $=id=>document.getElementById(id);
const state={chat:null,data:null,chats:[],config:null,signature:'',polling:false,sending:false,uploading:false,mutation:0};
const names={alex:'Alex',sofia:'Sofia',eli:'Eli'};
const roles={alex:'Product & engineering',sofia:'Frontend & UI tests',eli:'Full-stack & tests'};
const terminal=new Set(['completed','failed','cancelled','interrupted']);
function el(tag,cls,text){const n=document.createElement(tag);if(cls)n.className=cls;if(text!==undefined)n.textContent=text;return n;}
async function api(path,method='GET',body){
 const form=body instanceof FormData;
 const response=await fetch(path,{method,headers:body&&!form?{'Content-Type':'application/json'}:{},body:form?body:body?JSON.stringify(body):undefined});
 const data=await response.json();if(!response.ok){const d=data.detail;throw Error(typeof d==='string'?d:Array.isArray(d)?d.map(i=>i.msg).join('; '):'Request failed');}return data;
}
function error(message=''){$('error').textContent=message;$('error').hidden=!message;}
function toast(message){$('toast').textContent=message;$('toast').hidden=false;setTimeout(()=>$('toast').hidden=true,2200);}
function saveBlob(content,filename){const url=URL.createObjectURL(new Blob([content],{type:'text/plain;charset=utf-8'}));const link=el('a');link.href=url;link.download=filename;document.body.append(link);link.click();link.remove();setTimeout(()=>URL.revokeObjectURL(url),5000);}
function extension(language){return {python:'py',py:'py',javascript:'js',js:'js',typescript:'ts',html:'html',css:'css',json:'json',bash:'sh',sh:'sh',jsx:'jsx',tsx:'tsx',sql:'sql'}[language]||'txt';}
function renderMarkdown(content){
 const box=el('div','markdown');box.innerHTML=window.roozMarkdown.render(content);
 box.querySelectorAll('a').forEach(a=>{a.target='_blank';a.rel='noopener noreferrer';});
 box.querySelectorAll('pre>code').forEach((code,index)=>{
  const pre=code.parentElement;const original=code.textContent;const language=[...code.classList].find(c=>c.startsWith('language-'))?.slice(9)||'text';
  if(window.roozHighlight.getLanguage(language))code.innerHTML=window.roozHighlight.highlight(original,{language,ignoreIllegals:true}).value;
  const wrapper=el('div','code-block'),head=el('div','code-head'),actions=el('div','code-actions');head.append(el('span','',language));
  const copy=el('button','','Copy');copy.onclick=async()=>{try{await navigator.clipboard.writeText(original);copy.textContent='Copied';setTimeout(()=>copy.textContent='Copy',1500);}catch(e){error('Clipboard unavailable; select the code to copy it.');}};
  const download=el('button','','Download');download.onclick=()=>saveBlob(original,'code-'+(index+1)+'.'+extension(language));actions.append(copy,download);head.append(actions);pre.replaceWith(wrapper);wrapper.append(head,pre);
 });return box;
}
function showChecks(run,message){
 const checks=run.checks.filter(c=>c.reply_id?c.reply_id===message.id:(!c.agent||c.agent===message.agent));
 if(!checks.length)return null;
 const latest=checks[checks.length-1],current=new Map();
 for(const check of checks)if(check.revision===state.data.revision)current.set(check.check_id||JSON.stringify(check.command),check);
 const currentChecks=[...current.values()],stale=!currentChecks.length;
 const failed=currentChecks.some(c=>c.status==='failed'),unavailable=currentChecks.some(c=>c.status!=='passed'&&c.status!=='failed');
 const card=el('details','check-card'+(failed||unavailable||stale?' fail':''));
 const heading=el('summary'),status=stale?'Earlier code revision':failed?'Checks failed':unavailable?'Checks unavailable':'Checks passed';
 heading.append(el('strong','',status),el('small','',latest.kind||'Executed checks'));card.append(heading);
 checks.forEach(c=>{const block=el('div','check-detail');block.append(el('strong','',c.status+(c.superseded_by?' (resolved by a passing rerun)':'')+' · '+c.kind),el('p','',c.command.join(' ')),el('pre','',c.output||'(No output)'));if(c.replacement_reason)block.append(el('p','','Corrected check: '+c.replacement_reason));card.append(block);});
 card.append(el('small','','These results apply to the saved code revision and executed commands shown above.'));return card;
}
function welcome(){
 const box=el('div','welcome');box.append(el('div','welcome-eyebrow','YOUR IDEAS, A LITTLE FURTHER.'));
 const h=el('h1');h.append(document.createTextNode('Make something '),el('em','','good.'));box.append(h,el('p','','A thought, a sketch, a tricky bit of code. Bring it here. Let’s turn it into something that works.'));
 const art=el('div','welcome-art');art.setAttribute('aria-hidden','true');const mini=el('div','mini-code');mini.append(el('div','mini-dots','● ● ●'));for(let i=0;i<4;i++)mini.append(el('span','mini-line'));art.append(mini,el('span','art-star','✳'),el('span','art-note','a little idea → a real thing'));box.append(art);
 const suggestions=el('div','suggestions');
 for(const [agent,icon,title,sub,prompt] of [['alex','✳','Think it through','Product & engineering','Help me turn an idea into a small, clear project.'],['sofia','▧','Make it tangible','Frontend & UI tests','Build a polished, responsive task list in plain HTML, CSS and JavaScript. Save the files and test the add and complete interactions.'],['eli','⌘','Build the logic','Full-stack & tests','Write a Python expense tracker that stores amounts as integer cents in SQLite. Include a few useful tests and run them.']]){
  const button=el('button','suggestion');button.append(el('span','suggestion-icon',icon),el('strong','',title),el('small','',sub));button.onclick=()=>{$('agentSelect').value=agent;updateAgent();$('prompt').value=prompt;$('prompt').focus();};suggestions.append(button);
 }box.append(suggestions);return box;
}
function attachmentCard(file,pending=false){
 const card=el('div','attachment-card'+(file.kind==='image'?' image-file':' text-file'));
 const body=pending?el('div','attachment-card-body'):el('a','attachment-card-body');
 if(!pending){body.href=file.download_url;body.title='Download '+file.filename;}
 if(file.kind==='image'){const img=el('img');img.src=file.thumbnail_url;img.alt='Attachment: '+file.filename;img.loading='lazy';body.append(img);}
 else body.append(el('span','file-extension',file.filename.split('.').pop().toUpperCase().slice(0,8)));
 body.append(el('strong','',file.filename),el('small','',file.size<1024?file.size+' B':Math.round(file.size/1024)+' KB'));
 card.append(body);
 if(pending){const remove=el('button','remove-attachment','×');remove.setAttribute('aria-label','Remove '+file.filename);remove.disabled=state.uploading||state.sending;remove.onclick=()=>removeAttachment(file.id);card.append(remove);}
 return card;
}
function renderDrafts(){
 const files=state.data?.pending_attachments||[];$('attachmentDrafts').replaceChildren();$('attachmentDrafts').hidden=!files.length;
 for(const file of files)$('attachmentDrafts').append(attachmentCard(file,true));
 $('attachButton').disabled=!state.chat||state.uploading||state.sending;$('send').disabled=!state.chat||state.uploading||state.sending;
}
async function uploadFiles(files){
 if(!files.length||!state.chat||state.uploading)return;
 const chat=state.chat,form=new FormData();for(const file of files)form.append('files',file,file.name);
 state.uploading=true;state.mutation++;error();$('uploadStatus').textContent='Uploading '+files.length+' file'+(files.length===1?'':'s')+'…';$('uploadStatus').hidden=false;renderDrafts();
 try{
  const result=await api('/api/chats/'+chat+'/attachments','POST',form);state.mutation++;
  if(state.chat===chat&&state.data?.chat.id===chat){state.data.pending_attachments=[...(state.data.pending_attachments||[]),...result.attachments];state.signature='';render();}
  else toast('Files saved as a draft in the earlier room.');
 }catch(e){error(e.message);}finally{state.uploading=false;state.mutation++;$('uploadStatus').hidden=true;$('attachmentInput').value='';renderDrafts();}
}
async function removeAttachment(id){
 if(state.uploading||state.sending)return;const chat=state.chat;state.uploading=true;state.mutation++;renderDrafts();
 try{await api('/api/chats/'+chat+'/attachments/'+id,'DELETE');state.mutation++;
  if(state.chat===chat){state.data.pending_attachments=state.data.pending_attachments.filter(a=>a.id!==id);state.signature='';render();}
 }catch(e){error(e.message);}finally{state.uploading=false;state.mutation++;renderDrafts();}
}
function currentRun(){return state.data?.runs.find(r=>!terminal.has(r.status));}
function render(){
 const data=state.data;if(!data)return;
 const signature=JSON.stringify([data.chat.title,data.messages,data.runs,data.artifacts,data.revision,data.pending_attachments]);if(signature===state.signature)return;state.signature=signature;
 const container=$('messages'),nearBottom=container.scrollHeight-container.scrollTop-container.clientHeight<150;container.replaceChildren();
 if(!data.messages.length)container.append(welcome());
 for(const message of data.messages){
  const row=el('article','message '+message.role);
  if(message.role==='user'){
   const body=el('div','user-message');body.append(el('div','user-content',message.content));
   if(message.attachments?.length){const files=el('div','message-attachments');for(const file of message.attachments)files.append(attachmentCard(file));body.append(files);}row.append(body);
  }
  else if(message.role==='handoff'){
   let handoff;try{handoff=JSON.parse(message.content);}catch(e){handoff={target:'',message:message.content,status:'recorded'};}
   row.className='message team-handoff';const detail=el('details'),summary=el('summary');
   summary.append(el('strong','',(names[message.agent]||message.agent)+' → '+(names[handoff.target]||handoff.target)),el('span','handoff-status '+handoff.status,handoff.status));
   detail.append(summary,el('p','',handoff.reason||'Teammate request'),el('div','handoff-task',handoff.message));
   if(handoff.error)detail.append(el('p','handoff-error',handoff.error));row.append(detail);
  }
  else{
   const meta=el('div','message-meta');meta.append(el('span','agent-dot '+message.agent,names[message.agent]?.[0]||'R'),el('strong','',names[message.agent]||'Rooz'),el('small','',roles[message.agent]||''));row.append(meta,renderMarkdown(message.content));
   const run=data.runs.find(r=>r.id===message.run_id);if(run){if(run.model)meta.append(el('small','message-model',modelName(run.model)));const checks=showChecks(run,message);if(checks)row.append(checks);}
   const files=data.artifacts.filter(a=>a.run_id===message.run_id&&(a.reply_id?a.reply_id===message.id:(!a.agent||a.agent===message.agent)));if(files.length){const downloads=el('div','download-row');const seen=new Set();for(const a of files){if(seen.has(a.path))continue;seen.add(a.path);const link=el('a','download-chip','↓ '+a.path);link.href='/api/artifacts/'+a.id+'/download';downloads.append(link);}row.append(downloads);}
  }container.append(row);
 }
 const active=currentRun();if(active){const row=el('div','message working');row.append(el('span','pulse'),el('span','',names[active.agent]+' · '+active.stage));container.append(row);}
 $('stop').hidden=!active;$('stop').disabled=active?.status==='stopping';$('send').hidden=!!active;$('send').disabled=state.sending||state.uploading;$('agentSelect').disabled=!!active;$('modelSelect').disabled=!!active||state.sending;if(active?.model)$('modelSelect').value=active.model;$('workingLabel').textContent=active?'Working…':'';
 $('chatTitle').textContent=data.chat.title+' ⌄';$('chatTitle').title='Rename project: '+data.chat.title;document.title=data.chat.title+' · Rooz-AI';$('fileCount').textContent=data.files.length;$('previewButton').disabled=false;$('filesButton').disabled=false;
 renderDrafts();
 if(nearBottom||!data.messages.length)container.scrollTop=container.scrollHeight;
}
function renderChats(){
 $('recentChats').replaceChildren();$('olderList').replaceChildren();
 state.chats.forEach((chat,index)=>{const b=el('button','chat-link'+(chat.id===state.chat?' active':''),chat.title);b.title=chat.title;b.setAttribute('aria-label',chat.title);b.onclick=()=>openChat(chat.id);(index<5?$('recentChats'):$('olderList')).append(b);});
 $('olderChats').hidden=state.chats.length<=5;$('olderCount').textContent=Math.max(0,state.chats.length-5);
}
async function refreshChats(){state.chats=(await api('/api/chats')).chats;renderChats();}
function closeNavigation(){document.body.classList.remove('nav-open');$('shade').hidden=true;}
async function openChat(id){
 state.chat=id;window.dispatchEvent(new CustomEvent('rooz:room',{detail:{chat:id}}));localStorage.setItem('rooz.chat',id);state.signature='';const loaded=await api('/api/chats/'+id);if(state.chat!==id)return;state.data=loaded;syncModelPicker(loaded.runs[0]?.model);$('agentSelect').value=loaded.runs[0]?.root_agent||loaded.runs[0]?.agent||'alex';updateAgent();render();renderChats();closeNavigation();$('messages').scrollTop=$('messages').scrollHeight;
}
function projectDialog(mode='create'){
 if(state.projectSaving)return;const dialog=$('projectDialog');dialog.dataset.mode=mode;
 $('projectDialogTitle').textContent=mode==='create'?'New project':'Rename project';
 $('saveProjectName').textContent=mode==='create'?'Create project':'Save name';
 $('projectName').value=mode==='rename'?state.data.chat.title:'';$('projectNameError').hidden=true;
 if(!dialog.open)dialog.showModal();$('projectName').focus();$('projectName').select();
}
function newProject(){projectDialog('create');}
$('cancelProjectName').onclick=()=>{if(!state.projectSaving)$('projectDialog').close();};
$('projectDialog').addEventListener('cancel',event=>{if(state.projectSaving)event.preventDefault();});
$('projectForm').onsubmit=async event=>{
 event.preventDefault();if(state.projectSaving)return;const title=$('projectName').value.trim();
 if(!title){$('projectNameError').textContent='Enter a project name.';$('projectNameError').hidden=false;$('projectName').focus();return;}
 state.projectSaving=true;$('saveProjectName').disabled=true;$('cancelProjectName').disabled=true;
 try{
  if($('projectDialog').dataset.mode==='create'){
   const chat=await api('/api/projects','POST',{title});await refreshChats();await openChat(chat.id);$('prompt').value='';
  }else{
   await api('/api/chats/'+state.chat,'PATCH',{title});state.mutation++;state.signature='';await openChat(state.chat);await refreshChats();
  }
  $('projectDialog').close();$('prompt').focus();error();
 }catch(e){$('projectNameError').textContent=e.message;$('projectNameError').hidden=false;}
 finally{state.projectSaving=false;$('saveProjectName').disabled=false;$('cancelProjectName').disabled=false;}
};
async function send(){
 const content=$('prompt').value.trim(),files=state.data?.pending_attachments||[];
 if((!content&&!files.length)||state.sending||state.uploading||currentRun()||state.data?.chat.id!==state.chat)return;
 state.sending=true;$('send').disabled=true;error();const chat=state.chat,agent=$('agentSelect').value,model=$('modelSelect').value;renderDrafts();
 try{
  const run=await api('/api/chats/'+chat+'/messages','POST',{agent,content,model,attachment_ids:files.map(a=>a.id)});state.mutation++;if(run.model)localStorage.setItem('rooz.model.'+chat,run.model);
  if(state.chat===chat){
   $('agentSelect').value=run.root_agent||run.agent;updateAgent();$('prompt').value='';$('prompt').style.height='auto';
   const loaded=await api('/api/chats/'+chat);
   if(state.chat===chat){state.data=loaded;state.signature='';render();$('messages').scrollTop=$('messages').scrollHeight;}
  }
  await refreshChats();
 }catch(e){error(e.message);}finally{state.sending=false;renderDrafts();}
}
async function poll(){
 if(!state.chat||state.polling)return;state.polling=true;const id=state.chat,generation=state.mutation;
 try{const data=await api('/api/chats/'+id);if(id===state.chat&&generation===state.mutation){state.data=data;render();}}catch(e){error('Connection interrupted. Reconnecting automatically…');}finally{state.polling=false;}
}
function modelName(id){return state.config?.models?.find(m=>m.id===id)?.label||id;}
function syncModelPicker(previous){
 const models=state.config?.models;if(!models?.length)return;
 const picker=$('modelSelect'),saved=localStorage.getItem('rooz.model.'+state.chat);
 const selected=[saved,previous,localStorage.getItem('rooz.model'),state.config.model].find(id=>models.some(m=>m.id===id))||models[0].id;
 picker.replaceChildren();for(const m of models){const option=el('option','',m.label+(m.key_configured?'':' · key needed'));option.value=m.id;picker.append(option);}
 picker.value=selected;updateModelHint();
}
function updateModelHint(){
 const selected=state.config?.models?.find(m=>m.id===$('modelSelect').value);
 $('modelHint').textContent=selected&&!selected.key_configured?'Add '+(selected.provider==='deepseek'?'DEEPSEEK_API_KEY':'OPENAI_API_KEY')+' to .env and restart.':'Selected model applies to this request and teammate calls.';
}
$('modelSelect').onchange=()=>{localStorage.setItem('rooz.model',$('modelSelect').value);if(state.chat)localStorage.setItem('rooz.model.'+state.chat,$('modelSelect').value);updateModelHint();};
function updateAgent(){const agent=$('agentSelect').value;$('agentDot').className='agent-dot '+agent;$('agentDot').textContent=names[agent][0];}
function drawer(title,eyebrow){$('drawerTitle').textContent=title;$('drawerEyebrow').textContent=eyebrow;$('drawerContent').replaceChildren();if(!$('drawer').open)$('drawer').showModal();return $('drawerContent');}
$('previewButton').onclick=()=>window.dispatchEvent(new CustomEvent('rooz:preview',{detail:{chat:state.chat}}));
$('filesButton').onclick=()=>{
 const box=drawer('Project files','SAVED IN THIS WORKSPACE');if(!state.data?.files.length){box.append(el('p','','Files the agents save will appear here. You can also download individual code blocks directly from a response.'));return;}
 const latest=new Map();for(const a of state.data.artifacts)if(!latest.has(a.path))latest.set(a.path,a);
 for(const file of state.data.files){const row=el('div','file-item');row.append(el('span','',file.path));const artifact=latest.get(file.path);if(artifact){const a=el('a','','↓ Download');a.href='/api/artifacts/'+artifact.id+'/download';row.append(a);}box.append(row);}
 const all=el('a','download-all','Download project ZIP');all.href='/api/projects/'+state.data.chat.project_id+'/download';box.append(all);
};
$('settings').onclick=async()=>{
 const box=drawer('Your environment','CONFIGURED ONCE, REUSED');box.append(el('p','','Checking configuration…'));
 try{state.config=await api('/api/config');const c=state.config;box.replaceChildren();box.append(el('h3','','Coding models'));for(const m of c.models||[])box.append(el('p','',m.label+' · '+(m.key_configured?'Key configured':('Add '+(m.provider==='deepseek'?'DEEPSEEK_API_KEY':'OPENAI_API_KEY')+' to .env and restart'))));box.append(el('p','','Select a model in the chat composer. That model is used for the request and any teammate calls. Keys stay on the server.'));syncModelPicker();
 box.append(el('h3','','Shared test environment'),el('p','',c.runner.ready?'Ready. All agents use the same isolated Python, Node and browser environment.':c.runner.reason));
 if(!c.runner.ready)box.append(el('pre','','docker build -t rooz-ai-runner:stage1 -f sandbox/Dockerfile .'));
 box.append(el('h3','','Projects and full-stack preview'),el('p','','Shared room, attachments and actual image input. Upload up to 8 files, 10 MB each and 20 MB total. Code/text files: UTF-8, at most 1 MB. PNG, JPEG and WebP images are supported. Uploads stay separate from executable project files. Static Live Preview is available from the Preview button. Eli supports React builds and full-stack checks. Preview serves the built UI and its backend at one address.'));}
 catch(e){box.replaceChildren(el('p','',e.message));}
};
$('attachButton').onclick=()=>$('attachmentInput').click();
$('attachmentInput').onchange=()=>uploadFiles([...$('attachmentInput').files]);
$('prompt').addEventListener('paste',event=>{
 const files=[...(event.clipboardData?.items||[])].filter(i=>i.kind==='file').map(i=>i.getAsFile()).filter(Boolean);
 if(files.length){event.preventDefault();uploadFiles(files);}
});
document.addEventListener('dragover',event=>{if([...event.dataTransfer.types].includes('Files')){event.preventDefault();document.querySelector('.composer').classList.add('drag-over');}});
document.addEventListener('dragleave',event=>{if(!event.relatedTarget)document.querySelector('.composer').classList.remove('drag-over');});
document.addEventListener('drop',event=>{if(event.dataTransfer.files.length){event.preventDefault();document.querySelector('.composer').classList.remove('drag-over');uploadFiles([...event.dataTransfer.files]);}});
$('newChat').onclick=newProject;$('send').onclick=send;$('agentSelect').onchange=updateAgent;
$('stop').onclick=async()=>{const run=currentRun();if(run){try{await api('/api/runs/'+run.id+'/stop','POST',{});await poll();}catch(e){error(e.message);}}};
$('prompt').addEventListener('keydown',e=>{if(e.key==='Enter'&&!e.shiftKey&&!e.isComposing){e.preventDefault();send();}});
$('prompt').addEventListener('input',()=>{$('prompt').style.height='auto';$('prompt').style.height=Math.min(200,$('prompt').scrollHeight)+'px';});
$('chatTitle').onclick=()=>{if(state.data)projectDialog('rename');else newProject();};
$('menuButton').onclick=()=>{document.body.classList.add('nav-open');$('shade').hidden=false;};$('shade').onclick=closeNavigation;
$('closeDrawer').onclick=()=>$('drawer').close();$('drawer').addEventListener('click',e=>{if(e.target===$('drawer')&&e.clientX<$('drawer').getBoundingClientRect().left)$('drawer').close();});
document.addEventListener('keydown',e=>{if((e.metaKey||e.ctrlKey)&&e.key.toLowerCase()==='k'){e.preventDefault();newProject();}});
(async()=>{try{await refreshChats();const saved=localStorage.getItem('rooz.chat');if(state.chats.length)await openChat(state.chats.some(c=>c.id===saved)?saved:state.chats[0].id);else{$('messages').replaceChildren(welcome());$('previewButton').disabled=true;$('filesButton').disabled=true;renderDrafts();newProject();}const config=await api('/api/config');state.config=config;syncModelPicker(state.data?.runs[0]?.model);state.signature='';if(state.data)render();const anyKey=config.models?.some(m=>m.key_configured)||config.key_configured;$('connectionLabel').textContent=anyKey?(config.runner.ready?'Environment ready':'Key saved · tests need setup'):'Configure your environment';document.querySelector('.settings-button .status-dot').classList.toggle('warning',!anyKey||!config.runner.ready);setInterval(poll,1000);}catch(e){error(e.message);}})();
