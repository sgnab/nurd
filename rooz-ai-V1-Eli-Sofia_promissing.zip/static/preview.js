/* Preview UI is deliberately independent of chat/model execution. */
(()=>{'use strict';
 const $=id=>document.getElementById(id),panel=$('previewPanel');let chat=null,data=null,busy='',version=0,polling=false,frameUrl='';
 async function request(suffix='',method='GET',body){
  const response=await fetch('/api/chats/'+chat+'/preview'+suffix,{method,headers:body?{'Content-Type':'application/json'}:{},body:body?JSON.stringify(body):undefined});
  const result=await response.json();if(!response.ok)throw Error(typeof result.detail==='string'?result.detail:'Preview request failed (HTTP '+response.status+')');return result;
 }
 function clearFrame(){frameUrl='';$('previewFrame').removeAttribute('src');$('previewFrame').hidden=true;$('previewPlaceholder').hidden=false;}
 function render(row){
  data=row;const select=$('previewEntry'),old=select.value,options=row.entries||[];
  if(JSON.stringify([...select.options].map(o=>o.value))!==JSON.stringify(options)){
   select.replaceChildren();for(const path of options){const option=document.createElement('option');option.value=path;option.textContent=path==='@fullstack'?'Full-stack app (UI + API)':path;select.append(option);}
   select.value=options.includes('@fullstack')&&row.mode!=='fullstack'?'@fullstack':options.includes(old)?old:options.includes(row.entry)?row.entry:options[0]||'';
  }
  select.disabled=!!busy;const running=row.status==='running';
  $('startPreview').disabled=!!busy||running||!options.length;
  $('refreshPreview').disabled=!!busy||!options.length||!running;
  $('stopPreview').disabled=busy==='stop'||(!busy&&!['running','starting','error'].includes(row.status));
  $('previewStatus').textContent=busy==='stop'?'Stopping…':row.status==='starting'?'Starting…':running?'Running':row.status==='error'?'Needs attention':'Stopped';
  const app=row.mode==='fullstack'||select.value==='@fullstack';
  $('previewNote').textContent=row.source_error||(!options.length?'Save an HTML file or supported full-stack app in Project files first.':row.status==='starting'?(app?'Building frontend and starting its real backend… Open logs for progress.':'Starting the static server and checking its local address…'):row.stale?'Saved files changed. Refresh rebuilds code and preserves preview data.':running?(app?'Frontend + real API · Preview data survives Refresh and Stop. Closing this panel keeps it running.':(options.includes('@fullstack')?'Static-only mode: API is not running. Choose Full-stack app and Refresh.':'Read-only static snapshot · Closing this panel keeps it running.')):(app?'Serves the UI and /api through its real backend. Builds React only when needed. Data is separate from saved source.':'Saved HTML, CSS and JavaScript.'));
  $('resetPreviewData').hidden=!app;$('resetPreviewData').disabled=!!busy;
  $('openPreviewTab').hidden=true;$('openPreviewTab').removeAttribute('href');
  $('previewError').textContent=row.error||'';$('previewError').hidden=!row.error;
  $('previewLogText').textContent=row.logs||'No server logs yet.';
  if(running&&/^http:\/\/127\.0\.0\.1:\d+\/$/.test(row.url||'')){
   if(frameUrl!==row.url){frameUrl=row.url;$('previewFrame').src=row.url;}
   $('openPreviewTab').href=row.url;$('openPreviewTab').hidden=false;
   $('previewFrame').hidden=false;$('previewPlaceholder').hidden=true;
  }else{clearFrame();$('previewPlaceholder').textContent=row.status==='starting'?'Starting your preview…':row.status==='error'?'Preview could not run. Read the error above or open the server logs.':'Your app will appear here.';}
 }
 async function poll(){
  if(!panel.open||!chat||busy||polling)return;polling=true;const ticket=version,id=chat;
  try{const row=await request();if(ticket===version&&id===chat)render(row);}
  catch(e){if(ticket===version){$('previewError').textContent=e.message;$('previewError').hidden=false;}}
  finally{polling=false;}
 }
 async function action(kind){
  if(!chat||(busy&&kind!=='stop'))return;const ticket=++version,id=chat,entry=$('previewEntry').value;busy=kind;
  render({...data,status:kind==='stop'?'stopped':'starting',url:null,error:''});
  try{const row=await request('/'+kind,'POST',kind==='stop'?{}:{entry});if(ticket===version&&id===chat){busy='';render(row);}}
  catch(e){if(ticket===version&&id===chat){busy='';render({...data,status:'error',url:null,error:e.message});}}
 }
 async function logs(){
  if(!chat)return;const ticket=version,id=chat;
  try{const result=await request('/logs');if(ticket===version&&id===chat){$('previewLogText').textContent=(result.error?result.error+'\n':'')+(result.logs||'No server logs yet.');}}
  catch(e){if(ticket===version)$('previewLogText').textContent=e.message;}
 }
 function changeRoom(id){
  if(chat===id)return;chat=id;version++;busy='';clearFrame();render({status:'stopped',entries:[],error:'',logs:''});if(panel.open)poll();
 }
 window.addEventListener('rooz:room',event=>changeRoom(event.detail.chat));
 window.addEventListener('rooz:preview',event=>{changeRoom(event.detail.chat);if(!panel.open)panel.showModal();poll();});
 $('closePreview').onclick=()=>panel.close();$('startPreview').onclick=()=>action('start');$('refreshPreview').onclick=()=>action('refresh');$('stopPreview').onclick=()=>action('stop');
 $('previewLogs').addEventListener('toggle',()=>{if($('previewLogs').open)logs();});$('reloadPreviewLogs').onclick=logs;
 $('resetPreviewData').onclick=async()=>{if(!chat||busy||!confirm('Stop this preview and delete its stored preview data? Saved source files will stay.'))return;await action('reset-data');};
 $('previewEntry').onchange=()=>{if(data)render(data);};
 setInterval(()=>{poll();if(panel.open&&busy&&$('previewLogs').open)logs();},2000);
})();
