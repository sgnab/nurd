#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
.venv/bin/python - <<'PY'
from pathlib import Path
import zipfile
root=Path.cwd();destination=root.parent/'rooz-ai-review.zip'
with zipfile.ZipFile(destination,'w',zipfile.ZIP_DEFLATED) as z:
 for p in sorted(root.rglob('*')):
  if not p.is_file() or p.is_symlink():continue
  rel=p.relative_to(root)
  if any(x in ('.venv','data','node_modules','__pycache__','.git') for x in rel.parts) or p.name.startswith('.env') or p.suffix=='.pyc':continue
  z.write(p,rel)
print('Saved:',destination)
PY
