# Corrected checks and request lifecycle

This update changes Rooz-AI's host and Eli's development guidance. It does not change generated project source.

## Corrected checks

Every check execution now has an execution ID and belongs to a logical check ID. Rerunning the same command uses the same logical check. When the command itself has broken setup, Eli can use `rerun_check(check_id, command, reason)` to execute a corrected command. He must explain what changed and preserve the intended behavior and assertions.

Only an executed pass settles the failure. The original command, output and failure remain in history, linked to the passing rerun. A failed replacement still blocks delivery. Passing an unrelated command does not clear another check. The UI shows the latest logical result and marks historical failures resolved by a passing rerun.

Full-stack acceptance retains `python tests/verify.py` (or python3) as its entrypoint. A smaller probe cannot replace that gate. Existing current-revision and browser-screenshot checks remain in place. Eli can edit tests to correct stale setup/selectors; this mechanism records his explanation and actual execution, not a formal proof that two arbitrary test programs have identical coverage.

Older saved results remain readable. This update applies logical identities to new executions; it does not relabel historical failures from older requests.

## Time and cancellation

The overall request deadline is now **45 minutes**, up from 15. Agent turn-count limits have been removed. The shared 45-minute deadline and Stop govern request duration; individual-operation timeouts still detect stalled calls.

Runs persist an `end_reason` distinguishing user Stop, request deadline, operation timeout, server shutdown, external cancellation and interrupted server restart. Cancellation messages retain the saved work and no longer label the request deadline as a user Stop. An operation timeout is not labelled as the 45-minute deadline. Stop still cancels the waiting teammate chain.

## Build before browser checks

Eli's guides now explicitly require building the frontend before browser navigation, within the same disposable test command or saved script. Builds must not run lazily inside an HTTP request. Earlier build output disappears between disposable commands. Existing generated apps with lazy-build handlers still need Eli to repair those handlers; this host update does not rewrite them.

## Install

Stop Rooz-AI, replace its source from this ZIP, retain your existing `.env` and `data/`, then start with `bash start.sh`. No runner-image change is included, so this update does not require rebuilding the Docker image. The database migration only adds a nullable run-reason column.

## Verification

167 automated tests passed, including corrected-command recovery, failed-replacement handling, acceptance-entrypoint protection, real OpenAI SDK serialization with controlled Responses API replies, request-lifecycle causes, real local HTTP/SQLite recovery and Stop, and the actual check-card renderer using a minimal Node text-node adapter. JavaScript syntax validation also passed.

These tests use controlled model responses and native disposable fixtures. Chromium could not start because this environment disallows the Unix socket it needs; downloading a separate headless browser was also unavailable. Browser tests, Docker execution and live-provider calls were not verified in this delivery. The runner image, supported app templates and generated project source were not changed.
